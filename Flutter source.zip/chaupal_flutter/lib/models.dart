import 'package:flutter/material.dart';
import 'theme.dart';

class GameDef {
  final String id, name, tag, glyph, blurb;
  final List<int> counts;
  final Color accent;
  const GameDef(this.id, this.name, this.tag, this.counts, this.accent, this.glyph, this.blurb);
}

const games = [
  GameDef('ludo', 'Ludo', 'The house classic', [2, 3, 4], T.red, '🎲', 'Cut, guard, home run.'),
  GameDef('carrom', 'Carrom', 'Aim and flick', [2, 3, 4], T.yellow, '⭕', 'Real striker physics.'),
  GameDef('uttt', 'Tic Tac Toe', 'Three formats', [2], T.green, '✕', 'Classic, Infinity, Nine Board.'),
  GameDef('snakes', 'Snakes & Ladders', 'Climb and slide', [2, 3, 4], T.blue, '🪜', 'Every square scores.'),
];
GameDef gameOf(String id) => games.firstWhere((g) => g.id == id, orElse: () => games[0]);

/// One format of a board. Optional fields only matter for the board that reads them.
class Mode {
  final String id, name, glyph, tag;
  final Color color;
  final Map<int, int> secs;
  final bool open; // ludo: all tokens start on the track
  final int? rolls; // ludo turbo: roll budget
  final int tokens; // snakes: tokens per player
  final Map<int, int>? moves; // snakes plus: move budget by player count
  final int target; // carrom points / ttt rounds
  final List<int> players;
  const Mode(this.id, this.name, this.glyph, this.color, this.tag, this.secs,
      {this.open = false, this.rolls, this.tokens = 1, this.moves, this.target = 3, this.players = const [2, 3, 4]});
  int secsFor(int n) => secs[n] ?? secs.values.first;
}

const ludoModes = [
  Mode('classic', 'Classic', '🏠', T.green, 'Roll a six to open. First to bring every token home.', {2: 480, 3: 540, 4: 600}),
  Mode('rush', 'Score Rush', '⚡', T.yellow, 'All tokens open. Every box is a point. Highest score when time ends.', {2: 300, 3: 360, 4: 420}, open: true),
  Mode('turbo', 'Turbo', '🎯', T.red, '24 rolls each, all tokens open. Bonus rolls are free. Make every roll count.', {2: 420, 3: 480, 4: 540}, open: true, rolls: 24),
];
const carromModes = [
  Mode('free', 'Freestyle', '🎯', T.yellow, 'Pocket anything. Black 10, white 20, queen 50. First to 120.', {2: 300, 3: 360, 4: 420}, target: 120),
  Mode('classic', 'Classic', '👑', T.red, 'White vs black. Clear your colour and cover the queen.', {2: 420}, players: [2]),
  Mode('disc', 'Colour Rush', '⚪', T.blue, 'No queen. First to clear all nine of your colour.', {2: 360}, players: [2]),
];
const tttModes = [
  Mode('classic', 'Classic', '✕', T.green, 'The 3×3 you know. First to win three rounds. Draws replay.', {2: 300}, players: [2]),
  Mode('infinity', 'Infinity', '∞', T.blue, 'Only your last three marks stay — the oldest fades when you place a fourth. No draws, ever.', {2: 300}, players: [2]),
  Mode('nine', 'Nine Board', '▦', T.red, 'Nine boards in one. Where you play decides which board they must play in.', {2: 420}, target: 1, players: [2]),
];
const slModes = [
  Mode('plus', 'Plus', '➕', T.green, 'Three tokens each, all open. Every square scores. Ladders and cuts earn free extra turns. Fixed moves — highest score wins.', {2: 300, 3: 360, 4: 420}, tokens: 3, moves: {2: 15, 3: 12, 4: 10}),
  Mode('classic', 'Classic', '🪜', T.yellow, 'One token. Climb, slide, and be first to square 100. Overshoot bounces back.', {2: 360, 3: 420, 4: 480}),
];
List<Mode> formatsOf(String gid) => switch (gid) { 'ludo' => ludoModes, 'carrom' => carromModes, 'uttt' => tttModes, _ => slModes };

const seatsFor = {2: [0, 2], 3: [0, 1, 2], 4: [0, 1, 2, 3]};
const botNames = ['Rhea', 'Saif', 'Nandu', 'Meera', 'Abhi', 'Zoya', 'Kabir', 'Diya', 'Golu', 'Ishaan'];

class Player {
  final int seat;
  final String name, avatar;
  final bool you;
  final String frame;
  const Player(this.seat, this.name, this.avatar, {this.you = false, this.frame = 'none'});
}

/* ---------------- status tiers ---------------- */
class Tier {
  final String id, name, glyph, perk;
  final int cost, bonus, mins, upkeep;
  final int free; // -1 = unlimited
  final List<String> rooms;
  final Color color;
  const Tier(this.id, this.name, this.glyph, this.cost, this.bonus, this.free, this.mins, this.rooms, this.upkeep, this.color, this.perk);
  bool get unlimited => free < 0;
}

const tiers = [
  Tier('rookie', 'Rookie', '🎲', 0, 0, 0, 2, [], 0, T.mute, 'Where everyone starts. Chat costs coins.'),
  Tier('peacock', 'Peacock', '🦚', 1000, 5, 2, 2, [], 0, Color(0xFF3FBFA8), '2 free chat entries a day · +5 coins a game'),
  Tier('elephant', 'Elephant', '🐘', 10000, 10, 5, 2, [], 0, Color(0xFFA992D6), '5 free chat entries a day · +10 coins a game'),
  Tier('turtle', 'Turtle', '🐢', 50000, 20, -1, 5, ['turtle'], 10, T.green, 'Unlimited chat · 5-minute sessions · Turtle room · +20 coins a game'),
  Tier('owl', 'Owl', '🦉', 100000, 50, -1, 10, ['turtle', 'owl'], 10, Color(0xFFE7A94F), 'Unlimited chat · 10-minute sessions · Owl + Turtle rooms · +50 coins a game'),
  Tier('lion', 'Lion', '🦁', 200000, 100, -1, 15, ['turtle', 'owl', 'lion'], 0, T.yellow, 'Unlimited chat · 15-minute sessions · every room · +100 coins a game'),
];
Tier tierOf(String id) => tiers.firstWhere((t) => t.id == id, orElse: () => tiers[0]);

/* ---------------- league & cups ---------------- */
const trophyDelta = [12, 6, 2, -3];
const cupPoints = [10, 6, 3, 1];

class League { final String id, name, glyph; final int min; final Color color; const League(this.id, this.name, this.min, this.color, this.glyph); }
const leagues = [
  League('bronze', 'Bronze', 0, Color(0xFFC97A3E), '🥉'),
  League('silver', 'Silver', 200, Color(0xFFB8C0CC), '🥈'),
  League('gold', 'Gold', 500, T.yellow, '🥇'),
  League('platinum', 'Platinum', 1000, Color(0xFF7FE3F0), '💎'),
  League('diamond', 'Diamond', 2000, T.violet, '👑'),
];
League leagueOf(int t) => leagues.lastWhere((l) => t >= l.min, orElse: () => leagues[0]);

class Cup { final String id, name, game, glyph; final int entry; final Color color; const Cup(this.id, this.name, this.game, this.entry, this.color, this.glyph); }
const cups = [
  Cup('ludo', 'Ludo Cup', 'ludo', 200, T.red, '🎲'),
  Cup('carrom', 'Carrom Cup', 'carrom', 150, T.yellow, '⭕'),
  Cup('uttt', 'XO Cup', 'uttt', 100, T.green, '✕'),
  Cup('snakes', 'Ladders Cup', 'snakes', 150, T.blue, '🪜'),
  Cup('all', 'Chaupal Open', 'all', 300, T.violet, '🏆'),
];
class CupPrize { final int upto, coins, trophies; final String label; const CupPrize(this.upto, this.coins, this.trophies, this.label); }
const cupPrizes = [
  CupPrize(1, 5000, 60, '1st'), CupPrize(3, 2500, 35, '2nd–3rd'), CupPrize(10, 1000, 20, '4th–10th'),
  CupPrize(50, 300, 8, '11th–50th'), CupPrize(100, 100, 3, '51st–100th'),
];
CupPrize? prizeForRank(int r) { for (final p in cupPrizes) { if (r <= p.upto) return p; } return null; }

/* ---------------- market catalogue ---------------- */
class Rarity { final String name; final Color color; const Rarity(this.name, this.color); }
const rarities = {
  'common': Rarity('Common', T.mute), 'rare': Rarity('Rare', T.blue), 'epic': Rarity('Epic', T.violet), 'legendary': Rarity('Legendary', T.yellow),
};

class Item {
  final String id, name, cat, rarity;
  final int price;
  final String? slot; // equip slot, null = consumable / owned pack
  final String? setId, glyph, desc, kind;
  final int qty;
  final List<Color>? frameC, boardC, carromC, faceC;
  final Color? cell, pip, color;
  final bool double_;
  final List<String>? emojis, pieces;
  const Item(this.id, this.name, this.cat, this.price, this.rarity,
      {this.slot, this.setId, this.glyph, this.desc, this.kind, this.qty = 0, this.frameC, this.boardC, this.carromC, this.faceC, this.cell, this.pip, this.color, this.double_ = false, this.emojis, this.pieces});
}

const themes = [
  Item('classic', 'Classic', 'boards', 0, 'common', slot: 'board', frameC: [Color(0xFF4A3F7C), Color(0xFF1E1937)], boardC: [Color(0xFFFFFDF6), Color(0xFFEBE0C8)], carromC: [Color(0xFFF4E1BC), Color(0xFFDDBF8E)], cell: Color(0xFFFFFDF6)),
  Item('midnight', 'Midnight', 'boards', 600, 'rare', slot: 'board', frameC: [Color(0xFF1B1B2F), Color(0xFF0B0B16)], boardC: [Color(0xFF2A2747), Color(0xFF1C1A33)], carromC: [Color(0xFF3A3557), Color(0xFF2A2747)], cell: Color(0xFF3A3557)),
  Item('marigold', 'Marigold', 'boards', 600, 'rare', slot: 'board', frameC: [Color(0xFF8A4B12), Color(0xFF4A2607)], boardC: [Color(0xFFFFF1D6), Color(0xFFF5D9A6)], carromC: [Color(0xFFF7D89A), Color(0xFFE5B96A)], cell: Color(0xFFFFF6E3)),
  Item('jade', 'Jade', 'boards', 800, 'epic', slot: 'board', frameC: [Color(0xFF1F5B46), Color(0xFF0E2E23)], boardC: [Color(0xFFEEF8F0), Color(0xFFCFE8D6)], carromC: [Color(0xFFDDEFDF), Color(0xFFBFDCC6)], cell: Color(0xFFF3FAF4)),
  Item('marble', 'Marble', 'boards', 1000, 'epic', slot: 'board', frameC: [Color(0xFF6E7480), Color(0xFF2E323B)], boardC: [Color(0xFFFAFAFA), Color(0xFFDCDCE0)], carromC: [Color(0xFFECECEE), Color(0xFFD6D6DA)], cell: Color(0xFFFFFFFF)),
  Item('festival', 'Festival', 'boards', 1000, 'epic', slot: 'board', frameC: [Color(0xFF7A2A6B), Color(0xFF3A1233)], boardC: [Color(0xFFFFF0F7), Color(0xFFF6D3E6)], carromC: [Color(0xFFF9D9EA), Color(0xFFEBB8D2)], cell: Color(0xFFFFF4FA)),
  Item('diwali', 'Diwali Lights', 'boards', 1800, 'legendary', slot: 'board', setId: 'diwali', frameC: [Color(0xFFB3541E), Color(0xFF3F1B08)], boardC: [Color(0xFFFFF3D6), Color(0xFFF5CF8A)], carromC: [Color(0xFFF8D28C), Color(0xFFE2A54F)], cell: Color(0xFFFFF7E4)),
];
const diceSkins = [
  Item('ivory', 'Ivory', 'dice', 0, 'common', slot: 'dice', faceC: [Color(0xFFFFFEF9), Color(0xFFDCD1B6)], pip: Color(0xFF2A2247)),
  Item('brass', 'Brass', 'dice', 400, 'rare', slot: 'dice', faceC: [Color(0xFFFFE9A6), Color(0xFFC9973F)], pip: Color(0xFF3A2208)),
  Item('obsidian', 'Obsidian', 'dice', 500, 'rare', slot: 'dice', faceC: [Color(0xFF4A4460), Color(0xFF15121F)], pip: T.yellow),
  Item('rose', 'Rose', 'dice', 500, 'rare', slot: 'dice', faceC: [Color(0xFFFFD1DC), Color(0xFFE8748F)], pip: Colors.white),
  Item('ocean', 'Ocean', 'dice', 600, 'epic', slot: 'dice', faceC: [Color(0xFFBFE6FF), T.blue], pip: Color(0xFF0B1E3A)),
  Item('neon', 'Neon', 'dice', 700, 'epic', slot: 'dice', faceC: [Color(0xFF1E2A2A), Color(0xFF0B1414)], pip: Color(0xFF3FFFB0)),
  Item('diya', 'Diya', 'dice', 1200, 'legendary', slot: 'dice', setId: 'diwali', faceC: [Color(0xFFFFD27A), Color(0xFFC4611C)], pip: Color(0xFF5A1B00)),
];
const pawnStyles = [
  Item('classic', 'Classic pawn', 'pawns', 0, 'common', slot: 'pawn'), Item('disc', 'Flat disc', 'pawns', 300, 'common', slot: 'pawn'),
  Item('pin', 'Map pin', 'pawns', 450, 'rare', slot: 'pawn'), Item('crown', 'Crowned', 'pawns', 900, 'epic', slot: 'pawn'),
];
const strikers = [
  Item('gold', 'Gold', 'strikers', 0, 'common', slot: 'striker', color: T.yellow), Item('ruby', 'Ruby', 'strikers', 350, 'rare', slot: 'striker', color: T.red),
  Item('sapphire', 'Sapphire', 'strikers', 350, 'rare', slot: 'striker', color: T.blue), Item('emerald', 'Emerald', 'strikers', 350, 'rare', slot: 'striker', color: T.green),
  Item('ivory_s', 'Ivory', 'strikers', 450, 'epic', slot: 'striker', color: Color(0xFFF2EDE3)), Item('violet', 'Violet', 'strikers', 550, 'epic', slot: 'striker', color: T.violet),
];
const frames = [
  Item('none', 'No frame', 'frames', 0, 'common', slot: 'frame'),
  Item('brass_f', 'Brass ring', 'frames', 500, 'rare', slot: 'frame', color: T.yellow),
  Item('neon_f', 'Neon', 'frames', 700, 'rare', slot: 'frame', color: Color(0xFF3FFFB0)),
  Item('royal', 'Royal', 'frames', 1200, 'epic', slot: 'frame', color: T.violet, double_: true),
  Item('flame', 'Flame', 'frames', 1500, 'legendary', slot: 'frame', color: Color(0xFFFF7A45), double_: true),
  Item('diwaliframe', 'Lamp halo', 'frames', 1500, 'legendary', slot: 'frame', setId: 'diwali', color: Color(0xFFFFB347), double_: true),
];
const emotePacks = [
  Item('em_party', 'Party pack', 'emotes', 250, 'rare', glyph: '🥳', emojis: ['🎉', '🥳', '😎', '🤯']),
  Item('em_savage', 'Savage pack', 'emotes', 300, 'rare', glyph: '😈', emojis: ['😈', '🫣', '🤡', '👀']),
  Item('em_desi', 'Desi pack', 'emotes', 350, 'epic', glyph: '🕺', emojis: ['🪔', '🎶', '🕺', '🍬']),
];
const victoryFx = [
  Item('fx_confetti', 'Confetti', 'fx', 0, 'common', slot: 'fx', glyph: '🎊'),
  Item('fx_petals', 'Marigold rain', 'fx', 500, 'rare', slot: 'fx', glyph: '🌼', pieces: ['🌼', '🌸', '🧡']),
  Item('fx_coins', 'Coin shower', 'fx', 800, 'epic', slot: 'fx', glyph: '🪙', pieces: ['🪙', '✨', '💰']),
  Item('fx_fire', 'Fireworks', 'fx', 1200, 'legendary', slot: 'fx', glyph: '🎆', pieces: ['🎆', '🎇', '✨', '💥']),
];
const bundles = [
  Item('reroll5', '5 re-rolls', 'bundles', 80, 'common', glyph: '↻', kind: 'reroll', qty: 5, desc: 'Use instead of paying 20. Save 20.'),
  Item('reroll20', '20 re-rolls', 'bundles', 280, 'rare', glyph: '↻', kind: 'reroll', qty: 20, desc: 'Bulk pack. Save 120.'),
  Item('chatday', 'Chat day pass', 'bundles', 150, 'common', glyph: '💬', kind: 'chat', desc: 'Unlimited rooms until midnight.'),
];
class Cat { final String id, name; final List<Item> items; const Cat(this.id, this.name, this.items); }
const cats = [
  Cat('dice', 'Dice', diceSkins), Cat('boards', 'Boards', themes), Cat('pawns', 'Pawns', pawnStyles), Cat('strikers', 'Strikers', strikers),
  Cat('frames', 'Frames', frames), Cat('emotes', 'Emotes', emotePacks), Cat('fx', 'Victory', victoryFx), Cat('bundles', 'Bundles', bundles),
];
List<Item> get allItems => [for (final c in cats) ...c.items];
Item? itemById(String id) { for (final i in allItems) { if (i.id == id) return i; } return null; }
Item themeOf(String id) => themes.firstWhere((t) => t.id == id, orElse: () => themes[0]);
Item diceSkinOf(String id) => diceSkins.firstWhere((t) => t.id == id, orElse: () => diceSkins[0]);
Item strikerOf(String id) => strikers.firstWhere((t) => t.id == id, orElse: () => strikers[0]);
Item frameOf(String id) => frames.firstWhere((t) => t.id == id, orElse: () => frames[0]);
Item fxOf(String id) => victoryFx.firstWhere((t) => t.id == id, orElse: () => victoryFx[0]);

class Equip {
  String dice, board, pawn, striker, frame, fx;
  Equip({this.dice = 'ivory', this.board = 'classic', this.pawn = 'classic', this.striker = 'gold', this.frame = 'none', this.fx = 'fx_confetti'});
  Map<String, dynamic> toJson() => {'dice': dice, 'board': board, 'pawn': pawn, 'striker': striker, 'frame': frame, 'fx': fx};
  static Equip fromJson(Map? m) => Equip(dice: m?['dice'] ?? 'ivory', board: m?['board'] ?? 'classic', pawn: m?['pawn'] ?? 'classic', striker: m?['striker'] ?? 'gold', frame: m?['frame'] ?? 'none', fx: m?['fx'] ?? 'fx_confetti');
  String get(String slot) => switch (slot) { 'dice' => dice, 'board' => board, 'pawn' => pawn, 'striker' => striker, 'frame' => frame, _ => fx };
  void set(String slot, String id) { switch (slot) { case 'dice': dice = id; case 'board': board = id; case 'pawn': pawn = id; case 'striker': striker = id; case 'frame': frame = id; default: fx = id; } }
}

const collection = (id: 'diwali', name: 'Diwali Lights', ends: '31 Oct', items: ['diwali', 'diya', 'diwaliframe']);

/* ---------------- season pass ---------------- */
const passXpPerLevel = 300, passLevels = 10, passPrice = 1500;
const seasonName = 'Season 1 · Monsoon', seasonEnds = '30 Sep';
class Reward { final int coins, reroll; final String? item, title; const Reward({this.coins = 0, this.reroll = 0, this.item, this.title});
  String label() => coins > 0 ? '$coins 🪙' : reroll > 0 ? '$reroll ↻' : (itemById(item ?? '')?.name ?? ''); }
class PassLevel { final Reward free, prem; const PassLevel(this.free, this.prem); }
const passTrack = [
  PassLevel(Reward(coins: 50), Reward(coins: 150)), PassLevel(Reward(coins: 80), Reward(item: 'rose')),
  PassLevel(Reward(reroll: 3), Reward(coins: 300)), PassLevel(Reward(coins: 100), Reward(item: 'disc')),
  PassLevel(Reward(item: 'brass'), Reward(coins: 400)), PassLevel(Reward(coins: 120), Reward(item: 'marigold')),
  PassLevel(Reward(reroll: 5), Reward(item: 'neon')), PassLevel(Reward(coins: 150), Reward(coins: 600)),
  PassLevel(Reward(coins: 200), Reward(item: 'crown')), PassLevel(Reward(coins: 300), Reward(item: 'festival', title: 'Monsoon Legend')),
];
const dailyCoins = [30, 40, 50, 60, 80, 100, 200];
const spinWheel = [20, 50, 100, 30, 200, 40, 500, 60];

/* ---------------- chat ---------------- */
class Room {
  final String id, name, topic, glyph;
  final int cost, live;
  final Color color;
  final String? gate;
  final Map<String, int> vibe;
  final List<String> tags;
  const Room(this.id, this.name, this.topic, this.cost, this.live, this.color, this.glyph, this.vibe, this.tags, {this.gate});
}
const rooms = [
  Room('ludo', 'Ludo Lobby', 'Tactics, cuts and bad luck', 50, 214, T.red, '🎲', {'dreamer': 5, 'steady': 4, 'warm': 3}, ['🔥 buzzing', 'Ludo']),
  Room('carrom', 'Carrom Corner', 'Angles, covers, trick shots', 50, 138, T.yellow, '⭕', {'dreamer': 3, 'steady': 6, 'warm': 3}, ['Carrom', 'Tips']),
  Room('new', "Beginners' Adda", 'New players, slow lane, no judging', 30, 96, T.green, '👋', {'dreamer': 2, 'steady': 4, 'warm': 7}, ['Friendly', 'New']),
  Room('cup', 'Cup Talk', "This week's tables and who's climbing", 60, 71, T.blue, '🏆', {'dreamer': 7, 'steady': 3, 'warm': 4}, ['Cups', 'Rankings']),
  Room('late', 'Late Night Baithak', 'After 10pm crowd. Chill.', 40, 52, T.violet, '🌙', {'dreamer': 6, 'steady': 3, 'warm': 6}, ['Chill', 'Night']),
  Room('turtleroom', 'Turtle Shell', 'Turtle players and above', 0, 44, T.green, '🐢', {'dreamer': 3, 'steady': 7, 'warm': 5}, ['Turtle+'], gate: 'turtle'),
  Room('owlroom', 'Owl Perch', 'Owl players and above', 0, 19, Color(0xFFE7A94F), '🦉', {'dreamer': 5, 'steady': 6, 'warm': 4}, ['Owl+'], gate: 'owl'),
  Room('lionroom', "Lion's Den", 'Lion players only', 0, 7, T.yellow, '🦁', {'dreamer': 7, 'steady': 3, 'warm': 6}, ['Lion'], gate: 'lion'),
];
const chatEmoji = ['👍', '😂', '😮', '🔥', '😭', '🙏', '🎲', '👏'];
const quickSay = ['Arre yaar! 😩', 'Kya luck hai 🔥', 'Bach ke rehna 👀', 'Wah bhai wah 👏', 'GG 🤝', 'Ek aur? 🔁', 'Jaldi karo ⏳', 'Nice move 💯'];
const wordCost = 2;
const botReplies = ['Haha same 😂', "I'm in, send a challenge", 'Facts.', 'GG 👏', 'Which format?', 'Welcome! 👋', "Let's go 🔥", "That's the spirit"];
const curatedLines = ['Kya scene hai aaj?', 'Anyone up for Score Rush?', 'That cut was brutal 😭', 'Carrom cup this week, who is in?', 'Good game everyone 🙏'];

class Filter { final RegExp re; final String why; final int sev; Filter(this.re, this.why, [this.sev = 1]); }
final filters = [
  Filter(RegExp(r'(\+?\d[\d\s\-().]{7,}\d)'), 'phone numbers'),
  Filter(RegExp(r'[\w.+-]+@[\w-]+\.[a-z]{2,}', caseSensitive: false), 'email addresses'),
  Filter(RegExp(r'(https?://|www\.|\.com|\.in\b|\.net\b|t\.me|wa\.me)', caseSensitive: false), 'links'),
  Filter(RegExp(r'\b[\w.-]{3,}@(ybl|okaxis|okhdfcbank|oksbi|okicici|paytm|upi|apl)\b', caseSensitive: false), 'UPI IDs'),
  Filter(RegExp(r'\b(f+u+c*k+\w*|sh+i+t+\w*|b+i+t+ch\w*|a+ss+h+o+le\w*|b+a+st+a+rd\w*|c+u+n+t\w*|s+l+u+t\w*|wh+o+re\w*)\b'), 'abusive language'),
  Filter(RegExp(r'\b(ch+u+t+i+y+a+|m+a+d+a+r+ch+o+d+|b+e+h+e+n+ch+o+d+|g+a+n+d+u+|b+h+o+s+d+i+|r+a+n+d+i+|l+a+u+d+a+)\w*', caseSensitive: false), 'abusive language', 2),
  // zero tolerance (3): block + strike + account flagged for review
  Filter(RegExp(r'\b(c+p+|ch+i+l+d+ *p+o+r+n\w*|p+e+d+o+\w*|(nude|naked|sexy|hot|porn|sex|xxx)\W+(?:\w+\W+){0,3}(kid|child|children|bacch[ae]|minor|teen|beti|beta)s?|(kid|child|children|bacch[ae]|minor|teen)s?\W+(?:\w+\W+){0,3}(nude|naked|sexy|hot|porn|sex|xxx|pics?))\b', caseSensitive: false), 'child safety violation', 3),
  Filter(RegExp(r'\b(r+a+p+e+ *(you|u|her|him|kar|karunga|karenge)|g+a+n+g+ *r+a+p+e+|(behead|lynch)\w*|(shoot|stab|bomb) *(you|u|them|school|temple|mosque|church)|m+a+a+r+ *d+a+l+[ou]+n+g+[ae]+)\b', caseSensitive: false), 'violent threats', 3),
  Filter(RegExp(r'\b(k+i+l+l+ *y+o+u+r+s+e+l+f|(cut|hang|hurt) *(yourself|urself)|s+u+i+c+i+d+e+ *(kar|karlo|method|how)|m+a+r+ *j+a+o*)\b', caseSensitive: false), 'self-harm content', 3),
  Filter(RegExp(r'\b(x+x+x+|c+h+u+d+a+i+\w*|c+h+o+d+n+a+|s+u+c+k+ *m+y+|b+l+o+w+j+o+b+\w*|d+i+c+k+ *p+i+c+s*|n+a+n+g+[ai]+ *p+i+c+s*|s+e+x+ *c+h+a+t+|o+n+l+y+f+a+n+s+|e+s+c+o+r+t+s*|c+a+l+l+ *g+i+r+l+s*|p+o+r+n+\w*)\b', caseSensitive: false), 'pornographic content', 3),
  Filter(RegExp(r'\b(k+a+t+u+[ae]+|m+u+l+l+[ae]+|ch+a+m+a+r+\w*|bh+a+n+g+i+\w*|(hindu|muslim|sikh|christian|dalit)s? *(ko|are|sab) *(maro|kill|terrorist|dogs?))\b', caseSensitive: false), 'hateful language', 3),
];
String normText(String t) => t.toLowerCase().replaceAll('@', 'a').replaceAll('0', 'o').replaceAll(RegExp(r'[1!|]'), 'i').replaceAll('3', 'e').replaceAll(RegExp(r'[\$5]'), 's').replaceAll('7', 't').replaceAll('4', 'a').replaceAll(RegExp(r'[.\-_*\s]+(?=\w)'), '').replaceAll(RegExp(r'(.)\1{2,}'), r'$1$1');
/// Returns null when OK, else (why, sev).
/// Returns null when OK, else (why, severity): 1 block · 2 block + strike · 3 zero tolerance (block + strike + flag).
(String, int)? moderate(String text) {
  final raw = text.toLowerCase(), nx = normText(text), squashed = nx.replaceAll(RegExp(r'\s+'), '');
  final ordered = [...filters]..sort((a, b) => b.sev.compareTo(a.sev));
  for (final f in ordered) { if (f.re.hasMatch(raw) || f.re.hasMatch(nx) || (f.sev >= 2 && f.re.hasMatch(squashed))) return (f.why, f.sev); }
  return null;
}

/* ---------------- profile vocabulary ---------------- */
const interests = ['Cricket', 'Music', 'Movies', 'Cooking', 'Travel', 'Books', 'Tech', 'Art', 'Fitness', 'Photography'];
const hobbies = ['Chess', 'Sketching', 'Gardening', 'Dancing', 'Writing', 'Cycling', 'Singing', 'Puzzles'];
class Quiz { final String q; final List<(String, String)> a; const Quiz(this.q, this.a); }
const quiz = [
  Quiz('What do you think of yourself?', [('Creative', 'dreamer'), ('Introvert', 'steady'), ('Outspoken', 'warm')]),
  Quiz('Pick a Friday evening.', [('A loud tournament bracket', 'dreamer'), ('A quiet board and a cup of chai', 'steady'), ('A long call with friends', 'warm')]),
  Quiz('Your Ludo style?', [('Go for every cut', 'dreamer'), ('Guard and wait', 'steady'), ('Chat more than play', 'warm')]),
];
const vibeNames = {'dreamer': 'Dreamer', 'steady': 'Steady', 'warm': 'Warm'};
const reservedNames = ['chaupal', 'admin', 'moderator', 'mod', 'support', 'official', 'staff', 'lion', 'owl', 'turtle'];
const takenNames = ['rhea_09', 'saifplays', 'nandu', 'tinydice', 'meerak', 'abhi_7', 'golu', 'zoya', 'kabir', 'ludoking', 'carromking', 'aarav', 'diya', 'ishaan', 'ananya', 'simran', 'raj'];
String? checkName(String raw) {
  final n = raw.trim();
  if (n.isEmpty) return 'Enter a name.';
  if (n.length < 3) return 'At least 3 characters.';
  if (n.length > 16) return 'At most 16 characters.';
  if (!RegExp(r'^[A-Za-z][A-Za-z0-9_]*$').hasMatch(n)) return 'Letters, numbers and _ only. Start with a letter.';
  if (reservedNames.contains(n.toLowerCase())) return 'That name is reserved.';
  if (takenNames.contains(n.toLowerCase())) return 'Taken — try another.';
  if (moderate(n) != null) return 'Keep it clean.';
  return null;
}

String levelTitle(int l) => l >= 30 ? 'Legend' : l >= 20 ? 'Master' : l >= 12 ? 'Veteran' : l >= 6 ? 'Sharp' : l >= 3 ? 'Regular' : 'Rookie';
