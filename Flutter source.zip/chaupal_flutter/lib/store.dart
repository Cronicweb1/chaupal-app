import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';
import 'adda_state.dart' show AddaState;
import 'backend.dart';

class Profile {
  String name = '', avatar = 'f1', age = '', pronoun = '', sex = '';
  bool nameLocked = false, ageLocked = false, everMinor = false, showSex = false;
  List<String> interests = [], hobbies = [];
  Map<String, String> quiz = {}; // question index -> vibe key
  Map<String, dynamic> toJson() => {'name': name, 'avatar': avatar, 'age': age, 'pronoun': pronoun, 'sex': sex, 'nameLocked': nameLocked, 'ageLocked': ageLocked, 'everMinor': everMinor, 'showSex': showSex, 'interests': interests, 'hobbies': hobbies, 'quiz': quiz};
  static Profile fromJson(Map? m) {
    final p = Profile();
    if (m == null) return p;
    p.name = m['name'] ?? ''; p.avatar = m['avatar'] ?? 'f1'; p.age = '${m['age'] ?? ''}'; p.pronoun = m['pronoun'] ?? ''; p.sex = m['sex'] ?? '';
    p.nameLocked = m['nameLocked'] == true; p.ageLocked = m['ageLocked'] == true; p.everMinor = m['everMinor'] == true; p.showSex = m['showSex'] == true;
    p.interests = List<String>.from(m['interests'] ?? []); p.hobbies = List<String>.from(m['hobbies'] ?? []);
    p.quiz = Map<String, String>.from(m['quiz'] ?? {});
    return p;
  }
}

class Stats { int played = 0, wins = 0, xp = 0; Map<String, List<int>> byGame = {}; // id -> [played, wins]
  Map<String, dynamic> toJson() => {'played': played, 'wins': wins, 'xp': xp, 'byGame': byGame};
  static Stats fromJson(Map? m) { final s = Stats(); if (m == null) return s; s.played = m['played'] ?? 0; s.wins = m['wins'] ?? 0; s.xp = m['xp'] ?? 0;
    (m['byGame'] as Map? ?? {}).forEach((k, v) => s.byGame['$k'] = List<int>.from(v)); return s; } }

class HistoryItem { final String game; final int rank, pay, ts; HistoryItem(this.game, this.rank, this.pay, this.ts);
  Map<String, dynamic> toJson() => {'game': game, 'rank': rank, 'pay': pay, 'ts': ts};
  static HistoryItem fromJson(Map m) => HistoryItem(m['game'] ?? 'ludo', m['rank'] ?? 0, m['pay'] ?? 0, m['ts'] ?? 0); }

class CupEntry { String week; int pts; bool settled; int? finalRank; CupPrize? prize;
  CupEntry(this.week, this.pts, {this.settled = false, this.finalRank, this.prize});
  Map<String, dynamic> toJson() => {'week': week, 'pts': pts, 'settled': settled, 'finalRank': finalRank, 'prizeRank': prize == null ? null : finalRank};
  static CupEntry fromJson(Map m) { final e = CupEntry(m['week'] ?? '', m['pts'] ?? 0, settled: m['settled'] == true, finalRank: m['finalRank']);
    if (m['prizeRank'] != null) e.prize = prizeForRank(m['prizeRank']); return e; } }

class Mission { final String id, name; final int reward, need; final int Function(AppStore) have; const Mission(this.id, this.name, this.reward, this.need, this.have); }
final missions = [
  Mission('play3', 'Play 3 games', 30, 3, (s) => s.gamesToday),
  Mission('win1', 'Win a game', 50, 1, (s) => s.winsToday),
  Mission('mix2', 'Play 2 different boards', 40, 2, (s) => s.gamesTodayIds.length),
];
class Achievement { final String id, glyph, name, how; final int coins, xp; final bool Function(AppStore) test; const Achievement(this.id, this.glyph, this.name, this.how, this.coins, this.xp, this.test); }
final badges = [
  Achievement('firstwin', '🥇', 'First blood', 'Win a game', 50, 100, (s) => s.stats.wins >= 1),
  Achievement('ten', '🎲', 'Regular', 'Play 10 games', 100, 150, (s) => s.stats.played >= 10),
  Achievement('fifty', '🔥', 'Grinder', 'Play 50 games', 300, 400, (s) => s.stats.played >= 50),
  Achievement('sharp', '🎯', 'Sharp', 'Win rate over 50% after 10 games', 200, 250, (s) => s.stats.played >= 10 && s.stats.wins / s.stats.played > .5),
  Achievement('streak3', '⚡', 'On a roll', 'Play 3 days in a row', 150, 200, (s) => s.liveStreak >= 3),
  Achievement('vibe', '🌀', 'Vibe checked', 'Finish the vibe check', 100, 100, (s) => s.vibe != null),
  Achievement('skin', '🦚', 'Dressed up', 'Wear any skin', 100, 150, (s) => s.tier != 'rookie'),
  Achievement('recruit', '🤝', 'Recruiter', 'Bring a friend in', 200, 200, (s) => s.refsTotal >= 1),
  Achievement('rich', '💰', 'Loaded', 'Hold 5,000 coins', 250, 300, (s) => s.coins >= 5000),
];

String dayKeyOf(DateTime d) => '${d.year}-${d.month}-${d.day}';
String todayKey() => dayKeyOf(DateTime.now());
DateTime weekStart([DateTime? d]) { final t = d ?? DateTime.now(); final day = (t.weekday + 6) % 7; return DateTime(t.year, t.month, t.day).subtract(Duration(days: day)); }
String weekKey([DateTime? d]) => dayKeyOf(weekStart(d));
DateTime weekEnd([DateTime? d]) => weekStart(d).add(const Duration(days: 7));

class CupRow { final String name; final int pts; TableRow(this.name, this.pts); }

/// Deterministic bot standings for a cup that drift upward through the week.
List<CupRow> cupTable(String cupId, String wk) {
  var seed = 0;
  for (final ch in (cupId + wk).codeUnits) { seed = (seed * 31 + ch) & 0xFFFFFFFF; }
  double rnd() { seed = (seed * 1664525 + 1013904223) & 0xFFFFFFFF; return seed / 4294967296; }
  final dayFrac = (DateTime.now().difference(weekStart()).inMinutes / (7 * 24 * 60)).clamp(0.05, 1.0);
  final names = ['Rhea_09', 'SaifPlays', 'Nandu', 'TinyDice', 'MeeraK', 'Abhi_7', 'Golu', 'Zoya', 'Kabir', 'LudoKing', 'CarromKing', 'Aarav', 'Diya', 'Ishaan', 'Ananya', 'Simran', 'Raj', 'Rev', 'Pooja', 'Vikram'];
  final rows = [for (final n in names) CupRow(n, (rnd() * 260 * dayFrac).round() + (rnd() * 20).round())];
  rows.sort((a, b) => b.pts.compareTo(a.pts));
  return rows;
}

class CupReward { final String name; final int cp; CupReward(this.name, this.cp); }
class Rewards { final int trophies; final List<CupReward> cups; Rewards(this.trophies, this.cups); }

String makeRefCode() { const a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; final r = Random(); return 'CHP-${List.generate(5, (_) => a[r.nextInt(a.length)]).join()}'; }

class AppStore extends ChangeNotifier {
  static const key = 'chaupal:save:v3';
  int coins = 0, trophies = 0, gamesToday = 0, winsToday = 0, freeChatUsed = 0, refsToday = 0, refsTotal = 0, streak = 0, rerolls = 0, strikes = 0, playMins = 0;
  Profile profile = Profile();
  Stats stats = Stats();
  List<String> owned = [], claimed = [], badgesClaimed = [], gamesTodayIds = [], tierBought = [];
  String tier = 'rookie', dayKey = todayKey(), refCode = makeRefCode(), refRedeemed = '', chatPassDay = '', spinDay = '', toast = '';
  bool grace = false, onboarded = false, welcomePaid = false, tourPaid = false, ready = false, soundOn = true;
  List<HistoryItem> history = [];
  Map<String, CupEntry> cupState = {};
  Equip equipped = Equip();
  int passXp = 0; bool passPremium = false; List<String> passClaimed = [];
  int dailyDay = 0; String dailyLast = '';
  AddaState adda = AddaState();
  Timer? _saveT, _toastT;

  Tier get tr => tierOf(tier);
  int get age => int.tryParse(profile.age) ?? 0;
  bool get ageKnown => age > 0;
  bool get chatAllowed => ageKnown && age >= 18 && !profile.everMinor;
  int get liveStreak => streak + (gamesToday > 0 ? 1 : 0);
  bool get chatPass => chatPassDay == todayKey();
  bool get spinDone => spinDay == todayKey();
  int get level => stats.xp ~/ 500 + 1;
  int get passLevel => (passXp ~/ passXpPerLevel).clamp(0, passLevels).toInt();

  /// Dominant vibe from the quiz, or null when incomplete.
  String? get vibe {
    if (profile.quiz.length < quiz.length) return null;
    final c = <String, int>{};
    for (final v in profile.quiz.values) { c[v] = (c[v] ?? 0) + 1; }
    return c.entries.reduce((a, b) => b.value > a.value ? b : a).key;
  }
  int matchPct(Room r) {
    final v = vibe; if (v == null) return -1;
    final mine = <String, int>{'dreamer': 0, 'steady': 0, 'warm': 0};
    for (final x in profile.quiz.values) { mine[x] = (mine[x] ?? 0) + 3; }
    var dot = 0, na = 0, nb = 0;
    for (final k in mine.keys) { final a = mine[k]!, b = r.vibe[k] ?? 0; dot += a * b; na += a * a; nb += b * b; }
    if (na == 0 || nb == 0) return -1;
    return (100 * dot / (sqrt(na) * sqrt(nb))).round();
  }

  /// Remote mode: server is the source of truth. Pull /v1/me and overwrite local fields.
  Future<void> syncRemote() async {
    if (!Backend.on || !Backend.signedIn) return;
    try { applyMe(await Backend.get('/v1/me')); } catch (e) { showToast('Offline · ${e is ApiException ? e.message : 'no connection'}', 3000); }
  }
  void applyMe(dynamic j) {
    if (j is! Map) return;
    final p = j['profile'] as Map? ?? {};
    coins = (j['balance'] as num? ?? coins).toInt(); rerolls = (j['rerolls'] as num? ?? rerolls).toInt();
    profile.name = p['username'] ?? ''; profile.nameLocked = p['name_locked'] == true; profile.avatar = p['avatar'] ?? profile.avatar;
    profile.age = p['age'] == null ? '' : '${p['age']}'; profile.ageLocked = p['age_locked'] == true; profile.everMinor = p['ever_minor'] == true;
    profile.interests = List<String>.from(p['interests'] ?? []); profile.hobbies = List<String>.from(p['hobbies'] ?? []); profile.quiz = Map<String, String>.from(p['quiz'] ?? {});
    tier = p['tier'] ?? tier; tierBought = List<String>.from(p['tier_bought'] ?? []); grace = p['grace'] == true;
    streak = (p['streak'] as num? ?? 0).toInt(); gamesToday = (p['games_today'] as num? ?? 0).toInt(); winsToday = (p['wins_today'] as num? ?? 0).toInt(); gamesTodayIds = List<String>.from(p['games_today_ids'] ?? []);
    freeChatUsed = (p['free_chat_used'] as num? ?? 0).toInt(); refsToday = (p['refs_today'] as num? ?? 0).toInt(); strikes = (p['strikes'] as num? ?? 0).toInt();
    stats.xp = (p['xp'] as num? ?? 0).toInt(); stats.played = (p['played'] as num? ?? 0).toInt(); stats.wins = (p['wins'] as num? ?? 0).toInt(); trophies = (p['trophies'] as num? ?? 0).toInt();
    stats.byGame = {for (final e in (p['by_game'] as Map? ?? {}).entries) '${e.key}': [(e.value['played'] as num).toInt(), (e.value['wins'] as num).toInt()]};
    playMins = (p['play_mins'] as num? ?? 0).toInt(); refCode = p['ref_code'] ?? refCode; refRedeemed = p['ref_redeemed'] ?? ''; onboarded = p['onboarded'] == true; tourPaid = p['tour_paid'] == true; welcomePaid = true;
    equipped = Equip.fromJson(p['equipped']); passXp = (p['pass_xp'] as num? ?? 0).toInt(); passPremium = p['pass_premium'] == true; passClaimed = List<String>.from(p['pass_claimed'] ?? []);
    dailyDay = (p['daily_day'] as num? ?? 0).toInt(); dailyLast = p['daily_last'] ?? ''; spinDay = p['spin_day'] ?? ''; chatPassDay = p['chat_pass_day'] ?? ''; soundOn = p['sound_on'] != false;
    owned = List<String>.from(j['inventory'] ?? []); adda.unlocked = p['adda_unlocked'] == true || adda.unlocked;
    if (j['toast'] is String && (j['toast'] as String).isNotEmpty) showToast(j['toast'], 4000);
    ready = true; notifyListeners();
  }
  /// Fire a server mutation, then re-sync. Errors surface as toasts; local state is the optimistic guess until the sync lands.
  Future<void> remote(Future<dynamic> Function() f) async {
    if (!Backend.on) return;
    try { await f(); } catch (e) { showToast(e is ApiException ? e.message : 'Could not reach the server', 3000); }
    await syncRemote();
  }

  Future<void> load() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString(key);
      if (raw != null) {
        final s = jsonDecode(raw) as Map;
        coins = s['coins'] ?? 0; trophies = s['trophies'] ?? 0; gamesToday = s['gamesToday'] ?? 0; winsToday = s['winsToday'] ?? 0;
        freeChatUsed = s['freeChatUsed'] ?? 0; refsToday = s['refsToday'] ?? 0; refsTotal = s['refsTotal'] ?? 0; streak = s['streak'] ?? 0;
        rerolls = s['rerolls'] ?? 0; strikes = s['strikes'] ?? 0; playMins = s['playMins'] ?? 0;
        profile = Profile.fromJson(s['profile']); stats = Stats.fromJson(s['stats']);
        owned = List<String>.from(s['owned'] ?? []); claimed = List<String>.from(s['claimed'] ?? []); badgesClaimed = List<String>.from(s['badgesClaimed'] ?? []);
        gamesTodayIds = List<String>.from(s['gamesTodayIds'] ?? []); tierBought = List<String>.from(s['tierBought'] ?? []);
        tier = tierOf(s['tier'] ?? 'rookie').id; dayKey = s['dayKey'] ?? todayKey(); refCode = s['refCode'] ?? refCode; refRedeemed = s['refRedeemed'] ?? '';
        chatPassDay = s['chatPassDay'] ?? ''; spinDay = s['spinDay'] ?? '';
        grace = s['grace'] == true; onboarded = s['onboarded'] == true; welcomePaid = s['welcomePaid'] == true; tourPaid = s['tourPaid'] == true; soundOn = s['soundOn'] != false;
        history = [for (final h in (s['history'] ?? [])) HistoryItem.fromJson(h)];
        (s['cups'] as Map? ?? {}).forEach((k, v) => cupState['$k'] = CupEntry.fromJson(v));
        equipped = Equip.fromJson(s['equipped']);
        passXp = s['passXp'] ?? 0; passPremium = s['passPremium'] == true; passClaimed = List<String>.from(s['passClaimed'] ?? []);
        dailyDay = s['dailyDay'] ?? 0; dailyLast = s['dailyLast'] ?? '';
        adda = AddaState.fromJson(s['adda']);
      }
    } catch (_) {/* fresh start */}
    if (!welcomePaid) { coins += 100; welcomePaid = true; }
    rollover();
    settleCups();
    ready = true;
    notifyListeners();
    save();
  }

  void save() {
    _saveT?.cancel();
    _saveT = Timer(const Duration(milliseconds: 400), () async {
      final sp = await SharedPreferences.getInstance();
      await sp.setString(key, jsonEncode({
        'coins': coins, 'trophies': trophies, 'gamesToday': gamesToday, 'winsToday': winsToday, 'freeChatUsed': freeChatUsed, 'refsToday': refsToday, 'refsTotal': refsTotal,
        'streak': streak, 'rerolls': rerolls, 'strikes': strikes, 'playMins': playMins, 'profile': profile.toJson(), 'stats': stats.toJson(), 'owned': owned, 'claimed': claimed,
        'badgesClaimed': badgesClaimed, 'gamesTodayIds': gamesTodayIds, 'tierBought': tierBought, 'tier': tier, 'dayKey': dayKey, 'refCode': refCode, 'refRedeemed': refRedeemed,
        'chatPassDay': chatPassDay, 'spinDay': spinDay, 'grace': grace, 'onboarded': onboarded, 'welcomePaid': welcomePaid, 'tourPaid': tourPaid, 'soundOn': soundOn,
        'history': [for (final h in history) h.toJson()], 'cups': {for (final e in cupState.entries) e.key: e.value.toJson()}, 'equipped': equipped.toJson(),
        'passXp': passXp, 'passPremium': passPremium, 'passClaimed': passClaimed, 'dailyDay': dailyDay, 'dailyLast': dailyLast, 'adda': adda.toJson(),
      }));
    });
  }

  void _commit() { notifyListeners(); save(); }

  void showToast(String msg, [int ms = 2400]) {
    toast = msg; notifyListeners();
    _toastT?.cancel();
    _toastT = Timer(Duration(milliseconds: ms), () { toast = ''; notifyListeners(); });
  }

  /// Daily rollover: status upkeep, streak, counters.
  void rollover() {
    final today = todayKey();
    if (dayKey == today) return;
    final t = tr;
    if (t.upkeep > 0 && gamesToday < t.upkeep) {
      if (grace) { tier = 'elephant'; grace = false; showToast('${t.name} status lapsed — you are back to Elephant', 4000); }
      else { grace = true; showToast('${t.name} needs ${t.upkeep} games a day. One warning day left.', 4000); }
    } else { grace = false; }
    DateTime? prev;
    try { final p = dayKey.split('-').map(int.parse).toList(); prev = DateTime(p[0], p[1], p[2]); } catch (_) {}
    final gap = prev == null ? 99 : DateTime.now().difference(prev).inDays;
    streak = gamesToday > 0 && gap <= 1 ? streak + 1 : 0;
    dayKey = today; gamesToday = 0; freeChatUsed = 0; refsToday = 0; winsToday = 0; gamesTodayIds = []; claimed = []; strikes = 0;
    _commit();
  }

  bool spend(int n) {
    if (n < 0) { coins -= n; _commit(); return true; }
    if (coins < n) return false;
    coins -= n; _commit(); return true;
  }
  void grant(int n) { coins += n; _commit(); }

  Rewards rewardsFor(int rank, String gid) {
    final wk = weekKey();
    final cp = rank < cupPoints.length ? cupPoints[rank] : 0;
    final mine = cups.where((c) => cupState[c.id]?.week == wk && (c.game == 'all' || c.game == gid));
    return Rewards(rank < trophyDelta.length ? trophyDelta[rank] : 0, [for (final c in mine) CupReward(c.name, cp)]);
  }

  void onResult(int rank, int pay, String gid) {
    final total = pay + tr.bonus;
    coins += total;
    final rw = rewardsFor(rank, gid);
    trophies = max(0, trophies + rw.trophies);
    passXp += rank == 0 ? 100 : 40;
    for (final c in cups) {
      final e = cupState[c.id];
      if (e != null && e.week == weekKey() && (c.game == 'all' || c.game == gid) && rw.cups.isNotEmpty) e.pts += rw.cups[0].cp;
    }
    gamesToday++;
    if (rank == 0) winsToday++;
    if (!gamesTodayIds.contains(gid)) gamesTodayIds.add(gid);
    history.insert(0, HistoryItem(gid, rank, total, DateTime.now().millisecondsSinceEpoch));
    if (history.length > 12) history.length = 12;
    stats.played++; if (rank == 0) stats.wins++; stats.xp += rank == 0 ? 120 : 40;
    final bg = stats.byGame[gid] ?? [0, 0]; stats.byGame[gid] = [bg[0] + 1, bg[1] + (rank == 0 ? 1 : 0)];
    showToast(tr.bonus > 0 ? '+$total coins (${tr.glyph} +${tr.bonus})' : '+$total coins', 2200);
    _commit();
  }

  (bool, String) redeemRef(String code) {
    final c = code.trim().toUpperCase();
    if (c.isEmpty) return (false, 'Enter a code or skip.');
    if (!RegExp(r'^CHP-[A-Z0-9]{5}$').hasMatch(c)) return (false, 'Codes look like CHP-7K2Q9.');
    if (c == refCode) return (false, "That's your own code.");
    if (refRedeemed.isNotEmpty) return (false, "You've already used a code.");
    refRedeemed = c; coins += 250; _commit();
    remote(() => Backend.post('/v1/referrals/redeem', {'code': c}));
    return (true, '250 coins added. Your friend gets 500.');
  }
  void finishTour() {
    onboarded = true;
    if (!tourPaid) { coins += 100; tourPaid = true; showToast('+100 coins for finishing the tour'); }
    _commit(); remote(() => Backend.post('/v1/me/tour'));
  }
  void replayTour() { onboarded = false; _commit(); }

  void claimMission(Mission m) { if (claimed.contains(m.id) || m.have(this) < m.need) return; claimed.add(m.id); coins += m.reward; showToast('+${m.reward} coins · ${m.name}'); _commit(); remote(() => Backend.post('/v1/missions/${m.id}/claim')); }
  void claimBadge(Achievement b) { if (badgesClaimed.contains(b.id) || !b.test(this)) return; badgesClaimed.add(b.id); coins += b.coins; stats.xp += b.xp; showToast('${b.glyph} ${b.name} · +${b.coins} coins · +${b.xp} XP'); _commit(); remote(() => Backend.post('/v1/badges/${b.id}/claim')); }

  void joinCup(String id) { final c = cups.firstWhere((x) => x.id == id); if (!spend(c.entry)) { showToast('Not enough coins for ${c.name}'); return; } cupState[id] = CupEntry(weekKey(), 0); _commit(); remote(() => Backend.post('/v1/cups/$id/join')); }
  void claimCup(String id) {
    if (Backend.on) { remote(() async { final mine = await Backend.get('/v1/cups') as Map; for (final e in (mine['mine'] as List).cast<Map>()) { if (e['cup_id'] == id && e['settled'] == true && e['claimed'] != true) await Backend.post('/v1/cups/entries/${e['id']}/claim'); } }); cupState.remove(id); _commit(); return; }
    final e = cupState[id]; if (e == null || e.prize == null) return;
    coins += e.prize!.coins; trophies += e.prize!.trophies;
    showToast('${e.prize!.coins} coins · +${e.prize!.trophies} trophies from ${cups.firstWhere((c) => c.id == id).name}');
    cupState.remove(id); _commit();
  }
  void settleCups() {
    final wk = weekKey();
    cupState.forEach((id, e) {
      if (e.week != wk && !e.settled) {
        final rank = cupTable(id, e.week).where((r) => r.pts > e.pts).length + 1;
        e.settled = true; e.finalRank = rank; e.prize = prizeForRank(rank);
      }
    });
  }

  bool buy(Item it) {
    if (owned.contains(it.id)) return false;
    if (!spend(it.price)) { showToast('Not enough coins — win a game to earn more.'); return false; }
    if (it.kind == 'reroll') { rerolls += it.qty; showToast('+${it.qty} re-rolls'); }
    else if (it.kind == 'chat') { chatPassDay = todayKey(); showToast('Chat pass active until midnight'); }
    else { owned.add(it.id); if (it.slot != null) equipped.set(it.slot!, it.id); showToast('${it.name} is yours'); }
    _commit(); remote(() => Backend.post('/v1/market/buy', {'itemId': it.id})); return true;
  }
  bool owns(Item it) => it.price == 0 || owned.contains(it.id);
  void equip(Item it) { if (it.slot == null || !owns(it)) return; equipped.set(it.slot!, it.id); _commit(); remote(() => Backend.post('/v1/market/equip', {it.slot!: it.id})); }
  bool hasSet(String setId) => allItems.where((i) => i.setId == setId).every(owns);

  void buyPass() { if (passPremium || !spend(passPrice)) { if (!passPremium) showToast('Not enough coins for the pass'); return; } passPremium = true; showToast('Premium pass unlocked'); _commit(); remote(() => Backend.post('/v1/pass/buy')); }
  void passClaim(int lvl, bool prem) {
    final k = '$lvl${prem ? 'p' : 'f'}';
    if (passClaimed.contains(k) || lvl > passLevel || (prem && !passPremium)) return;
    final r = prem ? passTrack[lvl - 1].prem : passTrack[lvl - 1].free;
    passClaimed.add(k); coins += r.coins; rerolls += r.reroll;
    if (r.item != null && !owned.contains(r.item)) owned.add(r.item!);
    showToast('Pass reward: ${r.label()}${r.title != null ? ' · title "${r.title}"' : ''}'); _commit();
    remote(() => Backend.post('/v1/pass/claim', {'level': lvl, 'premium': prem}));
  }
  bool dailyClaim() {
    if (dailyLast == todayKey()) return false;
    final idx = dailyLast.isEmpty ? 0 : (dailyDay + 1) % 7;
    final rr = idx == 6 ? 3 : 0;
    dailyDay = idx; dailyLast = todayKey(); coins += dailyCoins[idx]; rerolls += rr;
    showToast('Day ${idx + 1} reward: +${dailyCoins[idx]} coins${rr > 0 ? ' + $rr re-rolls' : ''}'); _commit(); remote(() => Backend.post('/v1/daily/claim')); return true;
  }
  void spinWon(int won) { spinDay = todayKey(); coins += won; showToast('🎡 Lucky spin: +$won coins'); _commit(); remote(() => Backend.post('/v1/spin')); }
  bool useReroll() { if (rerolls <= 0) return false; rerolls--; _commit(); return true; }

  bool buyTier(Tier t) {
    if (t.id == tier) return false;
    if (!tierBought.contains(t.id)) { if (!spend(t.cost)) { showToast('Not enough coins for ${t.name}'); return false; } tierBought.add(t.id); }
    tier = t.id; grace = false; showToast('${t.glyph} ${t.name} status active'); _commit(); remote(() => Backend.post('/v1/me/tier', {'tier': t.id})); return true;
  }

  void setSound(bool v) { soundOn = v; _commit(); if (Backend.on) Backend.patch('/v1/me', {'sound_on': v}).catchError((_) {}); }
  void saveAdda() => _commit();
  void updateProfile(void Function(Profile) f) {
    final beforeName = profile.name, beforeAge = profile.age; f(profile); _commit();
    if (!Backend.on) return;
    remote(() async {
      if (profile.name != beforeName && profile.name.isNotEmpty) await Backend.post('/v1/me/username', {'username': profile.name});
      if (profile.age != beforeAge && profile.age.isNotEmpty) await Backend.post('/v1/me/age', {'age': int.parse(profile.age)});
      await Backend.patch('/v1/me', {'avatar': profile.avatar, 'interests': profile.interests, 'hobbies': profile.hobbies, 'quiz': profile.quiz});
    });
  }
  void addStrike() { strikes++; _commit(); }
  void useFreeChat() { freeChatUsed++; _commit(); }
  void tickMinute() { playMins++; save(); }

  List<Item> dailyDeals() {
    final pool = allItems.where((i) => i.price > 0 && i.slot != null && i.setId == null).toList();
    var h = 0; for (final ch in todayKey().codeUnits) { h = (h * 33 + ch) & 0xFFFFFFFF; }
    final out = <Item>[];
    for (var k = 0; k < 3 && pool.isNotEmpty; k++) { h = (h * 1103515245 + 12345) & 0xFFFFFFFF; out.add(pool.removeAt(h % pool.length)); }
    return out;
  }

  // dev tools
  void devReset() async { final sp = await SharedPreferences.getInstance(); await sp.remove(key); coins = 0; profile = Profile(); stats = Stats(); owned = []; onboarded = false; welcomePaid = false; tourPaid = false; trophies = 0; cupState = {}; history = []; tier = 'rookie'; equipped = Equip(); coins = 100; welcomePaid = true; _commit(); }
  void devCoins() { coins += 500000; showToast('+5,00,000 coins'); _commit(); }
  void devNextDay() { dayKey = 'test-yesterday'; rollover(); showToast('Day rolled over'); }
}
