import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../adda_state.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

class AddaTab extends StatefulWidget {
  final AppStore store;
  const AddaTab({super.key, required this.store});
  @override
  State<AddaTab> createState() => _AddaTabState();
}

class _AddaTabState extends State<AddaTab> {
  String pane = 'feed'; Timer? growth; final rnd = Random();
  AddaState get a => widget.store.adda; AppStore get s => widget.store;
  String get me => s.profile.name.isEmpty ? 'You' : s.profile.name;
  @override
  void initState() { super.initState(); growth = Timer.periodic(const Duration(seconds: 6), (_) => _grow()); }
  @override
  void dispose() { growth?.cancel(); super.dispose(); }

  void _grow() {
    if (!a.unlocked) return;
    for (final p in a.posts) {
      if (p.review) { if (DateTime.now().millisecondsSinceEpoch - p.ts > 20000) p.review = false; continue; }
      final r = rnd.nextDouble();
      if (p.mine) {
        p.views += 2 + rnd.nextInt(12) * (1 + p.likes ~/ 40);
        if (r < .35) { p.likes++; p.likers.add(addaBots[rnd.nextInt(addaBots.length)]); if (p.likers.length > 300) p.likers.removeAt(0); }
        if (r > .9) p.comments.add(Comment(rnd.nextInt(1 << 30).toString(), addaBots[rnd.nextInt(addaBots.length)], botComments[rnd.nextInt(botComments.length)], DateTime.now().millisecondsSinceEpoch));
        if (r < .08) a.followers++;
      } else if (r < .15) { p.likes++; p.views += 5; }
    }
    s.saveAdda();
  }
  bool visible(Post p) => (!p.review || p.mine) && !a.blocked.contains(p.who) && !a.hiddenPosts.contains(p.id);
  bool following(String who) => a.following.contains(who);
  void follow(String who) { if (who == me || a.blocked.contains(who)) return; following(who) ? a.following.remove(who) : a.following.add(who); s.saveAdda(); }
  void block(String who) { a.blocked.add(who); a.following.remove(who); s.saveAdda(); s.showToast('$who blocked · their posts and comments are hidden'); }
  void like(Post p) { if (p.mine) return; if (a.liked.contains(p.id)) { a.liked.remove(p.id); p.likes--; } else { a.liked.add(p.id); p.likes++; } s.saveAdda(); }
  (int, int, String) profOf(String who) { if (who == me) return (a.followers, a.following.length, 'Your public profile'); final b = botProfiles[who] ?? (40 + who.length * 7, 20, 'Public profile'); return (b.$1 + (following(who) ? 1 : 0), b.$2, b.$3); }

  /// Returns null when allowed, else the reason. Severity 3 (zero tolerance) also flags the account.
  String? _guard(String text) {
    final v = moderate(text); if (v == null) return null;
    if (v.$2 >= 2) s.addStrike();
    if (v.$2 >= 3) { a.safetyFlags++; s.saveAdda(); s.showToast('Blocked — ${v.$1}. Your account has been flagged for review.', 4000); }
    return v.$1;
  }

  @override
  Widget build(BuildContext context) {
    if (!a.unlocked) return _gate();
    final feed = a.posts.where(visible).where((p) => a.filter != 'following' || p.mine || following(p.who)).toList();
    final today = DateTime.now().toIso8601String().substring(0, 10), postsToday = a.postsDay == today ? a.postsToday : 0;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(crossAxisAlignment: CrossAxisAlignment.end, children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Adda', style: head(24)), Text('Likes, comments and follows. Be nice.', style: body(11, color: T.mute))])),
        if (pane == 'feed') Btn('+ Post · ${addaPostsPerDay - postsToday} left', small: true, onTap: () => _compose(postsToday, today))]),
      const SizedBox(height: 12),
      Row(children: [for (final t in [('feed', 'Feed'), ('creator', a.creatorStatus == 'approved' ? 'Creator · earning' : 'Creator program')]) Expanded(child: GestureDetector(onTap: () => setState(() => pane = t.$1), child: Container(margin: EdgeInsets.only(right: t.$1 == 'feed' ? 6 : 0), padding: const EdgeInsets.symmetric(vertical: 8), alignment: Alignment.center, decoration: BoxDecoration(color: pane == t.$1 ? T.yellow : T.panel, borderRadius: BorderRadius.circular(12), border: Border.all(color: T.line)), child: Text(t.$2, style: body(11, w: FontWeight.w800, color: pane == t.$1 ? const Color(0xFF241B00) : T.ink)))))]),
      const SizedBox(height: 12),
      if (pane == 'feed') ...[
        Row(children: [for (final f in [('all', 'All'), ('following', 'Following · ${a.following.length}')]) GestureDetector(onTap: () => setState(() { a.filter = f.$1; s.saveAdda(); }), child: Container(margin: const EdgeInsets.only(right: 6), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), decoration: BoxDecoration(color: a.filter == f.$1 ? T.ink : T.panel2, borderRadius: BorderRadius.circular(99), border: Border.all(color: T.line)), child: Text(f.$2, style: body(10, w: FontWeight.w700, color: a.filter == f.$1 ? T.bg : T.mute)))),
          const Spacer(), GestureDetector(onTap: () => _profile(me), child: Text('${a.followers} followers', style: body(10, color: T.yellow, w: FontWeight.w600)))]),
        const SizedBox(height: 10),
        if (feed.isEmpty) Panel(child: Text(a.filter == 'following' ? 'Follow a few players — their posts show up here.' : 'Nothing here yet.', textAlign: TextAlign.center, style: body(11, color: T.mute))),
        for (var i = 0; i < feed.length; i++) ...[_post(feed[i]), const SizedBox(height: 10), if ((i + 1) % adMatrix.adsPerPosts == 0) ...[_ad(), const SizedBox(height: 10)]],
      ] else ..._creator(),
    ]);
  }

  Widget _gate() => Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('📸', style: TextStyle(fontSize: 40)), const SizedBox(height: 8),
        Text('NEW', style: body(11, color: T.yellow, w: FontWeight.w600)), Text('Adda', style: head(30)),
        const SizedBox(height: 8), Text("Post your board moments. Follow players you like, and like and comment on their posts. Every profile is public — no private accounts, no DMs.", style: body(14, color: T.mute)),
        const SizedBox(height: 14),
        Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Creator Partner Program', style: head(14)), const SizedBox(height: 4), Text('Post regularly, earn real engagement, and apply to share in Adda\'s ad revenue — ${(adMatrix.creatorShare * 100).round()}% of feed ad income is paid out to approved creators every month.', style: body(11, color: T.mute))])),
        const SizedBox(height: 10),
        Panel(color: T.yellow.withOpacity(.08), border: T.yellow.withOpacity(.3), child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('$addaUnlock coins', style: head(20, color: T.yellow)), Text('One-time unlock. One winning game pays for it.', style: body(11))])), Btn('Unlock', onTap: s.coins < addaUnlock ? null : () { if (s.spend(addaUnlock)) { a.unlocked = true; s.saveAdda(); s.showToast('Adda unlocked 📸'); } })])),
        const SizedBox(height: 10),
        Panel(border: T.red.withOpacity(.3), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Zero tolerance', style: head(14)), const SizedBox(height: 4), Text('Hate, abuse, sexual content, violence and anything involving children are blocked automatically, strike your account, and are reviewed by people. Child-safety violations are reported to the authorities. Photos are scanned and reviewed before they go public.', style: body(11, color: T.mute))])),
      ]));

  Widget _post(Post p) {
    final liked = a.liked.contains(p.id);
    return Container(clipBehavior: Clip.antiAlias, decoration: BoxDecoration(color: T.panel, borderRadius: BorderRadius.circular(24), border: Border.all(color: T.line)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.fromLTRB(12, 8, 8, 8), child: Row(children: [
        Face(p.avatar, size: 28), const SizedBox(width: 8),
        Expanded(child: GestureDetector(onTap: () => _profile(p.who), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${p.who} ${tierOf(p.tier).glyph}', maxLines: 1, overflow: TextOverflow.ellipsis, style: body(11, w: FontWeight.w800)), Text('${ago(p.ts)} ago${p.game != null ? ' · ${gameOf(p.game!).name}' : ''}${p.review ? ' · under review' : ''}', style: body(9, color: T.mute))]))),
        if (p.mine) Text('${fmtCoins(p.views)} views', style: body(9, color: T.mute, w: FontWeight.w600))
        else GestureDetector(onTap: () => setState(() => follow(p.who)), child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: following(p.who) ? Colors.transparent : T.yellow, borderRadius: BorderRadius.circular(8), border: Border.all(color: following(p.who) ? T.line : T.yellow)), child: Text(following(p.who) ? 'Following' : 'Follow', style: body(10, w: FontWeight.w800, color: following(p.who) ? T.mute : const Color(0xFF241B00))))),
        if (!p.mine) IconButton(onPressed: () => _report(p), icon: const Icon(Icons.more_horiz, size: 18, color: T.mute), padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 28, minHeight: 28)),
      ])),
      Container(height: 150, width: double.infinity, padding: const EdgeInsets.all(16), alignment: Alignment.bottomLeft, decoration: BoxDecoration(gradient: LinearGradient(colors: [p.grad[0].withOpacity(.8), p.grad[1]], begin: Alignment.topLeft, end: Alignment.bottomRight)),
        child: Stack(children: [Positioned(right: 0, top: -8, child: Opacity(opacity: .3, child: Text(p.glyph, style: const TextStyle(fontSize: 56)))), Align(alignment: Alignment.bottomLeft, child: Text(p.cap, style: head(16, color: Colors.white)))])),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), child: Row(children: [
        GestureDetector(onTap: () => setState(() => like(p)), child: Row(children: [Icon(liked ? Icons.favorite : Icons.favorite_border, size: 18, color: liked ? T.red : T.ink), const SizedBox(width: 4), Text('${p.likes}', style: body(11, w: FontWeight.w700, color: liked ? T.red : T.ink))])),
        const SizedBox(width: 16),
        GestureDetector(onTap: () => _comments(p), child: Row(children: [const Icon(Icons.chat_bubble_outline, size: 18, color: T.ink), const SizedBox(width: 4), Text('${p.comments.length}', style: body(11, w: FontWeight.w700))])),
        const Spacer(),
        if (p.comments.isNotEmpty) Flexible(child: Text('${p.comments.last.who} ${p.comments.last.text}', maxLines: 1, overflow: TextOverflow.ellipsis, style: body(10, color: T.mute))),
      ])),
    ]));
  }
  Widget _ad() => Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), decoration: BoxDecoration(color: T.panel2, borderRadius: BorderRadius.circular(16), border: Border.all(color: T.line)), child: Row(children: [const Pill('SPONSORED'), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Weekly Carrom Cup · free entry Friday', style: body(11, color: T.green, w: FontWeight.w600)), Text('Native feed unit · revenue funds the creator pool', style: body(10, color: T.mute))]))]));

  void _compose(int postsToday, String today) {
    final ctl = TextEditingController(); String? err;
    showSheet(context, StatefulBuilder(builder: (ctx, setS) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('New post', style: head(18)), Text(s.history.isNotEmpty ? 'Auto-tagged with your last game: ${gameOf(s.history[0].game).name}' : 'Play a game to auto-tag your post', style: body(10, color: T.mute)),
      const SizedBox(height: 10),
      TextField(controller: ctl, maxLength: addaCapMax, maxLines: 3, style: body(13), decoration: InputDecoration(hintText: 'Kya hua aaj board pe?', hintStyle: body(13, color: T.mute), filled: true, fillColor: T.panel2, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: T.line)))),
      Text('Photos: pick from gallery in the full build — scanned for nudity, violence and child safety, then reviewed before going public.', style: body(10, color: T.mute)),
      if (err != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(err!, style: body(11, color: T.red))),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: Btn('Cancel', tone: Tone.ghost, onTap: () => Navigator.pop(ctx))), const SizedBox(width: 8), Expanded(child: Btn('Post', onTap: () {
        final text = ctl.text.trim();
        if (text.isEmpty) { setS(() => err = 'Write something first.'); return; }
        if (postsToday >= addaPostsPerDay) { setS(() => err = '$addaPostsPerDay posts a day. Back tomorrow.'); return; }
        final why = _guard(text); if (why != null) { setS(() => err = 'Not posted — $why.'); return; }
        final g = s.history.isNotEmpty ? gameOf(s.history[0].game) : null;
        a.posts.insert(0, Post(id: 'p${DateTime.now().millisecondsSinceEpoch}', who: me, avatar: s.profile.avatar, tier: s.tier, mine: true, game: g?.id, glyph: g?.glyph ?? '🎲', grad: [g?.accent ?? T.yellow, const Color(0xFF1E1937)], ts: DateTime.now().millisecondsSinceEpoch, cap: text));
        a.postsToday = postsToday + 1; a.postsDay = today; s.saveAdda(); Navigator.pop(ctx); s.showToast('Posted to Adda');
      }))]),
    ])));
  }

  void _comments(Post p) {
    final ctl = TextEditingController(); String? err;
    showSheet(context, StatefulBuilder(builder: (ctx, setS) => Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
      Text('${p.comments.length} comment${p.comments.length == 1 ? '' : 's'}', style: head(14)),
      const SizedBox(height: 8),
      ConstrainedBox(constraints: const BoxConstraints(maxHeight: 280), child: ListView(shrinkWrap: true, children: [
        if (p.comments.isEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 20), child: Text('Be the first. Emojis are always welcome.', textAlign: TextAlign.center, style: body(11, color: T.mute))),
        for (final c in p.comments.where((c) => !a.blocked.contains(c.who))) Container(margin: const EdgeInsets.only(bottom: 6), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: c.mine ? T.yellow.withOpacity(.08) : T.panel2, borderRadius: BorderRadius.circular(12)), child: Text.rich(TextSpan(children: [TextSpan(text: '${c.who} ', style: body(12, w: FontWeight.w800, color: c.mine ? T.yellow : T.ink)), TextSpan(text: c.text, style: body(12)), TextSpan(text: '  ${ago(c.ts)}', style: body(9, color: T.mute))]))),
      ])),
      SizedBox(height: 36, child: ListView(scrollDirection: Axis.horizontal, children: [for (final e in ['🔥', '😂', '👏', '😭', '🙏', 'GG 🤝', 'Kya luck hai', 'Rematch?']) GestureDetector(onTap: () => setS(() => ctl.text = e), child: Container(margin: const EdgeInsets.only(right: 6, top: 4), padding: const EdgeInsets.symmetric(horizontal: 12), alignment: Alignment.center, decoration: BoxDecoration(color: T.panel2, borderRadius: BorderRadius.circular(99), border: Border.all(color: T.line)), child: Text(e, style: body(11))))])),
      if (err != null) Text(err!, style: body(10, color: T.red)),
      const SizedBox(height: 6),
      Row(children: [Expanded(child: TextField(controller: ctl, maxLength: 120, style: body(13), decoration: InputDecoration(counterText: '', hintText: 'Add a comment', hintStyle: body(13, color: T.mute), filled: true, fillColor: T.panel2, isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: T.line))))), const SizedBox(width: 8),
        Btn('Send', small: true, onTap: () { final t = ctl.text.trim(); if (t.isEmpty) return; final why = _guard(t); if (why != null) { setS(() { err = 'Not sent — $why.'; ctl.clear(); }); return; } p.comments.add(Comment(DateTime.now().millisecondsSinceEpoch.toString(), me, t, DateTime.now().millisecondsSinceEpoch, mine: true)); s.saveAdda(); setS(() { ctl.clear(); err = null; }); })]),
    ])));
  }

  void _profile(String who) {
    final pr = profOf(who), mineP = who == me, ps = a.posts.where((p) => p.who == who && visible(p)).toList();
    final av = ps.isNotEmpty ? ps[0].avatar : (mineP ? s.profile.avatar : 'f1'), tr = ps.isNotEmpty ? ps[0].tier : (mineP ? s.tier : 'rookie');
    showSheet(context, StatefulBuilder(builder: (ctx, setS) => Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
      Row(children: [Face(av, size: 56), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('$who ${tierOf(tr).glyph}', style: head(18)), Text('${pr.$3} · ${tierOf(tr).name}', style: body(10, color: T.mute)), const SizedBox(height: 4),
        Text.rich(TextSpan(children: [TextSpan(text: '${ps.length}', style: body(11, w: FontWeight.w800)), TextSpan(text: ' posts   ', style: body(11, color: T.mute)), TextSpan(text: fmtCoins(pr.$1), style: body(11, w: FontWeight.w800)), TextSpan(text: ' followers   ', style: body(11, color: T.mute)), TextSpan(text: '${pr.$2}', style: body(11, w: FontWeight.w800)), TextSpan(text: ' following', style: body(11, color: T.mute))]))]))]),
      const SizedBox(height: 12),
      if (!mineP) Row(children: [Expanded(child: Btn(following(who) ? 'Following ✓' : 'Follow', tone: following(who) ? Tone.dark : Tone.brass, onTap: () => setS(() => follow(who)))), const SizedBox(width: 8), Btn('Report', tone: Tone.ghost, onTap: ps.isEmpty ? null : () { Navigator.pop(ctx); _report(ps[0]); }), const SizedBox(width: 8), Btn('Block', tone: Tone.red, onTap: () { Navigator.pop(ctx); block(who); })]),
      if (mineP) Text('Following ${a.following.isEmpty ? 'nobody yet' : a.following.join(', ')}. Everyone can see this page — Adda has no private profiles.', style: body(10, color: T.mute)),
      if (mineP && a.blocked.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Wrap(spacing: 6, children: [for (final b in a.blocked) GestureDetector(onTap: () => setS(() { a.blocked.remove(b); s.saveAdda(); }), child: Pill('$b · unblock'))])),
      const SizedBox(height: 12), Text('POSTS', style: body(10, color: T.mute, w: FontWeight.w800)), const SizedBox(height: 8),
      if (ps.isEmpty) Text('No posts yet.', style: body(11, color: T.mute)),
      GridView.count(crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 6, crossAxisSpacing: 6, children: [for (final p in ps.take(9)) GestureDetector(onTap: () { Navigator.pop(ctx); _comments(p); }, child: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(gradient: LinearGradient(colors: [p.grad[0].withOpacity(.8), p.grad[1]]), borderRadius: BorderRadius.circular(12)), child: Stack(children: [Text(p.cap.length > 48 ? '${p.cap.substring(0, 48)}…' : p.cap, style: head(9, color: Colors.white)), Positioned(right: 0, bottom: 0, child: Text('♥ ${p.likes}', style: body(9, color: Colors.white, w: FontWeight.w700)))])))]),
    ])));
  }

  void _report(Post p) {
    showSheet(context, Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
      Text('Report this post', style: head(18)), Text("It's hidden from your feed right away. Marked reasons go straight to the safety team.", style: body(10, color: T.mute)), const SizedBox(height: 10),
      for (final r in reportReasons) Padding(padding: const EdgeInsets.only(bottom: 6), child: GestureDetector(onTap: () { a.hiddenPosts.add(p.id); if (r.$3) a.safetyFlags += 0; s.saveAdda(); Navigator.pop(context); s.showToast(r.$3 ? 'Reported · ${r.$2} reports are escalated to the safety team immediately' : 'Reported · hidden from your feed, under review', 3500); setState(() {}); },
        child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), decoration: BoxDecoration(color: T.panel2, borderRadius: BorderRadius.circular(12), border: Border.all(color: r.$3 ? T.red.withOpacity(.4) : T.line)), child: Row(children: [Expanded(child: Text(r.$2, style: body(12, w: FontWeight.w600))), if (r.$3) Text('ESCALATED', style: body(9, color: T.red, w: FontWeight.w900))])))),
      Btn('Cancel', tone: Tone.ghost, full: true, onTap: () => Navigator.pop(context)),
    ]));
  }

  List<Widget> _creator() {
    final cs = creatorStats(a, s);
    final ok = [for (final r in creatorRules) r.test != null ? r.test!(cs) : r.have!(cs) >= r.need!];
    final eligible = ok.every((x) => x), status = a.creatorStatus;
    return [
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(gradient: LinearGradient(colors: [T.yellow.withOpacity(.2), T.panel], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24), border: Border.all(color: T.yellow.withOpacity(.4))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('CREATOR PARTNER PROGRAM', style: body(10, color: T.yellow, w: FontWeight.w800)),
        Text(status == 'approved' ? "You're a partner" : status == 'pending' ? 'Application under review' : eligible ? "You're eligible — apply" : '${ok.where((x) => x).length} of ${creatorRules.length} rules met', style: head(20)),
        const SizedBox(height: 4),
        Text('${(adMatrix.creatorShare * 100).round()}% of Adda\'s monthly feed ad revenue is split between approved creators by eligible views, weighted by engagement rate. Paid in rupees to a verified UPI or bank account on the 7th of every month once you cross ${inr(adMatrix.minPayoutPaise)}.', style: body(11, color: T.mute)),
        if (status == 'none') Padding(padding: const EdgeInsets.only(top: 10), child: Btn(eligible ? 'Apply now' : 'Meet the rules below to apply', full: true, onTap: eligible ? () { a.creatorStatus = 'pending'; a.appliedAt = DateTime.now().millisecondsSinceEpoch; s.saveAdda(); s.showToast('Application sent · review takes up to 3 working days'); setState(() {}); } : null)),
        if (status == 'pending') Padding(padding: const EdgeInsets.only(top: 8), child: Text('Applied ${ago(a.appliedAt)} ago · we check content quality, originality and community reports.', style: body(11, color: T.yellow))),
      ])),
      const SizedBox(height: 12),
      if (status == 'approved') ...[Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text('Earnings', style: head(14))), Text('RPM ${inr(cs.rpm)} / 1k · ×${cs.boost.toStringAsFixed(1)}', style: body(10, color: T.mute))]),
        const SizedBox(height: 8),
        Row(children: [for (final e in [('Unpaid', inr(cs.unpaidPaise), T.green), ('Lifetime', inr(cs.earnedPaise), T.ink), ('Paid out', inr(a.paidPaise), T.ink)]) Expanded(child: Container(margin: const EdgeInsets.only(right: 6), padding: const EdgeInsets.symmetric(vertical: 8), decoration: BoxDecoration(color: T.panel2, borderRadius: BorderRadius.circular(12)), child: Column(children: [Text(e.$2, style: head(15, color: e.$3)), Text(e.$1, style: body(9, color: T.mute))])))]),
        const SizedBox(height: 8),
        ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: (cs.unpaidPaise / adMatrix.minPayoutPaise).clamp(0.0, 1.0).toDouble(), minHeight: 6, color: T.green, backgroundColor: T.line)),
        Text('${fmtCoins(cs.eligibleViews)} eligible views since approval · ${cs.unpaidPaise >= adMatrix.minPayoutPaise ? 'payout threshold reached' : '${inr(adMatrix.minPayoutPaise - cs.unpaidPaise)} to the ${inr(adMatrix.minPayoutPaise)} threshold'}', style: body(10, color: T.mute)),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: GestureDetector(onTap: () => setState(() { a.kyc = !a.kyc; s.saveAdda(); }), child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: a.kyc ? T.green.withOpacity(.12) : T.panel2, borderRadius: BorderRadius.circular(12), border: Border.all(color: a.kyc ? T.green : T.line)), child: Text(a.kyc ? '✓ KYC verified · PAN + UPI on file' : 'Complete KYC · PAN + UPI (tap to simulate)', style: body(11))))), const SizedBox(width: 8),
          Btn('Request payout', small: true, tone: Tone.green, onTap: cs.unpaidPaise >= adMatrix.minPayoutPaise && a.kyc ? () { a.paidPaise += cs.unpaidPaise; s.saveAdda(); s.showToast('${inr(cs.unpaidPaise)} payout queued for the 7th'); setState(() {}); } : null)]),
      ])), const SizedBox(height: 12)],
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Eligibility', style: head(14)), const SizedBox(height: 8),
        for (var i = 0; i < creatorRules.length; i++) Padding(padding: const EdgeInsets.only(bottom: 8), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text('${ok[i] ? '✓ ' : '○ '}${creatorRules[i].name}', style: body(11, color: ok[i] ? T.green : T.ink))), if (creatorRules[i].have != null) Text('${fmtCoins(min(creatorRules[i].have!(cs), creatorRules[i].need!))}/${fmtCoins(creatorRules[i].need!)}', style: body(11, color: T.mute))]),
          if (creatorRules[i].have != null) Padding(padding: const EdgeInsets.only(top: 4), child: ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: (creatorRules[i].have!(cs) / creatorRules[i].need!).clamp(0.0, 1.0).toDouble(), minHeight: 4, color: ok[i] ? T.green : T.yellow, backgroundColor: T.line))),
        ]))])),
      const SizedBox(height: 12),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('How the ad matrix pays', style: head(14)), const SizedBox(height: 6),
        for (final t in ['1. A sponsored card runs after every ${adMatrix.adsPerPosts} posts. That revenue is the month\'s Adda pool.', '2. ${(adMatrix.creatorShare * 100).round()}% of the pool goes to approved creators. The rest runs the servers and moderation.', '3. Your share = your eligible views (unique people, 2 s+, no bots) × an engagement multiplier: under 2% → ×0.8 · 2% → ×1.0 · 5% → ×1.2 · 10%+ → ×1.5.', '4. Illustrative RPM today: ${inr(adMatrix.baseRpmPaise)} per 1,000 views before the multiplier. Real RPM moves with actual ad income and is published on the 1st of each month.', '5. Minimum payout ${inr(adMatrix.minPayoutPaise)}. Paid on the 7th. Tax is deducted at source as required by Indian law.']) Padding(padding: const EdgeInsets.only(bottom: 4), child: Text(t, style: body(11, color: T.mute)))])),
      const SizedBox(height: 12),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Rules & regulations', style: head(14)), const SizedBox(height: 6),
        for (final t in ['Original content only — your own games, boards, reactions. No reposts, no copyrighted clips, no other people\'s faces without consent.', 'Zero tolerance: hate speech, abuse, bullying, sexual content, violence, self-harm, and anything involving children end the partnership immediately and permanently. Child-safety violations are reported to the authorities.', 'Nothing that identifies a minor. Nothing political. No links, phone numbers or UPI IDs in posts or comments.', 'Engagement must be organic. Like-for-like groups, bots, or paid engagement cancel your partnership and forfeit unpaid earnings.', 'Two strikes in 30 days pause payouts; a third removes you from the programme for 6 months.', 'Coins can never be converted to money. Creator payouts come only from ad revenue share, in rupees, after KYC (PAN + UPI/bank), to account holders 18 and over.', 'Chaupal may change RPM, share and thresholds with 30 days\' notice on this page. Disputes go to the grievance officer listed in your profile.']) Padding(padding: const EdgeInsets.only(bottom: 4), child: Text('• $t', style: body(11, color: T.mute)))])),
    ];
  }
}
