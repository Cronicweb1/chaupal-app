import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

class Msg { final String u, m; final bool mine; final String? sticker; Msg(this.u, this.m, {this.mine = false, this.sticker}); }

class ChatTab extends StatefulWidget {
  final AppStore store;
  final void Function(String gid) onChallenge;
  final VoidCallback goProfile;
  const ChatTab({super.key, required this.store, required this.onChallenge, required this.goProfile});
  @override
  State<ChatTab> createState() => _ChatTabState();
}

class _ChatTabState extends State<ChatTab> {
  Room? room; int secsLeft = 0, sessions = 0; String note = '';
  final msgs = <Msg>[]; final ctl = TextEditingController(); Timer? clock, botT; final rnd = Random();
  static const seedNames = ['Rhea_09', 'SaifPlays', 'Nandu', 'TinyDice', 'MeeraK'];
  @override
  void dispose() { clock?.cancel(); botT?.cancel(); ctl.dispose(); super.dispose(); }

  int get freeLeft { final t = widget.store.tr; if (t.unlimited || widget.store.chatPass) return 999; return max(0, t.free - widget.store.freeChatUsed); }

  void enter(Room r) {
    final s = widget.store, t = s.tr;
    if (r.gate != null && !t.rooms.contains(r.gate) && !s.chatPass) { setState(() => note = '${r.name} opens at ${tierOf(r.gate!).name} level.'); return; }
    if (sessions >= 8 && !t.unlimited && !s.chatPass) { setState(() => note = 'Daily chat limit reached. Come back tomorrow.'); return; }
    final free = freeLeft > 0 || r.cost == 0;
    if (!free && !s.spend(r.cost)) { setState(() => note = 'Not enough coins — win a game to earn more.'); return; }
    if (free && r.cost > 0 && !t.unlimited && !s.chatPass) s.useFreeChat();
    sessions++;
    msgs..clear()..addAll([Msg(seedNames[0], 'Welcome to ${r.name} 👋'), Msg(seedNames[1], curatedLines[rnd.nextInt(curatedLines.length)]), Msg(seedNames[2], curatedLines[rnd.nextInt(curatedLines.length)])]);
    setState(() { room = r; secsLeft = (s.chatPass ? 10 : t.mins) * 60; note = ''; });
    clock?.cancel();
    clock = Timer.periodic(const Duration(seconds: 1), (_) { if (!mounted) return; if (secsLeft <= 1) { leave('Session over — ${t.mins} minutes at ${t.name} level.'); } else { setState(() => secsLeft--); } });
    _botLoop();
  }
  void leave([String why = '']) { clock?.cancel(); botT?.cancel(); setState(() { room = null; note = why; }); }
  void _botLoop() { botT?.cancel(); botT = Timer(Duration(milliseconds: 4000 + rnd.nextInt(6000)), () { if (!mounted || room == null) return; setState(() => msgs.add(Msg(seedNames[rnd.nextInt(seedNames.length)], rnd.nextBool() ? botReplies[rnd.nextInt(botReplies.length)] : curatedLines[rnd.nextInt(curatedLines.length)]))); _botLoop(); }); }

  void send(String text, {bool free = false}) {
    final s = widget.store;
    final t = text.trim(); if (t.isEmpty) return;
    final v = moderate(t);
    if (v != null) { if (v.$2 >= 2) s.addStrike(); setState(() => note = 'Not sent — ${v.$1}.${s.strikes >= 3 ? ' Three strikes: chat locked until tomorrow.' : ''}'); if (s.strikes >= 3) leave('Chat locked until tomorrow after three strikes.'); return; }
    if (!free && !s.tr.unlimited && !s.chatPass) { final words = t.split(RegExp(r'\s+')).length; if (!s.spend(words)) { setState(() => note = '$words coins needed for $words word${words > 1 ? 's' : ''}.'); return; } }
    setState(() { msgs.add(Msg(s.profile.name.isEmpty ? 'You' : s.profile.name, t, mine: true)); note = ''; ctl.clear(); });
    if (rnd.nextDouble() < .6) Timer(const Duration(milliseconds: 1200), () { if (mounted && room != null) setState(() => msgs.add(Msg(seedNames[rnd.nextInt(seedNames.length)], botReplies[rnd.nextInt(botReplies.length)]))); });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    if (!s.chatAllowed) {
      return Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('🔒', style: TextStyle(fontSize: 44)), const SizedBox(height: 8),
        Text('Baithak is 18+', style: head(22)), const SizedBox(height: 6),
        Text(s.ageKnown ? (s.profile.everMinor ? 'This account was registered under 18. Chat stays off for good — the games and cups are all yours.' : 'Chat opens at 18.') : 'Set your age in Profile to open the rooms. Age is set once and cannot be changed.', textAlign: TextAlign.center, style: body(13, color: T.mute)),
        const SizedBox(height: 16), if (!s.ageKnown) Btn('Go to Profile', onTap: widget.goProfile),
      ]));
    }
    if (room != null) return _room(s, room!);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Baithak', style: head(24)),
      Text('Live rooms picked for your vibe. ${s.tr.unlimited || s.chatPass ? 'Unlimited entries today.' : '$freeLeft free entr${freeLeft == 1 ? 'y' : 'ies'} left today, then coins.'} Sessions run ${s.tr.mins} minutes at ${s.tr.name} level.', style: body(12, color: T.mute)),
      if (s.vibe == null) Padding(padding: const EdgeInsets.only(top: 8), child: GestureDetector(onTap: widget.goProfile, child: Text('Finish the vibe check in Profile to see room match %', style: body(11, color: T.yellow, w: FontWeight.w600)))),
      if (note.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: T.red.withOpacity(.12), borderRadius: BorderRadius.circular(12)), child: Text(note, style: body(11, color: const Color(0xFFFFC9C1))))),
      const SizedBox(height: 12),
      for (final r in rooms) Padding(padding: const EdgeInsets.only(bottom: 8), child: Panel(padding: const EdgeInsets.all(12), border: r.color.withOpacity(.3), onTap: () => enter(r), child: Row(children: [
        Container(width: 40, height: 40, alignment: Alignment.center, decoration: BoxDecoration(color: r.color.withOpacity(.15), borderRadius: BorderRadius.circular(12)), child: Text(r.glyph, style: const TextStyle(fontSize: 20))),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(r.name, style: head(14)), Text(r.topic, style: body(10, color: T.mute)), const SizedBox(height: 4), Row(children: [Container(width: 6, height: 6, decoration: const BoxDecoration(color: T.green, shape: BoxShape.circle)), const SizedBox(width: 4), Text('${r.live} live', style: body(9, w: FontWeight.w700)), const SizedBox(width: 8), if (s.matchPct(r) >= 0) Pill('${s.matchPct(r)}% match', color: s.matchPct(r) >= 80 ? T.green : T.mute), const SizedBox(width: 6), for (final t in r.tags) Padding(padding: const EdgeInsets.only(right: 4), child: Pill(t))])])),
        Text(r.gate != null && !s.tr.rooms.contains(r.gate) ? tierOf(r.gate!).glyph : r.cost == 0 || freeLeft > 0 ? 'Free' : '${r.cost} 🪙', style: body(11, color: r.color, w: FontWeight.w900)),
      ]))),
      Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: T.panel2, borderRadius: BorderRadius.circular(14)), child: Text('Filtered for phone numbers, links, UPI IDs and abuse. Three strikes lock chat for the day. Never share personal details.', textAlign: TextAlign.center, style: body(10, color: T.mute))),
    ]);
  }

  Widget _room(AppStore s, Room r) {
    final gid = rooms.indexOf(r) < 2 ? r.id : 'ludo';
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(8, 4, 12, 4), child: Row(children: [
        IconButton(onPressed: () => leave(), icon: const Icon(Icons.chevron_left, color: T.ink)),
        Text(r.glyph, style: const TextStyle(fontSize: 18)), const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(r.name, style: head(14)), Text('${r.live} live · ${s.tr.unlimited || s.chatPass ? 'free words' : '1 coin a word · curated lines free'}', style: body(9, color: T.mute))])),
        Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: secsLeft < 30 ? T.red.withOpacity(.15) : Colors.white.withOpacity(.06), borderRadius: BorderRadius.circular(8)), child: Text('${secsLeft ~/ 60}:${(secsLeft % 60).toString().padLeft(2, '0')}', style: body(11, w: FontWeight.w700, color: secsLeft < 30 ? T.red : T.ink))),
        const SizedBox(width: 6),
        Btn('⚔ Challenge', small: true, onTap: () => widget.onChallenge(gid)),
      ])),
      Expanded(child: ListView(padding: const EdgeInsets.symmetric(horizontal: 12), reverse: true, children: [for (final m in msgs.reversed) Align(alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(margin: const EdgeInsets.only(bottom: 6), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), constraints: const BoxConstraints(maxWidth: 280), decoration: BoxDecoration(color: m.mine ? T.yellow.withOpacity(.18) : T.panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: m.mine ? T.yellow.withOpacity(.4) : T.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(m.u, style: body(9, color: m.mine ? T.yellow : r.color, w: FontWeight.w800)), Text(m.m, style: body(12))])))])),
      if (note.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text(note, style: body(10, color: T.red))),
      SizedBox(height: 40, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [for (final l in [...chatEmoji, ...curatedLines]) GestureDetector(onTap: () => send(l, free: true), child: Container(margin: const EdgeInsets.only(right: 6, top: 4, bottom: 4), padding: const EdgeInsets.symmetric(horizontal: 10), alignment: Alignment.center, decoration: BoxDecoration(color: T.panel, borderRadius: BorderRadius.circular(99), border: Border.all(color: T.line)), child: Text(l, style: body(11))))])),
      Padding(padding: const EdgeInsets.fromLTRB(12, 4, 12, 10), child: Row(children: [
        Expanded(child: TextField(controller: ctl, maxLength: 80, style: body(12), onSubmitted: (v) => send(v), decoration: InputDecoration(counterText: '', hintText: s.tr.unlimited || s.chatPass ? 'Say something' : 'Your own words · 1 coin each', hintStyle: body(12, color: T.mute), filled: true, fillColor: T.panel2, isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: T.line))))),
        const SizedBox(width: 8),
        Btn('Send', small: true, onTap: () => send(ctl.text)),
      ])),
    ]);
  }
}
