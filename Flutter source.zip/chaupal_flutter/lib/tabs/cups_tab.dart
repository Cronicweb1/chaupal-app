import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

class CupsTab extends StatefulWidget {
  final AppStore store;
  const CupsTab({super.key, required this.store});
  @override
  State<CupsTab> createState() => _CupsTabState();
}

class _CupsTabState extends State<CupsTab> {
  String? open;
  @override
  Widget build(BuildContext context) {
    final s = widget.store, wk = weekKey(), lg = leagueOf(s.trophies);
    final nextLg = leagues.where((l) => l.min > s.trophies).firstOrNull;
    final msLeft = weekEnd().difference(DateTime.now());
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Cups & league', style: head(24)),
      Text('Every game moves your trophies. Every cup game moves your cup points. Prizes are coins and trophies — never cash.', style: body(12, color: T.mute)),
      const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(gradient: LinearGradient(colors: [lg.color.withOpacity(.2), T.panel], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24), border: Border.all(color: lg.color.withOpacity(.4))),
        child: Column(children: [
          Row(children: [
            Container(width: 56, height: 56, alignment: Alignment.center, decoration: BoxDecoration(color: lg.color.withOpacity(.15), borderRadius: BorderRadius.circular(16)), child: Text(lg.glyph, style: const TextStyle(fontSize: 30))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('YOUR LEAGUE', style: body(10, color: lg.color, w: FontWeight.w800)), Text('${lg.name} · ${s.trophies} 🏆', style: head(20)),
              const SizedBox(height: 6),
              ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: nextLg == null ? 1 : (s.trophies - lg.min) / (nextLg.min - lg.min), minHeight: 6, color: lg.color, backgroundColor: T.line)),
              Text(nextLg == null ? 'Top league' : '${nextLg.min - s.trophies} to ${nextLg.name}', style: body(10, color: T.mute)),
            ])),
          ]),
          const SizedBox(height: 12),
          Row(children: [for (var i = 0; i < 4; i++) Expanded(child: Container(margin: EdgeInsets.only(right: i < 3 ? 4 : 0), padding: const EdgeInsets.symmetric(vertical: 6), decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(12)), child: Column(children: [Text(['1st', '2nd', '3rd', '4th'][i], style: body(9, color: T.mute)), Text('${trophyDelta[i] > 0 ? '+' : ''}${trophyDelta[i]} 🏆', style: body(12, w: FontWeight.w900, color: trophyDelta[i] > 0 ? T.green : T.red))])))]),
          const SizedBox(height: 8),
          Row(children: [for (final l in leagues) Expanded(child: Container(margin: const EdgeInsets.symmetric(horizontal: 2), padding: const EdgeInsets.symmetric(vertical: 3), alignment: Alignment.center, decoration: BoxDecoration(color: l.id == lg.id ? l.color : l.color.withOpacity(.13), borderRadius: BorderRadius.circular(99)), child: Text(l.name, style: body(9, w: FontWeight.w700, color: l.id == lg.id ? const Color(0xFF1A1206) : l.color))))]),
        ])),
      const SizedBox(height: 14),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text("THIS WEEK'S CUPS", style: body(11, color: T.mute, w: FontWeight.w800)), Text(msLeft.inHours < 1 ? 'Settling soon' : 'Settle in ${msLeft.inDays}d ${msLeft.inHours % 24}h', style: body(11, color: T.yellow, w: FontWeight.w600))]),
      const SizedBox(height: 8),
      for (final cup in cups) _cup(s, cup, wk),
    ]);
  }

  Widget _cup(AppStore s, Cup cup, String wk) {
    final e = s.cupState[cup.id];
    final ex = e ?? CupEntry('', 0);
    final inIt = e != null && e.week == wk;
    final pending = e != null && e.week != wk && e.prize != null;
    final table = cupTable(cup.id, wk);
    final rank = inIt ? table.where((r) => r.pts > ex.pts).length + 1 : null;
    final isOpen = open == cup.id;
    return Padding(padding: const EdgeInsets.only(bottom: 10), child: Panel(border: inIt ? cup.color.withOpacity(.6) : T.line, padding: const EdgeInsets.all(12), onTap: () => setState(() => open = isOpen ? null : cup.id), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Container(width: 40, height: 40, alignment: Alignment.center, decoration: BoxDecoration(color: cup.color.withOpacity(.15), borderRadius: BorderRadius.circular(12)), child: Text(cup.glyph, style: const TextStyle(fontSize: 20))),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(cup.name, style: head(14)), Text(cup.game == 'all' ? 'Every board counts' : '${gameOf(cup.game).name} games count · 1st +10, 2nd +6, 3rd +3, 4th +1 cp', style: body(10, color: T.mute))])),
        const SizedBox(width: 8),
        if (pending) Btn('Claim ${ex.prize!.coins} 🪙', small: true, tone: Tone.green, onTap: () => s.claimCup(cup.id))
        else if (inIt) Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('#$rank', style: head(16, color: cup.color)), Text('${ex.pts} cp', style: body(10, color: T.mute))])
        else Btn('Join · ${cup.entry} 🪙', small: true, onTap: () => s.joinCup(cup.id)),
      ]),
      if (pending) Padding(padding: const EdgeInsets.only(top: 8), child: Text('Last week you finished #${ex.finalRank} (${ex.prize!.label}) · ${ex.prize!.coins} coins + ${ex.prize!.trophies} trophies waiting', style: body(11, color: T.green))),
      if (isOpen) ...[
        const SizedBox(height: 10),
        Text('STANDINGS', style: body(10, color: T.mute, w: FontWeight.w800)),
        for (var i = 0; i < 8; i++) Padding(padding: const EdgeInsets.only(top: 4), child: Row(children: [SizedBox(width: 28, child: Text('#${i + 1}', style: body(11, color: T.mute))), Expanded(child: Text(table[i].name, style: body(11))), Text('${table[i].pts} cp', style: body(11, w: FontWeight.w700))])),
        if (inIt) Padding(padding: const EdgeInsets.only(top: 6), child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), decoration: BoxDecoration(color: cup.color.withOpacity(.12), borderRadius: BorderRadius.circular(8)), child: Row(children: [SizedBox(width: 28, child: Text('#$rank', style: body(11, color: cup.color, w: FontWeight.w800))), Expanded(child: Text(s.profile.name.isEmpty ? 'You' : s.profile.name, style: body(11, w: FontWeight.w800))), Text('${ex.pts} cp', style: body(11, w: FontWeight.w800))]))),
        const SizedBox(height: 8),
        Text('PRIZES', style: body(10, color: T.mute, w: FontWeight.w800)),
        for (final p in cupPrizes) Padding(padding: const EdgeInsets.only(top: 3), child: Row(children: [SizedBox(width: 90, child: Text(p.label, style: body(11, color: T.mute))), Text('${fmtCoins(p.coins)} 🪙 · +${p.trophies} 🏆', style: body(11))])),
      ],
    ])));
  }
}
