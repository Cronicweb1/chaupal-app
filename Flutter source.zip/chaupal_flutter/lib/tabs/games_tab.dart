import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

class GamesTab extends StatefulWidget {
  final AppStore store;
  final void Function(String id, int n, {bool quick, String? modeId}) onStart;
  final void Function(int tab) goTab;
  const GamesTab({super.key, required this.store, required this.onStart, required this.goTab});
  @override
  State<GamesTab> createState() => _GamesTabState();
}

class _GamesTabState extends State<GamesTab> {
  int feat = 0; Timer? t;
  late final live = {for (final g in games) g.id: 2000 + Random().nextInt(14000)};
  static const featured = [('ludo', 'TRENDING', 'Ludo · Score Rush', 'All tokens open. Every box is a point. 7 minutes.', T.red), ('carrom', 'MOST PLAYED', 'Carrom · Freestyle', 'Pocket anything. First to 120.', T.yellow), ('uttt', 'NEW FORMAT', 'Tic Tac Toe · Infinity', 'Only three marks stay. No draws, ever.', T.blue)];
  @override
  void initState() { super.initState(); t = Timer.periodic(const Duration(seconds: 6), (_) => setState(() => feat = (feat + 1) % 3)); }
  @override
  void dispose() { t?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final hour = DateTime.now().hour;
    final greet = hour < 12 ? 'Subah ka round?' : hour < 17 ? 'Lunch break match?' : 'Shaam ho gayi';
    final quick = s.history.isNotEmpty ? gameOf(s.history[0].game) : games[0];
    final qm = formatsOf(quick.id)[quick.id == 'ludo' ? 1 : 0];
    final f = featured[feat];
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('$greet${s.profile.name.isNotEmpty ? ', ${s.profile.name}' : ''}', style: body(11, color: T.yellow, w: FontWeight.w600)), Text('Kya khelenge aaj?', style: head(24))])),
        if (s.liveStreak >= 1) Pill('🔥 ${s.liveStreak} day${s.liveStreak == 1 ? '' : 's'}', color: const Color(0xFFFF9A8A)),
      ]),
      const SizedBox(height: 16),
      // quick play
      GestureDetector(onTap: () => widget.onStart(quick.id, 2, quick: true, modeId: qm.id), child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), decoration: BoxDecoration(color: T.yellow, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: T.yellow.withOpacity(.25), blurRadius: 24, offset: const Offset(0, 10))]),
        child: Row(children: [const Text('⚡', style: TextStyle(fontSize: 24)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Quick Play', style: head(16, color: const Color(0xFF241B00))), Text('${quick.name} · ${qm.name} · 2 players', style: body(11, color: const Color(0xFF5A4600), w: FontWeight.w600))])),
          Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: const Color(0xFF241B00), borderRadius: BorderRadius.circular(12)), child: Text('GO', style: head(12, color: T.yellow)))]))),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: Panel(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text("Today's grind", style: head(12)), const SizedBox(height: 4),
          Text('${min(3, s.gamesToday)}/3 games · ${min(1, s.winsToday)}/1 win', style: body(10, color: T.mute)), const SizedBox(height: 6),
          Row(children: [for (var i = 0; i < 3; i++) Expanded(child: Container(height: 6, margin: EdgeInsets.only(right: i < 2 ? 4 : 0), decoration: BoxDecoration(color: i < s.gamesToday ? T.green : T.line, borderRadius: BorderRadius.circular(99))))]),
          const SizedBox(height: 4),
          Text(s.gamesToday >= 3 ? '+30 🪙 ready in Profile' : '${3 - min(3, s.gamesToday)} more for +30 🪙', style: body(10, color: s.gamesToday >= 3 ? T.green : T.yellow, w: FontWeight.w600)),
        ]))),
        const SizedBox(width: 12),
        Expanded(child: _LuckySpin(done: s.spinDone, onWon: s.spinWon)),
      ]),
      const SizedBox(height: 12),
      // events
      SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
        _event('🪔', 'Diwali Lights · ends ${collection.ends}', 'Limited board, dice & frame', const Color(0xFFE7A94F), () => widget.goTab(3)),
        const SizedBox(width: 8),
        _event('🏆', 'Weekly cups are live', 'Join with coins, win trophies', T.green, () => widget.goTab(1)),
      ])),
      const SizedBox(height: 12),
      // featured
      GestureDetector(onTap: () => _sheet(gameOf(f.$1)), child: Container(height: 140, padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: LinearGradient(colors: [f.$5.withOpacity(.8), Color.lerp(f.$5, Colors.black, .6)!]), borderRadius: BorderRadius.circular(24), boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 28, offset: Offset(0, 12))]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(99)), child: Text(f.$2, style: body(9, color: Colors.white, w: FontWeight.w900))),
          Text(f.$3, style: head(20, color: Colors.white)), Text(f.$4, style: body(11, color: Colors.white70)),
          Row(children: [Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)), child: Text('Play now', style: head(12, color: const Color(0xFF1A1206)))), const Spacer(), for (var i = 0; i < 3; i++) Container(width: i == feat ? 14 : 6, height: 6, margin: const EdgeInsets.only(left: 4), decoration: BoxDecoration(color: i == feat ? Colors.white : Colors.white38, borderRadius: BorderRadius.circular(99)))]),
        ]))),
      const SizedBox(height: 12),
      GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .95, children: [
        for (final g in games) GestureDetector(onTap: () => _sheet(g), child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(gradient: LinearGradient(colors: [g.accent.withOpacity(.15), T.panel], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24), border: Border.all(color: g.accent.withOpacity(.27))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Container(width: 54, height: 54, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(16)), child: Text(g.glyph, style: const TextStyle(fontSize: 28))), Row(children: [Container(width: 6, height: 6, decoration: const BoxDecoration(color: T.green, shape: BoxShape.circle)), const SizedBox(width: 4), Text('${(live[g.id]! / 1000).round()}k', style: body(9, w: FontWeight.w700))])]),
            const Spacer(),
            Text(g.name, style: head(15)), Text(g.tag, style: body(10, color: T.mute)),
            const SizedBox(height: 6),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(g.counts.length > 1 ? '${g.counts.first}–${g.counts.last} players' : '2 players', style: body(10, color: g.accent, w: FontWeight.w600)), if ((s.stats.byGame[g.id]?[0] ?? 0) > 0) Text('${s.stats.byGame[g.id]![1]}W · ${s.stats.byGame[g.id]![0]}P', style: body(10, color: T.mute))]),
          ]))),
      ]),
      const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: T.panel2, borderRadius: BorderRadius.circular(14)), child: Text('Every game has a clock, a format picker and placing rewards. Coins never become cash.', textAlign: TextAlign.center, style: body(10, color: T.mute))),
    ]);
  }

  Widget _event(String glyph, String title, String sub, Color c, VoidCallback f) => GestureDetector(onTap: f, child: Container(width: 220, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(gradient: LinearGradient(colors: [c.withOpacity(.3), T.panel]), borderRadius: BorderRadius.circular(12), border: Border.all(color: c.withOpacity(.4))),
      child: Row(children: [Text(glyph, style: const TextStyle(fontSize: 20)), const SizedBox(width: 8), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: head(11)), Text(sub, style: body(10, color: T.mute))]))])));

  void _sheet(GameDef g) {
    final rec = widget.store.stats.byGame[g.id];
    showSheet(context, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Text(g.glyph, style: const TextStyle(fontSize: 34)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(g.name, style: head(22)), Text(g.blurb, style: body(12, color: T.mute))])), if (rec != null) Text('${rec[1]}W · ${rec[0]}P', style: body(11, color: T.mute))]),
      const SizedBox(height: 12),
      Text('FORMATS', style: body(10, color: T.mute, w: FontWeight.w800)),
      for (final m in formatsOf(g.id)) Padding(padding: const EdgeInsets.only(top: 6), child: Row(children: [Text(m.glyph, style: const TextStyle(fontSize: 16)), const SizedBox(width: 8), Expanded(child: Text('${m.name} — ${m.tag}', style: body(11, color: T.mute)))])),
      const SizedBox(height: 16),
      Text('PLAYERS', style: body(10, color: T.mute, w: FontWeight.w800)),
      const SizedBox(height: 8),
      Row(children: [for (final n in g.counts) ...[Expanded(child: Btn('$n players', onTap: () { Navigator.pop(context); widget.onStart(g.id, n); })), if (n != g.counts.last) const SizedBox(width: 8)]]),
      const SizedBox(height: 8),
      Text('1st 100 · 2nd 50 · 3rd & 4th 30 coins. Watch a short ad after the match to double.', style: body(10, color: T.mute)),
    ]));
  }
}

class _LuckySpin extends StatefulWidget {
  final bool done; final void Function(int) onWon;
  const _LuckySpin({required this.done, required this.onWon});
  @override
  State<_LuckySpin> createState() => _LuckySpinState();
}
class _LuckySpinState extends State<_LuckySpin> {
  double rot = 0; bool busy = false; int? won;
  void go() {
    if (widget.done || busy) return;
    final idx = Random().nextInt(spinWheel.length), seg = 360 / spinWheel.length;
    setState(() { busy = true; rot += 1440 + (360 - (idx * seg + seg / 2)) - (rot % 360); });
    Timer(const Duration(milliseconds: 3200), () { if (!mounted) return; setState(() { busy = false; won = spinWheel[idx]; }); widget.onWon(spinWheel[idx]); });
  }
  @override
  Widget build(BuildContext context) {
    final seg = 360 / spinWheel.length;
    return Panel(onTap: go, padding: const EdgeInsets.all(10), border: widget.done ? T.line : T.yellow.withOpacity(.4), child: Opacity(opacity: widget.done && !busy ? .75 : 1, child: Row(children: [
      SizedBox(width: 52, height: 52, child: Stack(alignment: Alignment.topCenter, children: [
        AnimatedRotation(turns: rot / 360, duration: Duration(milliseconds: busy ? 3100 : 0), curve: Curves.easeOutCubic, child: Container(decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: T.yellow, width: 3), gradient: SweepGradient(colors: [for (var i = 0; i < spinWheel.length; i++) ...[T.pc[i % 4], T.pc[i % 4]]], stops: [for (var i = 0; i < spinWheel.length; i++) ...[i * seg / 360, (i + 1) * seg / 360]])))),
        const Icon(Icons.arrow_drop_down, color: Colors.white, size: 22),
      ])),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(widget.done ? (won != null ? '+$won coins!' : 'Spun today') : busy ? 'Spinning…' : 'Lucky Spin', style: head(12)), Text(widget.done ? 'Back tomorrow' : 'Free · up to 500 🪙', style: body(10, color: T.mute))])),
    ])));
  }
}
