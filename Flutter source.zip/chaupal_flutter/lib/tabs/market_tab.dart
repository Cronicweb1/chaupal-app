import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

class MarketTab extends StatefulWidget {
  final AppStore store;
  const MarketTab({super.key, required this.store});
  @override
  State<MarketTab> createState() => _MarketTabState();
}

class _MarketTabState extends State<MarketTab> {
  String cat = 'dice';
  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final c = cats.firstWhere((x) => x.id == cat);
    final dailyDone = s.dailyLast == todayKey();
    final nextDay = s.dailyLast.isEmpty ? 0 : (dailyDone ? s.dailyDay : (s.dailyDay + 1) % 7);
    final deals = s.dailyDeals();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(crossAxisAlignment: CrossAxisAlignment.end, children: [Expanded(child: Text('Market', style: head(24))), Text('${fmtCoins(s.coins)} 🪙 · ${s.rerolls} ↻', style: body(12, color: T.yellow, w: FontWeight.w700))]),
      Text('Skins, frames, emotes and effects are yours for good. Coins never become cash.', style: body(12, color: T.mute)),
      const SizedBox(height: 12),
      // daily reward
      Panel(border: dailyDone ? T.line : T.green.withOpacity(.5), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text('Daily reward', style: head(14))), Btn(dailyDone ? 'Collected' : 'Collect +${dailyCoins[nextDay]} 🪙', small: true, tone: Tone.green, onTap: dailyDone ? null : () => s.dailyClaim())]),
        const SizedBox(height: 8),
        Row(children: [for (var i = 0; i < 7; i++) Expanded(child: Container(margin: EdgeInsets.only(right: i < 6 ? 4 : 0), padding: const EdgeInsets.symmetric(vertical: 6), decoration: BoxDecoration(color: i == nextDay && !dailyDone ? T.green.withOpacity(.2) : T.panel2, borderRadius: BorderRadius.circular(8), border: Border.all(color: i == nextDay ? T.green : T.line)), child: Column(children: [Text('D${i + 1}', style: body(8, color: T.mute)), Text('${dailyCoins[i]}', style: body(11, w: FontWeight.w800)), if (i == 6) Text('+3↻', style: body(8, color: T.yellow))])))]),
      ])),
      const SizedBox(height: 12),
      // season pass
      Panel(border: T.violet.withOpacity(.5), onTap: _passSheet, child: Row(children: [
        Container(width: 44, height: 44, alignment: Alignment.center, decoration: BoxDecoration(color: T.violet.withOpacity(.15), borderRadius: BorderRadius.circular(14)), child: const Text('🎟️', style: TextStyle(fontSize: 22))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(seasonName, style: head(14)), Text('Level ${s.passLevel}/$passLevels · ${s.passXp % passXpPerLevel}/$passXpPerLevel XP · ends $seasonEnds', style: body(10, color: T.mute)), const SizedBox(height: 4), ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: s.passLevel >= passLevels ? 1 : (s.passXp % passXpPerLevel) / passXpPerLevel, minHeight: 4, color: T.violet, backgroundColor: T.line))])),
        const SizedBox(width: 8), Pill(s.passPremium ? 'PREMIUM' : 'FREE TRACK', color: s.passPremium ? T.yellow : T.mute),
      ])),
      const SizedBox(height: 12),
      // deals
      Text('TODAY\'S DEALS · 30% OFF · RESET AT MIDNIGHT', style: body(10, color: T.mute, w: FontWeight.w800)),
      const SizedBox(height: 8),
      Row(children: [for (final it in deals) Expanded(child: Padding(padding: EdgeInsets.only(right: it == deals.last ? 0 : 8), child: _card(s, it, deal: true)))]),
      const SizedBox(height: 12),
      // collection
      Panel(border: const Color(0xFFE7A94F).withOpacity(.6), color: const Color(0xFF3F1B08).withOpacity(.5), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Text('🪔', style: TextStyle(fontSize: 22)), const SizedBox(width: 8), Expanded(child: Text('${collection.name} · ends ${collection.ends}', style: head(14))), Pill(s.hasSet('diwali') ? 'SET COMPLETE' : '${collection.items.where((i) => s.owned.contains(i)).length}/3', color: const Color(0xFFE7A94F))]),
        Text('Limited set · owning all three unlocks the Legend title', style: body(10, color: T.mute)),
        const SizedBox(height: 8),
        Row(children: [for (final id in collection.items) Expanded(child: Padding(padding: EdgeInsets.only(right: id == collection.items.last ? 0 : 8), child: _card(s, itemById(id)!)))]),
      ])),
      const SizedBox(height: 14),
      SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [for (final x in cats) GestureDetector(onTap: () => setState(() => cat = x.id), child: Container(margin: const EdgeInsets.only(right: 6), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: cat == x.id ? T.yellow : T.panel, borderRadius: BorderRadius.circular(99), border: Border.all(color: T.line)), child: Text(x.name, style: body(11, w: FontWeight.w700, color: cat == x.id ? const Color(0xFF241B00) : T.ink))))])),
      const SizedBox(height: 10),
      GridView.count(crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: .72, children: [for (final it in c.items) _card(s, it)]),
    ]);
  }

  Widget _preview(Item it) {
    switch (it.cat) {
      case 'dice': return DiceWidget(value: 5, size: 40, face: it.faceC!, pip: it.pip!, color: Colors.transparent);
      case 'boards': return Container(width: 40, height: 40, decoration: BoxDecoration(gradient: LinearGradient(colors: it.boardC!), borderRadius: BorderRadius.circular(8), border: Border.all(color: it.frameC![0], width: 4)));
      case 'strikers': return Container(width: 40, height: 40, decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [Colors.white, it.color!, Colors.black54], stops: const [0, .4, 1], center: const Alignment(-.4, -.4))));
      case 'frames': return Face('f1', size: 40, frame: it.color, glow: it.double_);
      case 'pawns': return Icon(it.id == 'crown' ? Icons.emoji_events : it.id == 'pin' ? Icons.place : it.id == 'disc' ? Icons.circle : Icons.person, color: T.red, size: 36);
      default: return Text(it.glyph ?? '✨', style: const TextStyle(fontSize: 28));
    }
  }

  Widget _card(AppStore s, Item it, {bool deal = false}) {
    final owned = s.owns(it), equipped = it.slot != null && s.equipped.get(it.slot!) == it.id;
    final price = deal ? (it.price * .7).round() : it.price;
    final r = rarities[it.rarity]!;
    return GestureDetector(
      onTap: () {
        if (it.slot != null && owned) { s.equip(it); return; }
        if (owned) { s.showToast('Already owned'); return; }
        if (deal) { if (s.spend(price)) { s.owned.add(it.id); if (it.slot != null) s.equipped.set(it.slot!, it.id); s.showToast('${it.name} is yours · saved ${it.price - price}'); s.save(); } else { s.showToast('Not enough coins'); } return; }
        s.buy(it);
      },
      child: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: T.panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: equipped ? T.yellow : owned ? T.green.withOpacity(.5) : T.line)), child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Pill(r.name.toUpperCase(), color: r.color),
        _preview(it),
        Text(it.name, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: body(10, w: FontWeight.w700)),
        Text(equipped ? 'Equipped' : owned ? (it.slot != null ? 'Tap to equip' : 'Owned') : deal ? '$price 🪙 (was ${it.price})' : it.price == 0 ? 'Free' : '$price 🪙', textAlign: TextAlign.center, style: body(9, color: equipped ? T.yellow : owned ? T.green : T.mute, w: FontWeight.w600)),
      ])),
    );
  }

  void _passSheet() {
    final s = widget.store;
    showSheet(context, StatefulBuilder(builder: (ctx, setS) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(seasonName, style: head(20))), if (!s.passPremium) Btn('Premium · $passPrice 🪙', small: true, onTap: () { s.buyPass(); setS(() {}); })]),
      Text('Every match adds pass XP (win 100, place 40). $passXpPerLevel XP a level. Premium unlocks the second row for the whole season.', style: body(11, color: T.mute)),
      const SizedBox(height: 10),
      SizedBox(height: 320, child: ListView(children: [for (var l = 1; l <= passLevels; l++) Padding(padding: const EdgeInsets.only(bottom: 6), child: Row(children: [
        SizedBox(width: 30, child: Text('L$l', style: body(11, color: l <= s.passLevel ? T.yellow : T.mute, w: FontWeight.w800))),
        Expanded(child: _passCell(s, l, false, setS)), const SizedBox(width: 6), Expanded(child: _passCell(s, l, true, setS)),
      ]))])),
    ])));
  }
  Widget _passCell(AppStore s, int l, bool prem, void Function(void Function()) setS) {
    final r = prem ? passTrack[l - 1].prem : passTrack[l - 1].free;
    final k = '$l${prem ? 'p' : 'f'}', claimed = s.passClaimed.contains(k), can = l <= s.passLevel && (!prem || s.passPremium) && !claimed;
    return GestureDetector(onTap: can ? () { s.passClaim(l, prem); setS(() {}); } : null, child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), decoration: BoxDecoration(color: claimed ? T.green.withOpacity(.1) : can ? T.yellow.withOpacity(.15) : T.panel2, borderRadius: BorderRadius.circular(8), border: Border.all(color: can ? T.yellow : T.line)),
      child: Row(children: [Expanded(child: Text(r.label(), maxLines: 1, overflow: TextOverflow.ellipsis, style: body(11, w: FontWeight.w700, color: claimed ? T.green : prem && !s.passPremium ? T.mute : T.ink))), Text(claimed ? '✓' : can ? 'claim' : prem && !s.passPremium ? '🔒' : '', style: body(9, color: T.mute))])));
  }
}
