import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

class ProfileTab extends StatefulWidget {
  final AppStore store;
  const ProfileTab({super.key, required this.store});
  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  int pane = 0; // 0 you · 1 vibe · 2 status
  late final nameC = TextEditingController(text: widget.store.profile.name);
  late final ageC = TextEditingController(text: widget.store.profile.age);
  String note = '';
  @override
  void dispose() { nameC.dispose(); ageC.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final s = widget.store, p = s.profile, lvl = s.level, lg = leagueOf(s.trophies);
    final earned = badges.where((b) => b.test(s)).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      // header card
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(gradient: LinearGradient(colors: [s.tr.color.withOpacity(.25), T.panel], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24), border: Border.all(color: s.tr.color.withOpacity(.4))),
        child: Row(children: [
          Face(p.avatar, size: 64, frame: frameOf(s.equipped.frame).color, glow: frameOf(s.equipped.frame).double_),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(p.name.isEmpty ? 'Set your name' : p.name, style: head(20)),
            Text('${s.tr.glyph} ${s.tr.name} · Level $lvl ${levelTitle(lvl)} · ${lg.glyph} ${lg.name}', style: body(11, color: T.mute)),
            const SizedBox(height: 6),
            ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: (s.stats.xp % 500) / 500, minHeight: 5, color: T.yellow, backgroundColor: T.line)),
            Text('${s.stats.xp % 500}/500 XP · ${s.stats.played} played · ${s.stats.wins} wins · ${s.trophies} 🏆', style: body(10, color: T.mute)),
          ])),
        ])),
      const SizedBox(height: 12),
      // missions
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text("Today's missions", style: head(14)),
        for (final m in missions) Padding(padding: const EdgeInsets.only(top: 10), child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(m.name, style: body(12, w: FontWeight.w700)), const SizedBox(height: 4), ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: (m.have(s) / m.need).clamp(0.0, 1.0).toDouble(), minHeight: 4, color: T.green, backgroundColor: T.line))])),
          const SizedBox(width: 12),
          s.claimed.contains(m.id) ? const Pill('Claimed', color: T.green) : Btn('+${m.reward} 🪙', small: true, onTap: m.have(s) >= m.need ? () => s.claimMission(m) : null),
        ])),
      ])),
      const SizedBox(height: 12),
      // badges
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Badges · ${earned.length}/${badges.length}', style: head(14)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [for (final b in badges) GestureDetector(onTap: () { if (b.test(s) && !s.badgesClaimed.contains(b.id)) { s.claimBadge(b); } else { s.showToast('${b.name}: ${b.how}'); } },
          child: Container(width: 92, padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: b.test(s) ? T.yellow.withOpacity(.1) : T.panel2, borderRadius: BorderRadius.circular(12), border: Border.all(color: b.test(s) && !s.badgesClaimed.contains(b.id) ? T.yellow : T.line)),
            child: Column(children: [Opacity(opacity: b.test(s) ? 1 : .35, child: Text(b.glyph, style: const TextStyle(fontSize: 22))), Text(b.name, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: body(10, w: FontWeight.w700)), Text(s.badgesClaimed.contains(b.id) ? 'claimed' : b.test(s) ? 'tap to claim' : b.how, textAlign: TextAlign.center, maxLines: 2, style: body(8, color: T.mute))])))]),
      ])),
      const SizedBox(height: 12),
      Row(children: [for (var i = 0; i < 3; i++) Expanded(child: GestureDetector(onTap: () => setState(() => pane = i), child: Container(margin: EdgeInsets.only(right: i < 2 ? 6 : 0), padding: const EdgeInsets.symmetric(vertical: 8), alignment: Alignment.center, decoration: BoxDecoration(color: pane == i ? T.yellow : T.panel, borderRadius: BorderRadius.circular(10), border: Border.all(color: T.line)), child: Text(['You', 'Vibe', 'Status'][i], style: body(11, w: FontWeight.w800, color: pane == i ? const Color(0xFF241B00) : T.ink)))))]),
      const SizedBox(height: 12),
      if (pane == 0) _you(s, p) else if (pane == 1) _vibe(s, p) else _status(s),
      const SizedBox(height: 12),
      _invite(s),
      const SizedBox(height: 12),
      if (s.history.isNotEmpty) Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Recent games', style: head(14)), for (final h in s.history.take(6)) Padding(padding: const EdgeInsets.only(top: 6), child: Row(children: [Text(gameOf(h.game).glyph), const SizedBox(width: 8), Expanded(child: Text(gameOf(h.game).name, style: body(12))), Text(['1st', '2nd', '3rd', '4th'][h.rank.clamp(0, 3).toInt()], style: body(11, color: h.rank == 0 ? T.green : T.mute)), const SizedBox(width: 10), Text('+${h.pay} 🪙', style: body(11, color: T.yellow, w: FontWeight.w700))]))])),
      const SizedBox(height: 12),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Playing safe', style: head(14)), const SizedBox(height: 4),
        Text('Never share your number, address, school or UPI — not even in a friendly room. Break reminders appear after 45 minutes. Coins are a score, never cash.\n\nGrievance officer: grievance@chaupal.example · replies within 48 hours.', style: body(11, color: T.mute)),
        const SizedBox(height: 10),
        Row(children: [Btn('Replay the tour', small: true, tone: Tone.dark, onTap: s.replayTour), const SizedBox(width: 8), Text('${s.playMins} min played this session', style: body(10, color: T.mute))]),
      ])),
    ]);
  }

  Widget _field(String label, Widget child, {String? hint}) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label.toUpperCase(), style: body(10, color: T.mute, w: FontWeight.w800)), const SizedBox(height: 4), child, if (hint != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text(hint, style: body(10, color: T.mute)))]));
  InputDecoration _deco(String hint) => InputDecoration(hintText: hint, hintStyle: body(12, color: T.mute), filled: true, fillColor: T.panel2, isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: T.line)));

  Widget _you(AppStore s, Profile p) => Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _field('Display name', Row(children: [Expanded(child: TextField(controller: nameC, enabled: !p.nameLocked, style: body(13), decoration: _deco('3–16 letters, numbers, _'))), const SizedBox(width: 8), if (!p.nameLocked) Btn('Save', small: true, onTap: () { final err = checkName(nameC.text); if (err != null) { setState(() => note = err); return; } s.updateProfile((q) { q.name = nameC.text.trim(); q.nameLocked = true; }); setState(() => note = 'Name set — it cannot be changed later.'); })]), hint: p.nameLocked ? 'Locked. Names are permanent.' : 'One chance only. Choose well.'),
        _field('Age', Row(children: [Expanded(child: TextField(controller: ageC, enabled: !p.ageLocked, keyboardType: TextInputType.number, inputFormatters: [FilteringTextInputFormatter.digitsOnly], style: body(13), decoration: _deco('Unlocks Baithak at 18+'))), const SizedBox(width: 8), if (!p.ageLocked) Btn('Save', small: true, onTap: () { final a = int.tryParse(ageC.text) ?? 0; if (a < 6 || a > 99) { setState(() => note = 'Enter a real age.'); return; } s.updateProfile((q) { q.age = '$a'; q.ageLocked = true; if (a < 18) q.everMinor = true; }); setState(() => note = a >= 18 ? 'Baithak unlocked.' : 'Chat stays off for under-18 accounts.'); })]), hint: p.ageLocked ? 'Locked. Age is set once.' : 'Set once. Under-18 accounts never get chat, even after a birthday.'),
        _field('Avatar', Wrap(spacing: 8, runSpacing: 8, children: [for (final f in faceIds) GestureDetector(onTap: () => s.updateProfile((q) => q.avatar = f), child: Container(padding: const EdgeInsets.all(2), decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: p.avatar == f ? T.yellow : Colors.transparent, width: 2)), child: Face(f, size: 40)))])),
        _field('Interests', Wrap(spacing: 6, runSpacing: 6, children: [for (final i in interests) _chip(i, p.interests.contains(i), () => s.updateProfile((q) { if (q.interests.contains(i)) { q.interests.remove(i); } else { q.interests.add(i); } }))])),
        _field('Hobbies', Wrap(spacing: 6, runSpacing: 6, children: [for (final i in hobbies) _chip(i, p.hobbies.contains(i), () => s.updateProfile((q) { if (q.hobbies.contains(i)) { q.hobbies.remove(i); } else { q.hobbies.add(i); } }))])),
        if (note.isNotEmpty) Text(note, style: body(11, color: T.yellow)),
      ]));

  Widget _chip(String t, bool on, VoidCallback f) => GestureDetector(onTap: f, child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: on ? T.yellow.withOpacity(.15) : T.panel2, borderRadius: BorderRadius.circular(99), border: Border.all(color: on ? T.yellow : T.line)), child: Text(t, style: body(11, w: FontWeight.w600, color: on ? T.yellow : T.ink))));

  Widget _vibe(AppStore s, Profile p) => Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Vibe check', style: head(14)), Text(s.vibe != null ? 'You are a ${vibeNames[s.vibe]}. Rooms are ranked by match.' : 'Three quick picks. Baithak rooms get a match % once you finish.', style: body(11, color: T.mute)),
        for (var i = 0; i < quiz.length; i++) Padding(padding: const EdgeInsets.only(top: 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(quiz[i].q, style: body(12, w: FontWeight.w700)), const SizedBox(height: 6), Wrap(spacing: 6, runSpacing: 6, children: [for (final a in quiz[i].a) _chip(a.$1, p.quiz['$i'] == a.$2, () => s.updateProfile((q) => q.quiz['$i'] = a.$2))])])),
      ]));

  Widget _status(AppStore s) => Column(children: [for (final t in tiers) Padding(padding: const EdgeInsets.only(bottom: 8), child: Panel(border: s.tier == t.id ? t.color : T.line, child: Row(children: [
        Container(width: 44, height: 44, alignment: Alignment.center, decoration: BoxDecoration(color: t.color.withOpacity(.15), borderRadius: BorderRadius.circular(14)), child: Text(t.glyph, style: const TextStyle(fontSize: 22))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t.name, style: head(14, color: t.color)), Text(t.perk, style: body(10, color: T.mute)), if (t.upkeep > 0) Text('Upkeep: ${t.upkeep} games a day${s.tier == t.id && s.grace ? ' · WARNING DAY' : ''}', style: body(10, color: T.red))])),
        const SizedBox(width: 8),
        s.tier == t.id ? const Pill('Active', color: T.green) : Btn(s.tierBought.contains(t.id) ? 'Wear' : t.cost == 0 ? 'Switch' : '${fmtCoins(t.cost)} 🪙', small: true, tone: Tone.dark, onTap: () => s.buyTier(t)),
      ]))))]);

  Widget _invite(AppStore s) => Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Invite friends', style: head(14)), Text('They get 250 coins when they enter your code while signing up. You get 500. Two referrals a day count.', style: body(11, color: T.mute)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), decoration: BoxDecoration(color: T.panel2, borderRadius: BorderRadius.circular(12), border: Border.all(color: T.line)), child: Text(s.refCode, style: body(14, color: T.yellow, w: FontWeight.w800)))),
          const SizedBox(width: 8),
          Btn('Copy', small: true, tone: Tone.dark, onTap: () { Clipboard.setData(ClipboardData(text: s.refCode)); s.showToast('Code copied'); }),
          const SizedBox(width: 8),
          Btn('WhatsApp', small: true, tone: Tone.green, onTap: () => launchUrl(Uri.parse('https://wa.me/?text=${Uri.encodeComponent('Aa jao Chaupal pe 🎲 Ludo, Carrom aur bhi. Mera code ${s.refCode} lagao — 250 coins free!')}'), mode: LaunchMode.externalApplication)),
        ]),
        const SizedBox(height: 8),
        Text('Today ${s.refsToday} of 2 · ${s.refsTotal} friends joined so far · ${s.refRedeemed.isNotEmpty ? 'You joined with ${s.refRedeemed}' : "You didn't use a code"}', style: body(10, color: T.mute)),
      ]));
}
