import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

/// Design tokens — lacquered-night board room.
class T {
  static const bg = Color(0xFF0F0D1A);
  static const panel = Color(0xFF181530);
  static const panel2 = Color(0xFF211C3C);
  static const line = Color(0xFF2E2850);
  static const ink = Color(0xFFF4F0E6);
  static const mute = Color(0xFF958DB9);
  static const red = Color(0xFFE8523F);
  static const green = Color(0xFF2FB67C);
  static const yellow = Color(0xFFF5C542);
  static const blue = Color(0xFF4A8DFF);
  static const violet = Color(0xFFC77DFF);
  static const pc = [red, green, yellow, blue];
  static const pname = ['Red', 'Green', 'Yellow', 'Blue'];
}

Color hex(String h) {
  var s = h.replaceAll('#', '');
  if (s.length == 6) s = 'FF$s';
  return Color(int.parse(s, radix: 16));
}

TextStyle head(double size, {Color color = T.ink, FontWeight w = FontWeight.w800}) =>
    TextStyle(fontSize: size, color: color, fontWeight: w, letterSpacing: -0.3, height: 1.15);
TextStyle body(double size, {Color color = T.ink, FontWeight w = FontWeight.w500}) =>
    TextStyle(fontSize: size, color: color, fontWeight: w, height: 1.3);

String fmtCoins(int n) {
  // Indian grouping: 5,00,000
  final s = n.abs().toString();
  if (s.length <= 3) return (n < 0 ? '-' : '') + s;
  final last3 = s.substring(s.length - 3);
  var rest = s.substring(0, s.length - 3);
  final parts = <String>[];
  while (rest.length > 2) {
    parts.insert(0, rest.substring(rest.length - 2));
    rest = rest.substring(0, rest.length - 2);
  }
  if (rest.isNotEmpty) parts.insert(0, rest);
  return (n < 0 ? '-' : '') + '${parts.join(',')},$last3';
}

enum Tone { brass, ghost, dark, red, green }

class Btn extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final Tone tone;
  final bool small;
  final bool full;
  const Btn(this.label, {super.key, this.onTap, this.tone = Tone.brass, this.small = false, this.full = false});

  @override
  Widget build(BuildContext context) {
    Color bg, fg, br = Colors.transparent;
    switch (tone) {
      case Tone.brass: bg = T.yellow; fg = const Color(0xFF241B00); break;
      case Tone.ghost: bg = Colors.transparent; fg = T.ink; br = T.line; break;
      case Tone.dark: bg = T.panel2; fg = T.ink; br = T.line; break;
      case Tone.red: bg = T.red; fg = const Color(0xFF2A0A05); break;
      case Tone.green: bg = T.green; fg = const Color(0xFF03231A); break;
    }
    final child = Opacity(
      opacity: onTap == null ? 0.4 : 1,
      child: Material(
        color: bg,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: small ? 12 : 16, vertical: small ? 7 : 11),
            decoration: BoxDecoration(border: Border.all(color: br), borderRadius: BorderRadius.circular(12)),
            alignment: Alignment.center,
            child: Text(label, textAlign: TextAlign.center, style: body(small ? 12 : 14, color: fg, w: FontWeight.w700)),
          ),
        ),
      ),
    );
    return full ? SizedBox(width: double.infinity, child: child) : child;
  }
}

class Panel extends StatelessWidget {
  final Widget child;
  final Color? color;
  final Color? border;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  const Panel({super.key, required this.child, this.color, this.border, this.padding = const EdgeInsets.all(16), this.onTap});
  @override
  Widget build(BuildContext context) {
    final box = Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? T.panel,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: border ?? T.line),
      ),
      child: child,
    );
    if (onTap == null) return box;
    return GestureDetector(onTap: onTap, child: box);
  }
}

class Pill extends StatelessWidget {
  final String text;
  final Color color;
  const Pill(this.text, {super.key, this.color = T.mute});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(color: color.withOpacity(.14), borderRadius: BorderRadius.circular(99)),
        child: Text(text, style: body(10, color: color, w: FontWeight.w700)),
      );
}

/// Avatar faces — original palette-based marks (no licensed characters).
const faceIds = ['f1', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8'];
const _faceColors = [Color(0xFF4A8DFF), Color(0xFFC0454E), Color(0xFF2FB67C), Color(0xFFF5C542), Color(0xFFC77DFF), Color(0xFFFF7A59), Color(0xFF3FBFA8), Color(0xFFE7A94F)];
const _faceGlyphs = ['◐', '◑', '◒', '◓', '◈', '◉', '◍', '◎'];

class Face extends StatelessWidget {
  final String id;
  final double size;
  final Color? frame;
  final bool glow;
  const Face(this.id, {super.key, this.size = 40, this.frame, this.glow = false});
  @override
  Widget build(BuildContext context) {
    var i = faceIds.indexOf(id);
    if (i < 0) i = 0;
    final c = _faceColors[i];
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        color: c.withOpacity(.22),
        borderRadius: BorderRadius.circular(size * .3),
        border: frame != null ? Border.all(color: frame!, width: 1.5) : null,
        boxShadow: glow && frame != null ? [BoxShadow(color: frame!, blurRadius: 6)] : null,
      ),
      alignment: Alignment.center,
      child: Text(_faceGlyphs[i], style: TextStyle(fontSize: size * .55, color: c, height: 1)),
    );
  }
}

/// Player seat header used by all four boards.
class Seat extends StatelessWidget {
  final int p;
  final String name;
  final bool you, active;
  final String sub;
  final String avatar;
  final int? score;
  final double? timer; // 0..1
  final Color? frame;
  const Seat({super.key, required this.p, required this.name, this.you = false, this.active = false, this.sub = '', this.avatar = 'f1', this.score, this.timer, this.frame});
  @override
  Widget build(BuildContext context) {
    final c = T.pc[p];
    return Expanded(
      child: Container(
        clipBehavior: Clip.antiAlias,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        decoration: BoxDecoration(
          color: active ? c.withOpacity(.18) : Colors.white.withOpacity(.04),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: active ? c : Colors.transparent),
        ),
        child: Stack(children: [
          Row(children: [
            Face(avatar, size: 22, frame: frame),
            const SizedBox(width: 6),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text(you ? 'You' : name, maxLines: 1, overflow: TextOverflow.ellipsis, style: body(10, w: FontWeight.w800)),
              Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: body(9, color: c)),
            ])),
            if (score != null) Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('$score', style: head(13)),
              Text('pts', style: body(8, color: T.mute)),
            ]),
          ]),
          if (timer != null)
            Positioned(left: 0, right: 0, bottom: 0, child: Container(height: 3, color: Colors.black26, alignment: Alignment.centerLeft,
              child: FractionallySizedBox(widthFactor: timer!.clamp(0.0, 1.0).toDouble(), child: Container(color: timer! < .3 ? T.red : c)))),
        ]),
      ),
    );
  }
}

const pips = {
  1: [[.5, .5]], 2: [[.29, .29], [.71, .71]], 3: [[.26, .26], [.5, .5], [.74, .74]],
  4: [[.29, .29], [.71, .29], [.29, .71], [.71, .71]],
  5: [[.29, .29], [.71, .29], [.5, .5], [.29, .71], [.71, .71]],
  6: [[.29, .24], [.71, .24], [.29, .5], [.71, .5], [.29, .76], [.71, .76]],
};

class DiceWidget extends StatefulWidget {
  final int? value;
  final bool rolling, enabled, glow;
  final VoidCallback? onTap;
  final Color color;
  final List<Color> face;
  final Color pip;
  final double size;
  const DiceWidget({super.key, this.value, this.rolling = false, this.enabled = true, this.glow = false, this.onTap, this.color = T.yellow, this.face = const [Color(0xFFFFFEF9), Color(0xFFDCD1B6)], this.pip = const Color(0xFF2A2247), this.size = 54});
  @override
  State<DiceWidget> createState() => _DiceState();
}

class _DiceState extends State<DiceWidget> with SingleTickerProviderStateMixin {
  int shown = 1;
  Timer? t;
  late final AnimationController spin = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
  @override
  void initState() { super.initState(); shown = widget.value ?? 1; _sync(); }
  @override
  void didUpdateWidget(DiceWidget o) { super.didUpdateWidget(o); _sync(); }
  void _sync() {
    if (widget.rolling) {
      spin.repeat();
      t ??= Timer.periodic(const Duration(milliseconds: 55), (_) => setState(() => shown = 1 + Random().nextInt(6)));
    } else {
      t?.cancel(); t = null; spin.stop(); spin.value = 0;
      if (widget.value != null) shown = widget.value!;
    }
  }
  @override
  void dispose() { t?.cancel(); spin.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.enabled ? widget.onTap : null,
      child: Opacity(
        opacity: widget.enabled ? 1 : .4,
        child: RotationTransition(
          turns: spin,
          child: Container(
            width: widget.size, height: widget.size,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: widget.face, begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(widget.size * .26),
              border: Border.all(color: widget.color, width: 3),
              boxShadow: widget.glow ? [BoxShadow(color: T.yellow.withOpacity(.7), blurRadius: 12)] : [const BoxShadow(color: Colors.black45, blurRadius: 6, offset: Offset(0, 3))],
            ),
            child: CustomPaint(painter: _PipPainter(shown, widget.pip)),
          ),
        ),
      ),
    );
  }
}

class _PipPainter extends CustomPainter {
  final int v; final Color c;
  _PipPainter(this.v, this.c);
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()..color = c;
    for (final xy in pips[v] ?? pips[1]!) {
      canvas.drawCircle(Offset(xy[0] * s.width, xy[1] * s.height), s.width * .09, p);
    }
  }
  @override
  bool shouldRepaint(_PipPainter o) => o.v != v || o.c != c;
}

/// Bottom-sheet helper with the app's dark chrome.
Future<T?> showSheet<T>(BuildContext context, Widget child) => showModalBottomSheet<T>(
      context: context,
      backgroundColor: T.panel,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 12, bottom: 24 + MediaQuery.of(context).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: T.line, borderRadius: BorderRadius.circular(99))),
          const SizedBox(height: 12),
          child,
        ]),
      ),
    );

/// Simple 4-quadrant colour of a seat, tinted.
Color tint(Color c, double a) => c.withOpacity(a);
