import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'carrom.dart';
import 'common.dart';
import 'ludo.dart';
import 'snakes.dart';
import 'ttt.dart';

const adSecs = 15;
const adStock = [('Chaupal Pro', 'Skip ads, keep the coins', T.yellow), ('Weekly Carrom Cup', 'Free entry · starts Friday', T.green), ('Dice skins are here', '500 coins in Market', T.blue)];

class Bubble { final int id; final String text, who; final int p; Bubble(this.id, this.text, this.p, this.who); }

class GameHost extends StatefulWidget {
  final AppStore store;
  final String gameId;
  final int n;
  final bool quick;
  final String? modeId;
  final VoidCallback onBack;
  const GameHost({super.key, required this.store, required this.gameId, required this.n, required this.onBack, this.quick = false, this.modeId});
  @override
  State<GameHost> createState() => _GameHostState();
}

class _GameHostState extends State<GameHost> {
  late final GameDef game = gameOf(widget.gameId);
  Mode? mode;
  String phase = 'mode'; // mode | queue | play
  List<Player> roster = [];
  int left = 600, redoLeft = 3, found = 1, adLeft = adSecs, matchKey = 0;
  bool timeUp = false, leaveAsk = false;
  ({int rank, int pay})? result;
  String ad = 'offer'; // offer | watching | doubled
  final feed = <Bubble>[];
  Timer? clock, queueT, adT;
  final rnd = Random();
  late final int online = 3200 + rnd.nextInt(9000);

  @override
  void initState() {
    super.initState();
    final fm = formatsOf(game.id).where((m) => m.players.contains(widget.n)).toList();
    if (widget.quick) { mode = fm.firstWhere((m) => m.id == widget.modeId, orElse: () => fm[game.id == 'ludo' && fm.length > 1 ? 1 : 0]); _startQueue(initial: true); }
    else if (fm.length == 1) { mode = fm[0]; _startQueue(initial: true); }
  }
  @override
  void dispose() { clock?.cancel(); queueT?.cancel(); adT?.cancel(); super.dispose(); }

  void _startQueue({bool initial = false}) {
    left = mode!.secsFor(widget.n); phase = 'queue'; found = 1;
    final me = widget.store;
    final pool = [...botNames]..shuffle(rnd);
    final seats = seatsFor[widget.n]!;
    roster = [for (var i = 0; i < seats.length; i++) i == 0 ? Player(seats[i], me.profile.name.isEmpty ? 'You' : me.profile.name, me.profile.avatar, you: true, frame: me.equipped.frame) : Player(seats[i], pool[i], faceIds[(i * 3 + 1) % faceIds.length])];
    if (!initial) setState(() {});
    void step() {
      if (!mounted) return;
      if (found >= widget.n) { queueT = Timer(const Duration(milliseconds: 700), () { if (mounted) _startPlay(); }); return; }
      queueT = Timer(Duration(milliseconds: 700 + rnd.nextInt(900)), () { if (!mounted) return; setState(() => found++); step(); });
    }
    step();
  }
  void _startPlay() {
    setState(() { phase = 'play'; timeUp = false; result = null; redoLeft = 3; feed.clear(); matchKey++; ad = 'offer'; adLeft = adSecs; });
    clock?.cancel();
    clock = Timer.periodic(const Duration(seconds: 1), (_) { if (!mounted || result != null) return; if (left <= 0) { setState(() => timeUp = true); clock?.cancel(); } else { setState(() => left--); } });
  }

  void say(String text, int p, String who) {
    final id = rnd.nextInt(1 << 30);
    setState(() { feed.add(Bubble(id, text, p, who)); if (feed.length > 2) feed.removeAt(0); });
    Timer(const Duration(milliseconds: 2600), () { if (mounted) setState(() => feed.removeWhere((b) => b.id == id)); });
  }

  void finish(int rank) {
    if (result != null) return;
    final pay = [100, 50, 30, 30][rank.clamp(0, 3).toInt()];
    setState(() { result = (rank: rank, pay: pay); ad = 'offer'; adLeft = adSecs; });
    widget.store.onResult(rank, pay, game.id);
  }
  void watchAd() {
    setState(() { ad = 'watching'; adLeft = adSecs; });
    adT?.cancel();
    adT = Timer.periodic(const Duration(seconds: 1), (t) { if (!mounted) { t.cancel(); return; } if (adLeft <= 1) { t.cancel(); setState(() => ad = 'doubled'); widget.store.grant(result!.pay); } else { setState(() => adLeft--); } });
  }
  void share() {
    final place = ['1st', '2nd', '3rd', '4th'][result!.rank.clamp(0, 3).toInt()];
    final msg = 'I just came $place in ${game.name}${mode != null ? ' · ${mode!.name}' : ''} on Chaupal 🎲 Beat me? Use my code ${widget.store.refCode} for 250 free coins.';
    launchUrl(Uri.parse('https://wa.me/?text=${Uri.encodeComponent(msg)}'), mode: LaunchMode.externalApplication);
  }

  GameCtx _ctx() => GameCtx(
        n: widget.n, roster: roster, mode: mode!, equip: widget.store.equipped, onEnd: finish, say: say,
        tryRedo: () { if (redoLeft <= 0) return false; if (!widget.store.useReroll() && !widget.store.spend(20)) return false; setState(() => redoLeft--); return true; },
        redoLeft: () => redoLeft, redoPacks: () => widget.store.rerolls,
      );

  @override
  Widget build(BuildContext context) {
    if (phase == 'mode') return _modePicker();
    if (phase == 'queue') return _matchmaking();
    final ctx = _ctx();
    final lowTime = left < 60;
    final board = switch (game.id) {
      'ludo' => LudoGame(key: ValueKey('l$matchKey'), ctx: ctx, timeUp: timeUp),
      'carrom' => CarromGame(key: ValueKey('c$matchKey'), ctx: ctx, timeUp: timeUp),
      'uttt' => TttGame(key: ValueKey('t$matchKey'), ctx: ctx, timeUp: timeUp),
      _ => SlGame(key: ValueKey('s$matchKey'), ctx: ctx, timeUp: timeUp),
    };
    return Stack(children: [
      Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(8, 4, 12, 4), child: Row(children: [
          IconButton(onPressed: () { if (result == null) setState(() => leaveAsk = true); else widget.onBack(); }, icon: const Icon(Icons.chevron_left, color: T.ink)),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(game.name, style: head(13)), Text('${widget.n} players · ${mode!.name} · 1st 100 🪙', style: body(9, color: T.mute))])),
          Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: lowTime ? T.red.withOpacity(.15) : Colors.white.withOpacity(.06), borderRadius: BorderRadius.circular(8)),
            child: Row(children: [Icon(Icons.schedule, size: 11, color: lowTime ? T.red : T.mute), const SizedBox(width: 4), Text('${left ~/ 60}:${(left % 60).toString().padLeft(2, '0')}', style: body(11, w: FontWeight.w700, color: lowTime ? T.red : T.ink))])),
        ])),
        Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Stack(children: [
          board,
          Positioned(left: 0, right: 0, top: 4, child: IgnorePointer(child: Column(children: [for (final b in feed) Container(margin: const EdgeInsets.only(bottom: 4), padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: T.bg.withOpacity(.9), borderRadius: BorderRadius.circular(99), border: Border.all(color: T.pc[b.p].withOpacity(.4))),
            child: Text.rich(TextSpan(children: [TextSpan(text: '${b.who} ', style: body(11, color: T.pc[b.p])), TextSpan(text: b.text, style: body(11))])))]))),
        ]))),
        Padding(padding: const EdgeInsets.fromLTRB(12, 4, 12, 8), child: _ChatBar(store: widget.store, onSay: (t) => say(t, 0, 'You'))),
      ]),
      if (result != null) _resultOverlay(),
      if (leaveAsk) _leaveDialog(),
    ]);
  }

  Widget _modePicker() {
    final fm = formatsOf(game.id).where((m) => m.players.contains(widget.n)).toList();
    return Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [IconButton(onPressed: widget.onBack, icon: const Icon(Icons.chevron_left, color: T.ink)), Text('${game.name} · ${widget.n} players', style: head(18))]),
      Text('Pick a format', style: body(12, color: T.mute)),
      const SizedBox(height: 12),
      for (final m in fm) Padding(padding: const EdgeInsets.only(bottom: 10), child: Panel(onTap: () { setState(() => mode = m); _startQueue(); }, border: m.color.withOpacity(.4), child: Row(children: [
        Container(width: 44, height: 44, alignment: Alignment.center, decoration: BoxDecoration(color: m.color.withOpacity(.15), borderRadius: BorderRadius.circular(14)), child: Text(m.glyph, style: const TextStyle(fontSize: 22))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(m.name, style: head(15)), const SizedBox(height: 2), Text(m.tag, style: body(11, color: T.mute)), const SizedBox(height: 4), Text('${m.secsFor(widget.n) ~/ 60} min clock', style: body(10, color: m.color, w: FontWeight.w700))])),
      ]))),
    ]));
  }

  Widget _matchmaking() {
    return Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(game.glyph, style: const TextStyle(fontSize: 40)), const SizedBox(height: 8),
      Text(game.name, style: head(24)), Text('${fmtCoins(online)} playing right now', style: body(11, color: T.mute)),
      const SizedBox(height: 20),
      for (var i = 0; i < roster.length; i++) Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(color: i < found ? T.pc[roster[i].seat].withOpacity(.12) : T.panel, borderRadius: BorderRadius.circular(12), border: Border.all(color: i < found ? T.pc[roster[i].seat].withOpacity(.4) : T.line)),
        child: Row(children: [Opacity(opacity: i < found ? 1 : .25, child: Face(roster[i].avatar, size: 32)), const SizedBox(width: 10), Expanded(child: Text(i < found ? roster[i].name : 'waiting…', style: body(12, w: FontWeight.w700, color: i < found ? T.ink : T.mute))), Container(width: 8, height: 8, decoration: BoxDecoration(color: i < found ? T.pc[roster[i].seat] : T.line, shape: BoxShape.circle))])),
      const SizedBox(height: 12),
      Text(found >= widget.n ? 'Starting…' : 'Finding players $found of ${widget.n}', style: body(11, color: T.yellow, w: FontWeight.w600)),
      const SizedBox(height: 8),
      SizedBox(width: 160, child: LinearProgressIndicator(value: found / widget.n, color: T.yellow, backgroundColor: T.line, minHeight: 4, borderRadius: BorderRadius.circular(99))),
      const SizedBox(height: 20),
      Btn('Cancel', tone: Tone.ghost, small: true, onTap: widget.onBack),
    ]));
  }

  Widget _resultOverlay() {
    final r = result!, rw = widget.store.rewardsFor(r.rank, game.id), fx = fxOf(widget.store.equipped.fx);
    return Container(color: T.bg.withOpacity(.92), padding: const EdgeInsets.all(24), alignment: Alignment.center, child: Stack(alignment: Alignment.center, children: [
      if (r.rank == 0) ...[for (var i = 0; i < 18; i++) Positioned(left: (i * 37 % 100) / 100 * 300.0, top: (i * 53 % 100) / 100 * 500.0, child: Text(fx.pieces == null ? '▮' : fx.pieces![i % fx.pieces!.length], style: TextStyle(fontSize: 18, color: [T.red, T.green, T.yellow, T.blue, T.violet][i % 5])))],
      Panel(border: r.rank == 0 ? T.green : T.line, child: Column(children: [
        Text(['🥇', '🥈', '🥉', '🎖️'][r.rank.clamp(0, 3).toInt()], style: const TextStyle(fontSize: 40)),
        const SizedBox(height: 8),
        Text(['Pehla sthaan! 🔥', 'Second place', 'Third place', 'Fourth place'][r.rank.clamp(0, 3).toInt()], style: head(20, color: r.rank == 0 ? T.green : T.ink)),
        Text(ad == 'doubled' ? '+${r.pay * 2} coins · doubled' : '+${r.pay} coins added', style: body(14, color: T.yellow, w: FontWeight.w700)),
        Text('${rw.trophies >= 0 ? '+' : ''}${rw.trophies} 🏆${rw.cups.map((c) => ' · +${c.cp} ${c.name}').join()}', style: body(11, color: rw.trophies >= 0 ? T.green : T.red)),
        const SizedBox(height: 16),
        if (ad == 'offer') ...[Btn('▶ Watch ${adSecs}s ad · double to ${r.pay * 2} 🪙', full: true, onTap: watchAd), const SizedBox(height: 6), Text('Optional. Your ${r.pay} coins are already yours.', style: body(10, color: T.mute))],
        if (ad == 'watching') Container(decoration: BoxDecoration(color: T.panel2, borderRadius: BorderRadius.circular(12), border: Border.all(color: T.line)), child: Column(children: [
          Padding(padding: const EdgeInsets.all(12), child: Column(children: [const Pill('AD'), const SizedBox(height: 4), Text(adStock[adLeft % 3].$1, style: body(14, color: adStock[adLeft % 3].$3, w: FontWeight.w700)), Text(adStock[adLeft % 3].$2, style: body(10, color: T.mute))])),
          LinearProgressIndicator(value: (adSecs - adLeft) / adSecs, color: T.yellow, backgroundColor: T.line, minHeight: 6),
          Padding(padding: const EdgeInsets.all(6), child: Text('Bonus in ${adLeft}s', style: body(11, w: FontWeight.w600))),
        ])),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: Btn('Leave', tone: Tone.ghost, onTap: widget.onBack)), const SizedBox(width: 8),
          Expanded(child: Btn('Share 💬', tone: Tone.dark, onTap: share)), const SizedBox(width: 8),
          Expanded(child: Btn('Rematch', onTap: () { adT?.cancel(); setState(() { result = null; }); _startQueue(); })),
        ]),
      ])),
    ]));
  }

  Widget _leaveDialog() => Container(color: T.bg.withOpacity(.9), padding: const EdgeInsets.all(24), alignment: Alignment.center, child: Panel(border: T.red.withOpacity(.4), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Leave the game?', style: head(18)), const SizedBox(height: 8),
        Text("You'll forfeit this match, and any coins you would have earned from it are lost. Coins already spent on re-rolls or chat aren't refunded.", style: body(13, color: T.mute)),
        const SizedBox(height: 16),
        Row(children: [Expanded(child: Btn('Stay', tone: Tone.ghost, onTap: () => setState(() => leaveAsk = false))), const SizedBox(width: 8), Expanded(child: Btn('Leave', tone: Tone.red, onTap: widget.onBack))]),
      ])));
}

class _ChatBar extends StatefulWidget {
  final AppStore store; final void Function(String) onSay;
  const _ChatBar({required this.store, required this.onSay});
  @override
  State<_ChatBar> createState() => _ChatBarState();
}
class _ChatBarState extends State<_ChatBar> {
  String? panel; final ctl = TextEditingController();
  @override
  void dispose() { ctl.dispose(); super.dispose(); }
  Widget tab(String id, String label) => Expanded(child: GestureDetector(onTap: () => setState(() => panel = panel == id ? null : id), child: Container(padding: const EdgeInsets.symmetric(vertical: 7), alignment: Alignment.center,
      decoration: BoxDecoration(color: panel == id ? T.yellow : Colors.white.withOpacity(.05), borderRadius: BorderRadius.circular(10), border: Border.all(color: T.line)), child: Text(label, style: body(10, w: FontWeight.w700, color: panel == id ? const Color(0xFF241B00) : T.ink)))));
  @override
  Widget build(BuildContext context) {
    final extra = [for (final pk in emotePacks) if (widget.store.owned.contains(pk.id)) ...pk.emojis!];
    final words = ctl.text.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length, cost = words * wordCost;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      if (panel == 'emoji') Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: T.panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: T.line)),
        child: Wrap(spacing: 6, runSpacing: 6, children: [for (final e in [...chatEmoji, ...extra]) GestureDetector(onTap: () { widget.onSay(e); setState(() => panel = null); }, child: Container(width: 44, height: 44, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.white.withOpacity(.05), borderRadius: BorderRadius.circular(12)), child: Text(e, style: const TextStyle(fontSize: 22))))])),
      if (panel == 'quick') Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: T.panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: T.line)),
        child: Wrap(spacing: 6, runSpacing: 6, children: [for (final q in quickSay) GestureDetector(onTap: () { widget.onSay(q); setState(() => panel = null); }, child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: Colors.white.withOpacity(.06), borderRadius: BorderRadius.circular(99), border: Border.all(color: T.line)), child: Text(q, style: body(11, w: FontWeight.w700))))])),
      if (panel == 'words') Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: T.panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: T.line)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Emojis and quick lines are free. Typed words cost $wordCost coins each.', style: body(10, color: T.mute)), const SizedBox(height: 6),
        Row(children: [
          Expanded(child: TextField(controller: ctl, maxLength: 40, onChanged: (_) => setState(() {}), style: body(12), decoration: InputDecoration(counterText: '', hintText: 'type a short message', hintStyle: body(12, color: T.mute), filled: true, fillColor: T.panel2, isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: T.line))))),
          const SizedBox(width: 6),
          Btn('$cost 🪙', small: true, onTap: words == 0 || widget.store.coins < cost ? null : () {
            final v = moderate(ctl.text);
            if (v != null) { widget.onSay('(not sent — ${v.$1})'); if (v.$2 >= 2) widget.store.addStrike(); ctl.clear(); setState(() => panel = null); return; }
            if (!widget.store.spend(cost)) return; widget.onSay(ctl.text.trim()); ctl.clear(); setState(() => panel = null);
          }),
        ]),
      ])),
      Row(children: [tab('emoji', '😊  Emoji'), const SizedBox(width: 8), tab('quick', '💬  Quick'), const SizedBox(width: 8), tab('words', 'abc  Words · $wordCost each')]),
    ]);
  }
}
