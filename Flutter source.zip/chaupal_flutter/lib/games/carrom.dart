import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import '../models.dart';
import '../sound.dart';
import '../theme.dart';
import 'common.dart';

const cb = 400.0, cr = 9.2, sr = 12.4, pock = 21.0;
const pockets = [Offset(32, 32), Offset(cb - 32, 32), Offset(32, cb - 32), Offset(cb - 32, cb - 32)];
const coinPts = {'w': 20, 'b': 10, 'queen': 50};

class Piece { double x, y, vx = 0, vy = 0; final double r; final String t; bool alive = true; Piece(this.x, this.y, this.r, this.t); }

List<Piece> carromSetup(bool withQueen) {
  final ps = <Piece>[if (withQueen) Piece(200, 200, cr, 'queen')];
  for (var i = 0; i < 6; i++) { final a = i * pi / 3; ps.add(Piece(200 + cos(a) * 19.5, 200 + sin(a) * 19.5, cr, i.isEven ? 'w' : 'b')); }
  for (var i = 0; i < 12; i++) { final a = i * pi / 6 + pi / 12; ps.add(Piece(200 + cos(a) * 39, 200 + sin(a) * 39, cr, i.isEven ? 'b' : 'w')); }
  return ps;
}

class Hit { final Piece p; final double t; Hit(this.p, this.t); }
Hit? firstHit(double sx, double sy, double dx, double dy, List<Piece> pieces) {
  Hit? best;
  for (final p in pieces) {
    if (!p.alive) continue;
    final rx = p.x - sx, ry = p.y - sy, t = rx * dx + ry * dy;
    if (t <= 0) continue;
    final px = sx + dx * t - p.x, py = sy + dy * t - p.y, d = sqrt(px * px + py * py), rad = sr + cr;
    if (d > rad) continue;
    final tt = t - sqrt(rad * rad - d * d);
    if (best == null || tt < best.t) best = Hit(p, tt);
  }
  return best;
}

class CarromGame extends StatefulWidget {
  final GameCtx ctx; final bool timeUp;
  const CarromGame({super.key, required this.ctx, required this.timeUp});
  @override
  State<CarromGame> createState() => _CarromState();
}

class _CarromState extends State<CarromGame> with SingleTickerProviderStateMixin {
  late final bool colour = widget.ctx.mode.id != 'free';
  late final List<int> seats = seatsFor[widget.ctx.n]!;
  late final List<Piece> pieces = carromSetup(widget.ctx.mode.id != 'disc');
  Piece striker = Piece(200, cb - 62, sr, 's');
  late Map<int, int> score = {for (final s in seats) s: 0}, got = {for (final s in seats) s: 0};
  late Map<int, String>? own = colour ? {seats[0]: 'w', seats[1]: 'b'} : null;
  late int turn = seats[0];
  int? queenBy; bool coverDue = false, done = false, moving = false, aiming = false, ended = false;
  double slide = .5; int tleft = 30;
  String msg = 'Slide to place, drag back to aim';
  Offset? drag; FxLabel? fx;
  final pocketed = <String>[]; bool foul = false;
  late final Ticker ticker = createTicker(_frame);
  Duration? lastT; Timer? clock, botT, watchdog, fxT;
  final rnd = Random();
  int get human => widget.ctx.human;
  int sideIdx(int t) => seats.indexOf(t) % 4;

  @override
  void initState() { super.initState(); strikerHome(turn, slide); clock = Timer.periodic(const Duration(seconds: 1), (_) => _tick()); _scheduleBot(); }
  @override
  void didUpdateWidget(CarromGame o) { super.didUpdateWidget(o); if (widget.timeUp && !o.timeUp && !done) _finish(); }
  @override
  void dispose() { ticker.dispose(); clock?.cancel(); botT?.cancel(); watchdog?.cancel(); fxT?.cancel(); super.dispose(); }

  void strikerHome(int t, double sv) {
    final sd = sideIdx(t), off = 62.0, u = 96 + sv * 208;
    final pos = [[u, cb - off], [off, cb - u], [cb - u, off], [cb - off, u]][sd];
    striker = Piece(pos[0], pos[1], sr, 's');
  }
  List<double> freeSpot() {
    for (var k = 0; k < 40; k++) { final a = rnd.nextDouble() * pi * 2, rad = 12 + rnd.nextDouble() * 36; final x = 200 + cos(a) * rad, y = 200 + sin(a) * rad;
      if (!pieces.any((p) => p.alive && sqrt(pow(p.x - x, 2) + pow(p.y - y, 2)) < cr * 2.1)) return [x, y]; }
    return [200, 200];
  }
  bool returnCoin(String type) { final p = pieces.where((q) => !q.alive && q.t == type).firstOrNull; if (p == null) return false; final s = freeSpot(); p.x = s[0]; p.y = s[1]; p.vx = 0; p.vy = 0; p.alive = true; return true; }

  void _tick() {
    if (!mounted || done || moving || aiming) return;
    if (tleft <= 0) { if (turn == human) { setState(() => msg = 'Time — auto shot'); botShot(human); } return; }
    setState(() => tleft--);
  }
  void _scheduleBot() {
    botT?.cancel();
    if (done || moving || turn == human) return;
    botT = Timer(const Duration(milliseconds: 900), () { if (!mounted || done || moving || turn == human) return; if (rnd.nextDouble() < .12) widget.ctx.say(chatEmoji[rnd.nextInt(8)], turn, widget.ctx.nameOf(turn)); setState(() => msg = '${widget.ctx.nameOf(turn)} shoots'); botShot(turn); });
  }

  void shoot(double ux, double uy, double pw) {
    pocketed.clear(); foul = false;
    striker.vx = ux * pw; striker.vy = uy * pw;
    Sfx.play('strike');
    setState(() { moving = true; msg = ''; });
    lastT = null; ticker.start();
    watchdog?.cancel();
    watchdog = Timer(const Duration(seconds: 8), () { if (!moving) return; ticker.stop(); for (final p in [...pieces, striker]) { p.vx = 0; p.vy = 0; } settle(); });
  }

  void _frame(Duration t) {
    final dt = lastT == null ? 16.7 : (t - lastT!).inMicroseconds / 1000;
    lastT = t;
    final steps = dt.isNaN ? 1 : (dt / 16.7).round().clamp(1, 6).toInt();
    for (var i = 0; i < steps; i++) { _step(); }
    final all = [...pieces.where((p) => p.alive), if (striker.alive) striker];
    if (!all.any((p) => p.vx != 0 || p.vy != 0)) { ticker.stop(); watchdog?.cancel(); settle(); }
    else { setState(() {}); }
  }
  double _lastClick = 0;
  void _step() {
    final all = [...pieces.where((p) => p.alive), if (striker.alive) striker];
    for (final p in all) {
      p.x += p.vx; p.y += p.vy; p.vx *= .984; p.vy *= .984;
      if (sqrt(p.vx * p.vx + p.vy * p.vy) < .07) { p.vx = 0; p.vy = 0; }
      final lo = 26 + p.r, hi = cb - 26 - p.r;
      if (p.x < lo) { p.x = lo; p.vx = -p.vx * .72; } if (p.x > hi) { p.x = hi; p.vx = -p.vx * .72; }
      if (p.y < lo) { p.y = lo; p.vy = -p.vy * .72; } if (p.y > hi) { p.y = hi; p.vy = -p.vy * .72; }
    }
    for (var i = 0; i < all.length; i++) {
      for (var j = i + 1; j < all.length; j++) {
        final a = all[i], b = all[j];
        final dx = b.x - a.x, dy = b.y - a.y, d = sqrt(dx * dx + dy * dy), mn = a.r + b.r;
        if (d > 0 && d < mn) {
          final nx = dx / d, ny = dy / d, ov = (mn - d) / 2;
          a.x -= nx * ov; a.y -= ny * ov; b.x += nx * ov; b.y += ny * ov;
          final ma = a.t == 's' ? 1.5 : 1.0, mb = b.t == 's' ? 1.5 : 1.0;
          final rv = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
          if (rv < 0) {
            final im = (-1.86 * rv) / (1 / ma + 1 / mb);
            a.vx -= im * nx / ma; a.vy -= im * ny / ma; b.vx += im * nx / mb; b.vy += im * ny / mb;
            final now = DateTime.now().millisecondsSinceEpoch.toDouble();
            if (rv.abs() > 1.2 && now - _lastClick > 60) { _lastClick = now; Sfx.play('click'); }
          }
        }
      }
    }
    for (final p in all) { for (final pk in pockets) { if (p.alive && (Offset(p.x, p.y) - pk).distance < pock - 2) { p.alive = false; Sfx.play('pocket'); if (p.t == 's') foul = true; else pocketed.add(p.t); } } }
  }

  void settle() {
    final t = turn; var note = ''; var again = false; var pts = 0;
    final mode = widget.ctx.mode;
    if (!colour) {
      for (final ty in pocketed) { pts += coinPts[ty] ?? 0; }
      if (foul) { pts -= 10; note = 'Striker in — minus 10'; }
      score[t] = max(0, score[t]! + pts);
      again = pts > 0 && !foul;
      if (score[t]! >= mode.target || !pieces.any((p) => p.alive)) done = true;
    } else {
      final mine = own![t]!, opp = seats.firstWhere((s) => s != t);
      var ownHit = false;
      for (final ty in pocketed) {
        if (ty == 'queen') { queenBy = t; coverDue = true; note = 'Queen! Cover it'; pts += 50; }
        else if (ty == mine) { got[t] = got[t]! + 1; ownHit = true; pts += coinPts[ty]!; }
        else { got[opp] = got[opp]! + 1; note = "Opponent's coin — their point"; }
      }
      final myLeft = pieces.where((p) => p.alive && p.t == mine).length;
      if (mode.id == 'classic' && ownHit && myLeft == 0 && queenBy != t) { returnCoin(mine); got[t] = got[t]! - 1; note = 'Queen first — coin returned'; ownHit = false; }
      if (coverDue && queenBy == t && !pocketed.contains('queen')) {
        if (ownHit) { coverDue = false; note = 'Queen covered'; } else { returnCoin('queen'); queenBy = null; coverDue = false; note = 'No cover — queen returns'; }
      }
      if (foul) { if (got[t]! > 0 && returnCoin(mine)) got[t] = got[t]! - 1; note = 'Striker in — coin returned'; ownHit = false; }
      score[t] = got[t]! * 10 + (queenBy == t && !coverDue ? 50 : 0);
      again = ownHit && !foul;
      final cleared = !pieces.any((p) => p.alive && p.t == mine);
      if (cleared && (mode.id == 'disc' || (queenBy == t && !coverDue))) done = true;
    }
    if (pts != 0) { fx = FxLabel(200, 200, (pts > 0 ? '+' : '') + '$pts', pts > 0 ? T.green : T.red, 'fx'); fxT?.cancel(); fxT = Timer(const Duration(milliseconds: 900), () { if (mounted) setState(() => fx = null); }); }
    if (foul) Sfx.play('foul');
    striker.alive = true;
    if (done) { setState(() => moving = false); _finish(); return; }
    if (again) { msg = note.isEmpty ? 'Nice — shoot again' : note; strikerHome(t, slide); }
    else { turn = seats[(seats.indexOf(t) + 1) % seats.length]; msg = note.isEmpty ? (pocketed.isEmpty ? 'Missed — next player' : '') : note; strikerHome(turn, slide); }
    setState(() { moving = false; tleft = 30; });
    _scheduleBot();
  }

  void _finish() {
    if (ended) return; ended = true; done = true;
    final order = seats.toList()..sort((a, b) { final d = score[b]! - score[a]!; return d != 0 ? d : (a == turn ? -1 : 1); });
    setState(() {});
    widget.ctx.onEnd(colour ? (turn == human ? 0 : 1) : order.indexOf(human));
  }

  // bot: pick coin+pocket with a clear ghost-ball line, from the best baseline spot
  ({double sv, double ux, double uy, double pw})? planShot(int t) {
    bool targetable(Piece p) { if (!colour) return true; if (p.t == 'queen') return widget.ctx.mode.id == 'classic' && pieces.any((q) => q.alive && q.t == own![t]) && !coverDue; return p.t == own![t]; }
    ({double sv, double ux, double uy, double pw, double score})? best;
    for (var sv = .1; sv <= .9; sv += .2) {
      strikerHome(t, sv); final s = striker;
      for (final p in pieces) {
        if (!p.alive || !targetable(p)) continue;
        for (final pk in pockets) {
          final cx = pk.dx - p.x, cy = pk.dy - p.y, cd = sqrt(cx * cx + cy * cy);
          final gx = p.x - cx / cd * (sr + cr), gy = p.y - cy / cd * (sr + cr);
          final dx = gx - s.x, dy = gy - s.y, d = sqrt(dx * dx + dy * dy);
          if (d == 0) continue;
          final ux = dx / d, uy = dy / d, cut = ux * (cx / cd) + uy * (cy / cd);
          if (cut < .35) continue;
          final h = firstHit(s.x, s.y, ux, uy, pieces);
          if (h == null || h.p != p) continue;
          final val = p.t == 'queen' ? 3.0 : (p.t == 'w' && !colour ? 2.0 : 1.0);
          final sc = val * cut * cut / (1 + cd / 300) / (1 + d / 500);
          if (best == null || sc > best.score) best = (sv: sv, ux: ux, uy: uy, pw: 9 + min(8, (d + cd) / 45), score: sc);
        }
      }
    }
    return best == null ? null : (sv: best.sv, ux: best.ux, uy: best.uy, pw: best.pw);
  }
  void botShot(int t) {
    final plan = planShot(t);
    if (plan != null) {
      setState(() => slide = plan.sv); strikerHome(t, plan.sv);
      final jit = (rnd.nextDouble() - .5) * .045; final ux = plan.ux + jit, uy = plan.uy - jit, d = sqrt(ux * ux + uy * uy);
      shoot(ux / d, uy / d, plan.pw + rnd.nextDouble() * 2);
    } else {
      strikerHome(t, slide);
      final tgt = pieces.where((p) => p.alive).firstOrNull; if (tgt == null) return;
      final dx = tgt.x - striker.x, dy = tgt.y - striker.y, d = sqrt(dx * dx + dy * dy);
      shoot(dx / d, dy / d, 11);
    }
  }

  Offset _pt(Offset local, double side) => Offset(local.dx / side * cb, local.dy / side * cb);
  void _down(Offset p) {
    if (moving || done || turn != human) return;
    if ((p - Offset(striker.x, striker.y)).distance >= 56) return;
    setState(() { drag = p; aiming = true; });
  }
  void _release() {
    if (drag == null) return;
    final dx = striker.x - drag!.dx, dy = striker.y - drag!.dy, d = sqrt(dx * dx + dy * dy);
    setState(() { drag = null; aiming = false; });
    if (d < 12) return;
    shoot(dx / d, dy / d, min(d, 110) / 110 * 17);
  }

  @override
  Widget build(BuildContext context) {
    final ctx = widget.ctx, th = themeOf(ctx.equip.board), strikerC = strikerOf(ctx.equip.striker).color ?? T.yellow;
    return Column(children: [
      Row(children: [for (final s in seats) ...[
        Seat(p: s, name: ctx.nameOf(s), avatar: ctx.playerOf(s).avatar, you: s == human, active: turn == s && !done, score: score[s],
            sub: colour ? (own![s] == 'w' ? 'White · ${got[s]}/9' : 'Black · ${got[s]}/9') : 'to ${ctx.mode.target}',
            timer: turn == s && !done && !moving ? tleft / 30 : null, frame: frameOf(ctx.playerOf(s).frame).color),
        if (s != seats.last) const SizedBox(width: 4)]]),
      const SizedBox(height: 6),
      Expanded(child: SquareBox((side) => GestureDetector(
        onPanStart: (d) => _down(_pt(d.localPosition, side)),
        onPanUpdate: (d) { if (drag != null) setState(() => drag = _pt(d.localPosition, side)); },
        onPanEnd: (_) => _release(), onPanCancel: _release,
        child: Container(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 18, offset: Offset(0, 8))]),
          child: ClipRRect(borderRadius: BorderRadius.circular(14), child: CustomPaint(size: Size.square(side), painter: _CarromPainter(this, th, strikerC))),
        ),
      ))),
      const SizedBox(height: 6),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: Colors.white.withOpacity(.04), borderRadius: BorderRadius.circular(16), border: Border.all(color: T.line)),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(done ? 'Game over' : moving ? 'Rolling…' : turn == human ? (msg.isEmpty ? 'Your shot' : msg) : '${ctx.nameOf(turn)} playing', maxLines: 1, overflow: TextOverflow.ellipsis, style: body(12, w: FontWeight.w800)),
            SizedBox(height: 28, child: Slider(value: slide, onChanged: turn == human && !moving && !done ? (v) => setState(() { slide = v; strikerHome(human, v); }) : null, activeColor: strikerC, inactiveColor: T.line)),
          ])),
          Btn(ctx.redoPacks() > 0 ? '↻ pack ${ctx.redoPacks()} · ${ctx.redoLeft()}' : '↻ 20 🪙 · ${ctx.redoLeft()}', small: true, tone: Tone.dark,
              onTap: turn == human && !moving && !done && ctx.redoLeft() > 0 && foul ? () { if (ctx.tryRedo()) setState(() { score[human] = score[human]! + 10; foul = false; msg = 'Foul forgiven'; }); } : null),
        ]),
      ),
    ]);
  }
}

class _CarromPainter extends CustomPainter {
  final _CarromState s; final Item th; final Color strikerC;
  _CarromPainter(this.s, this.th, this.strikerC);
  @override
  void paint(Canvas c, Size size) {
    final k = size.width / cb; c.scale(k, k);
    c.drawRect(const Rect.fromLTWH(0, 0, cb, cb), Paint()..shader = const LinearGradient(colors: [Color(0xFF5A3512), Color(0xFF3E230B), Color(0xFF2A1706)]).createShader(const Rect.fromLTWH(0, 0, cb, cb)));
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(12, 12, cb - 24, cb - 24), const Radius.circular(10)), Paint()..color = const Color(0xFFC9973F)..style = PaintingStyle.stroke..strokeWidth = 2);
    final play = th.carromC ?? const [Color(0xFFF4E1BC), Color(0xFFDDBF8E)];
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(20, 20, cb - 40, cb - 40), const Radius.circular(8)), Paint()..shader = RadialGradient(colors: [play[0], play[1]], radius: .75).createShader(const Rect.fromLTWH(20, 20, cb - 40, cb - 40)));
    final red = Paint()..color = const Color(0xFF8A2B22)..style = PaintingStyle.stroke..strokeWidth = 2.5;
    c.drawRect(const Rect.fromLTWH(34, 34, cb - 68, cb - 68), red);
    c.drawCircle(const Offset(200, 200), 48, Paint()..color = const Color(0x228A2B22));
    c.drawCircle(const Offset(200, 200), 48, Paint()..color = const Color(0xFFB8894A)..style = PaintingStyle.stroke..strokeWidth = 1.2);
    c.drawCircle(const Offset(200, 200), 16, red..strokeWidth = 1.5);
    for (final deg in [45, 135, 225, 315]) { final a = deg * pi / 180; c.drawLine(Offset(200 + cos(a) * 58, 200 + sin(a) * 58), Offset(200 + cos(a) * 122, 200 + sin(a) * 122), Paint()..color = const Color(0x738A2B22)..strokeWidth = 1.6); }
    for (var sd = 0; sd < 4; sd++) {
      c.save(); c.translate(200, 200); c.rotate(pi / 2 * sd); c.translate(-200, -200);
      final on = sd == s.sideIdx(s.turn) && !s.done;
      final p = Paint()..color = on ? const Color(0xFF8A2B22) : const Color(0x668A2B22)..strokeWidth = on ? 4 : 2;
      c.drawLine(const Offset(84, cb - 62), const Offset(cb - 84, cb - 62), p);
      c.drawLine(const Offset(84, cb - 52), const Offset(cb - 84, cb - 52), p..strokeWidth = on ? 2 : 1);
      for (final x in [84.0, cb - 84]) { c.drawCircle(Offset(x, cb - 57), 6, Paint()..color = p.color); }
      c.restore();
    }
    for (final pk in pockets) {
      c.drawCircle(pk, pock + 3, Paint()..color = const Color(0xFF3A2208));
      c.drawCircle(pk, pock, Paint()..shader = const RadialGradient(colors: [Color(0xFF07050C), Color(0xFF171229), Color(0xFF2A2247)]).createShader(Rect.fromCircle(center: pk, radius: pock)));
      c.drawCircle(pk, pock + 1, Paint()..color = const Color(0xFFC9973F)..style = PaintingStyle.stroke..strokeWidth = 1.5);
    }
    for (final p in s.pieces) {
      if (!p.alive) continue;
      final o = Offset(p.x, p.y);
      c.drawCircle(o + const Offset(.5, 2), p.r, Paint()..color = Colors.black38);
      List<Color> g; Color ring, dot;
      if (p.t == 'queen') { g = const [Color(0xFFFF8E8A), Color(0xFFC42B3A), Color(0xFF7A1424)]; ring = Colors.white60; dot = const Color(0xFFFFD86B); }
      else if (p.t == 'w') { g = const [Color(0xFFFFFFFA), Color(0xFFEFE1C0), Color(0xFFC6AD80)]; ring = const Color(0x73785019); dot = const Color(0xFF8A2B22); }
      else { g = const [Color(0xFF6E6580), Color(0xFF2E2840), Color(0xFF151022)]; ring = Colors.white38; dot = T.yellow; }
      c.drawCircle(o, p.r, Paint()..shader = RadialGradient(colors: g, center: const Alignment(-.35, -.4)).createShader(Rect.fromCircle(center: o, radius: p.r)));
      c.drawCircle(o, p.r * .62, Paint()..color = ring..style = PaintingStyle.stroke..strokeWidth = 1.2);
      c.drawCircle(o, p.r * .2, Paint()..color = dot);
      if (s.colour && s.own != null && p.t == s.own![s.human] && !s.done) c.drawCircle(o, p.r + 2.5, Paint()..color = Colors.white54..style = PaintingStyle.stroke..strokeWidth = 1.2);
    }
    final st = s.striker;
    if (st.alive) {
      final o = Offset(st.x, st.y);
      c.drawCircle(o + const Offset(.5, 2.5), st.r, Paint()..color = Colors.black38);
      c.drawCircle(o, st.r, Paint()..shader = RadialGradient(colors: [Colors.white, strikerC, Colors.black54], stops: const [0, .4, 1], center: const Alignment(-.4, -.4)).createShader(Rect.fromCircle(center: o, radius: st.r)));
      c.drawCircle(o, st.r * .72, Paint()..color = Colors.white45..style = PaintingStyle.stroke..strokeWidth = 1.2);
      if (s.turn == s.human && !s.moving && !s.done) c.drawCircle(o, st.r + 6, Paint()..color = Colors.white38..style = PaintingStyle.stroke..strokeWidth = 1.5);
    }
    final d = s.drag;
    if (d != null) {
      final dx = st.x - d.dx, dy = st.y - d.dy, dist = sqrt(dx * dx + dy * dy);
      if (dist > 0) {
        final ux = dx / dist, uy = dy / dist, pw = min(dist, 110) / 110;
        final hit = firstHit(st.x, st.y, ux, uy, s.pieces);
        var endT = 600.0; const wall = 26 + sr;
        for (final t in [(wall - st.x) / ux, (cb - wall - st.x) / ux, (wall - st.y) / uy, (cb - wall - st.y) / uy]) { if (t > 0 && t < endT) endT = t; }
        if (hit != null && hit.t < endT) endT = hit.t;
        final end = Offset(st.x + ux * endT, st.y + uy * endT);
        c.drawLine(Offset(st.x, st.y), end, Paint()..color = Colors.white.withOpacity(.45 + pw * .45)..strokeWidth = 2.5);
        c.drawCircle(end, sr, Paint()..color = Colors.white70..style = PaintingStyle.stroke..strokeWidth = 2);
        if (hit != null) { final cx = hit.p.x - end.dx, cy = hit.p.y - end.dy, cd = sqrt(cx * cx + cy * cy); c.drawLine(Offset(hit.p.x, hit.p.y), Offset(hit.p.x + cx / cd * 70, hit.p.y + cy / cd * 70), Paint()..color = hit.p.t == 'queen' ? const Color(0xFFFF6B7A) : const Color(0xFFFFD86B)..strokeWidth = 3); }
        c.drawArc(Rect.fromCircle(center: Offset(st.x, st.y), radius: sr + 6 + pw * 10), -pi / 2, pi * 2 * pw, false, Paint()..color = pw > .8 ? const Color(0xFFFF6B5A) : const Color(0xFFFFD86B)..style = PaintingStyle.stroke..strokeWidth = 3);
      }
    }
    final fx = s.fx;
    if (fx != null) { final tp = TextPainter(text: TextSpan(text: fx.text, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: fx.color)), textDirection: TextDirection.ltr)..layout(); tp.paint(c, Offset(200 - tp.width / 2, 150)); }
  }
  @override
  bool shouldRepaint(_CarromPainter o) => true;
}
