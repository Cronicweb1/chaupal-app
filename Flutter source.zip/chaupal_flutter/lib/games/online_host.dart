import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../backend.dart';
import '../models.dart';
import '../realtime.dart';
import '../store.dart';
import '../theme.dart';
import 'common.dart';
import 'ludo.dart' as ludo;
import 'snakes.dart' as sl;
import 'ttt.dart' as ttt;

/// Online match against real players: the server owns every rule; this widget renders `match:state`
/// views with the same painters the offline boards use and sends intents (roll / move / mark / shot).
class OnlineHost extends StatefulWidget {
  final AppStore store; final String gameId; final int n; final String? modeId; final bool quick; final VoidCallback onBack;
  const OnlineHost({super.key, required this.store, required this.gameId, required this.n, required this.onBack, this.modeId, this.quick = false});
  @override
  State<OnlineHost> createState() => _OnlineHostState();
}

class _OnlineHostState extends State<OnlineHost> {
  late final GameDef game = gameOf(widget.gameId);
  Mode? mode; String phase = 'mode'; int found = 1; Map? view; Map? end; String ad = 'offer'; String err = '';
  final feed = <Map>[]; StreamSubscription? sub; Timer? clock; int tleft = 0; Offset? drag; List? shotFrames; int frameI = 0; Timer? anim;
  Live get live => Live.I;

  @override
  void initState() {
    super.initState();
    live.connect();
    sub = live.events.listen(_onEvent);
    final fm = formatsOf(game.id).where((m) => m.players.contains(widget.n)).toList();
    if (live.resumed != null) { view = Map.from(live.resumed!); phase = 'play'; _startClock(); }
    else if (widget.quick || fm.length == 1) { mode = fm.firstWhere((m) => m.id == widget.modeId, orElse: () => fm[game.id == 'ludo' && fm.length > 1 ? 1 : 0]); _queue(); }
    clock = Timer.periodic(const Duration(seconds: 1), (_) { if (view != null && mounted) setState(() => tleft = max(0, ((view!['endsAt'] as num) - DateTime.now().millisecondsSinceEpoch) ~/ 1000)); });
  }
  @override
  void dispose() { sub?.cancel(); clock?.cancel(); anim?.cancel(); super.dispose(); }
  void _startClock() {}

  Future<void> _queue() async {
    setState(() { phase = 'queue'; found = 1; err = ''; });
    final r = await live.emit('queue:join', {'game': game.id, 'mode': mode!.id, 'n': widget.n});
    if (r['ok'] != true && mounted) setState(() => err = r['message'] ?? r['code'] ?? 'Could not join');
  }
  void _onEvent((String, dynamic) e) {
    if (!mounted) return;
    final (ev, d) = e;
    switch (ev) {
      case 'queue:update': setState(() => found = (d['found'] as num).toInt());
      case 'match:start': case 'match:state': setState(() { view = Map.from(d as Map); phase = 'play'; });
      case 'match:say': setState(() { feed.add(Map.from(d)); if (feed.length > 2) feed.removeAt(0); }); Timer(const Duration(milliseconds: 2600), () { if (mounted) setState(() => feed.remove(d)); });
      case 'match:shot': _animateShot(d as Map);
      case 'match:end': setState(() { end = Map.from(d as Map); ad = 'offer'; }); Backend.get('/v1/me').then((j) => widget.store.applyMe(j)).catchError((_) {});
      case 'match:error': setState(() => err = d['message'] ?? '');
      case 'disconnect': setState(() => err = 'Reconnecting…');
      case 'hello': if (err == 'Reconnecting…') setState(() => err = ''); if (d['resumed'] != null) setState(() { view = Map.from(d['resumed']); phase = 'play'; });
    }
  }
  int get me { final p = (view?['players'] as List? ?? []).cast<Map>().firstWhere((p) => p['userId'] == Backend.userId, orElse: () => {'seat': 0}); return (p['seat'] as num).toInt(); }
  Map get st => view!['state'] as Map;
  bool get myTurn => st['turn'] == me && st['phase'] != 'over';
  Future<void> act(Map a) async { final r = await live.emit('match:action', a); if (r['ok'] != true && mounted) setState(() => err = r['message'] ?? r['code'] ?? ''); else if (mounted) setState(() => err = ''); }

  /* ---- state adapters: server JSON → the offline state classes the painters already know ---- */
  Map<int, List<int>> _mi(Map m) => {for (final e in m.entries) int.parse('${e.key}'): List<int>.from(e.value)};
  Map<int, int> _ii(Map? m) => {for (final e in (m ?? {}).entries) int.parse('${e.key}'): (e.value as num).toInt()};
  ludo.LudoState _ludo() { final s = st, seats = List<int>.from(s['seats']); final g = ludo.LudoState(seats, s['open'] == true, _mi(s['tokens']), _mi(s['tp']), _ii(s['bank']), _ii(s['tbank']), s['rolls'] == null ? null : _ii(s['rolls']), (s['turn'] as num).toInt());
    g.dice = s['dice']; g.phase = s['phase']; g.msg = s['msg'] ?? ''; g.done = List<int>.from(s['done'] ?? []); g.bonus = s['bonus'] == true; g.sixes = (s['sixes'] ?? 0) as int; return g; }
  sl.SlState _sl() { final s = st, seats = List<int>.from(s['seats']); final g = sl.SlState(seats, s['plus'] == true, _mi(s['tokens']), _mi(s['tp']), _ii(s['bank']), s['moves'] == null ? null : _ii(s['moves']), (s['turn'] as num).toInt());
    g.dice = s['dice']; g.phase = s['phase']; g.msg = s['msg'] ?? ''; g.done = List<int>.from(s['done'] ?? []); g.bonus = s['bonus'] == true; return g; }
  ttt.TttRound _ttt() { final s = st, r = s['r'] as Map; final t = ttt.TttRound(s['turn'] == 0 ? 0 : 1);
    if (s['variant'] == 'nine') { t.boards = [for (final b in r['b']) List<String?>.from(b)]; t.meta = List<String?>.from(r['meta']); t.active = r['active']; }
    else { t.cells = List<String?>.from(r['cells']); t.line = r['line'] == null ? null : List<int>.from(r['line']); t.faded = r['faded']; t.order = {'X': List<int>.from(r['order']['X']), 'O': List<int>.from(r['order']['O'])}; }
    return t; }

  /* ---- taps ---- */
  void _tapLudo(Offset p, double side) { if (!myTurn || st['phase'] != 'move') return; final g = _ludo(), k = 450 / side; for (final ti in g.legal(me)) { final c = ludo.lCoord(me, g.tokens[me]![ti], ti); if ((Offset((c[0] + .5) * 30, (c[1] + .5) * 30) - Offset(p.dx * k, p.dy * k)).distance < 21) { act({'type': 'move', 'ti': ti}); return; } } }
  void _tapSl(Offset p, double side) { if (!myTurn || st['phase'] != 'move') return; final g = _sl(), s = side / 1.1, u = s / 10, gi = g.seats.indexOf(me); for (final ti in g.legal(me)) { final pos = g.tokens[me]![ti]; final o = pos <= 0 ? Offset(u * .6 + gi * (side / g.seats.length) + ti * u * .55, s + u * .5) : sl.slXY(pos, s); if ((o - p).distance < u * .55) { act({'type': 'move', 'ti': ti}); return; } } }
  void _tapTtt(Offset p, double side) { if (!myTurn) return; final x = p.dx / side, y = p.dy / side; if (st['variant'] == 'nine') { final bi = (y * 3).floor() * 3 + (x * 3).floor(), ci = ((y * 9).floor() % 3) * 3 + (x * 9).floor() % 3; act({'type': 'mark', 'idx': bi.clamp(0, 8), 'sub': ci.clamp(0, 8)}); } else { act({'type': 'mark', 'idx': ((y * 3).floor() * 3 + (x * 3).floor()).clamp(0, 8)}); } }
  double slide = .5;
  void _shotRelease(double side) { if (drag == null || !myTurn) { drag = null; return; } final s = st, seats = List<int>.from(s['seats']); final sd = seats.indexOf(me) % 4, off = 62.0, u = 96 + slide * 208; final home = [[u, 400 - off], [off, 400 - u], [400 - u, off], [400 - off, u]][sd]; final d = Offset(home[0], home[1]) - drag!, dist = d.distance; setState(() => drag = null); if (dist < 12) return; act({'type': 'shot', 'sv': slide, 'ux': d.dx / dist, 'uy': d.dy / dist, 'pw': min(dist, 110) / 110 * 17}); }
  void _animateShot(Map d) { anim?.cancel(); shotFrames = d['frames'] as List?; frameI = 0; if (shotFrames == null) return; anim = Timer.periodic(const Duration(milliseconds: 50), (t) { if (!mounted || frameI >= shotFrames!.length - 1) { t.cancel(); setState(() => shotFrames = null); return; } setState(() => frameI++); }); }

  @override
  Widget build(BuildContext context) {
    if (phase == 'mode') return _modePicker();
    if (phase == 'queue' || view == null) return _queueView();
    final players = (view!['players'] as List).cast<Map>(), th = themeOf(widget.store.equipped.board), dice = diceSkinOf(widget.store.equipped.dice);
    final low = tleft < 60;
    return Stack(children: [
      Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(8, 4, 12, 4), child: Row(children: [
          IconButton(onPressed: () async { if (end == null) { final ok = await _confirmLeave(); if (ok != true) return; await live.emit('match:leave'); } widget.onBack(); }, icon: const Icon(Icons.chevron_left, color: T.ink)),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${game.name} · online', style: head(13)), Text('${widget.n} players · ${view!['mode']} · 1st 100 🪙', style: body(9, color: T.mute))])),
          Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: low ? T.red.withOpacity(.15) : Colors.white.withOpacity(.06), borderRadius: BorderRadius.circular(8)), child: Text('${tleft ~/ 60}:${(tleft % 60).toString().padLeft(2, '0')}', style: body(11, w: FontWeight.w700, color: low ? T.red : T.ink))),
        ])),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Row(children: [for (final p in players) ...[Seat(p: (p['seat'] as num).toInt(), name: p['name'] ?? 'Player', avatar: p['avatar'] ?? 'f1', you: p['userId'] == Backend.userId, active: st['turn'] == p['seat'] && st['phase'] != 'over', sub: p['bot'] == true ? 'bot' : p['connected'] == true ? '' : 'reconnecting…', timer: st['turn'] == p['seat'] && st['phase'] != 'over' ? ((view!['tleft'] ?? 0) as num) / 15 : null), if (p != players.last) const SizedBox(width: 4)]])),
        const SizedBox(height: 6),
        Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Stack(children: [
          SquareBox((side) => BoardFrame(theme: th, child: _board(side - 12, th))),
          Positioned(left: 0, right: 0, top: 4, child: IgnorePointer(child: Column(children: [for (final b in feed) Container(margin: const EdgeInsets.only(bottom: 4), padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: T.bg.withOpacity(.9), borderRadius: BorderRadius.circular(99), border: Border.all(color: T.pc[(b['seat'] as num).toInt() % 4].withOpacity(.4))), child: Text('${b['who']} ${b['text']}', style: body(11)))]))),
        ]))),
        const SizedBox(height: 6),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: _controls(dice)),
        if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(err, style: body(10, color: T.red))),
        Padding(padding: const EdgeInsets.fromLTRB(12, 6, 12, 8), child: SizedBox(height: 36, child: ListView(scrollDirection: Axis.horizontal, children: [for (final e in [...chatEmoji, ...quickSay]) GestureDetector(onTap: () => live.emit('match:say', {'text': e, 'kind': chatEmoji.contains(e) ? 'emoji' : 'quick'}), child: Container(margin: const EdgeInsets.only(right: 6), padding: const EdgeInsets.symmetric(horizontal: 12), alignment: Alignment.center, decoration: BoxDecoration(color: T.panel, borderRadius: BorderRadius.circular(99), border: Border.all(color: T.line)), child: Text(e, style: body(12))))]))),
      ]),
      if (end != null) _result(),
    ]);
  }

  Widget _board(double side, Item th) {
    switch (game.id) {
      case 'ludo': final g = _ludo(); final legal = myTurn && st['phase'] == 'move' ? g.legal(me) : <int>[]; return GestureDetector(onTapUp: (d) => _tapLudo(d.localPosition, side), child: CustomPaint(size: Size.square(side), painter: ludo.LudoPainter(g, th, legal, me, _ctx(), widget.store.equipped.pawn)));
      case 'snakes': final g = _sl(); final legal = myTurn && st['phase'] == 'move' ? g.legal(me) : <int>[]; return GestureDetector(onTapUp: (d) => _tapSl(d.localPosition, side), child: CustomPaint(size: Size.square(side), painter: sl.SlPainter(g, th, legal, me, null, null, null)));
      case 'uttt': final r = _ttt(); return GestureDetector(onTapUp: (d) => _tapTtt(d.localPosition, side), child: CustomPaint(size: Size.square(side), painter: ttt.TttPainter(r, st['variant'] == 'nine', st['variant'] == 'infinity', th, T.green, st['variant'] == 'nine' ? ttt.nineLegalOf(r) : const [])));
      default: return GestureDetector(
          onPanStart: (d) { if (myTurn) setState(() => drag = d.localPosition / side * 400); }, onPanUpdate: (d) { if (drag != null) setState(() => drag = d.localPosition / side * 400); }, onPanEnd: (_) => _shotRelease(side),
          child: CustomPaint(size: Size.square(side), painter: _CarromNet(st, me, slide, drag, shotFrames == null ? null : shotFrames![frameI] as List, th, strikerOf(widget.store.equipped.striker).color ?? T.yellow)));
    }
  }
  GameCtx _ctx() => GameCtx(n: widget.n, roster: [for (final p in (view!['players'] as List).cast<Map>()) Player((p['seat'] as num).toInt(), p['name'] ?? 'Player', p['avatar'] ?? 'f1', you: p['userId'] == Backend.userId)], mode: mode ?? formatsOf(game.id)[0], equip: widget.store.equipped, onEnd: (_) {}, say: (_, __, ___) {}, tryRedo: () => false, redoLeft: () => 0, redoPacks: () => 0);

  Widget _controls(Item dice) {
    final s = st, over = s['phase'] == 'over', turnName = (view!['players'] as List).cast<Map>().firstWhere((p) => p['seat'] == s['turn'], orElse: () => {'name': '—'})['name'];
    final status = over ? 'Game over' : s['phase'] == 'hold' ? (s['msg'] ?? '') : myTurn ? (s['phase'] == 'roll' ? (s['bonus'] == true ? 'Bonus roll — free' : 'Your turn') : s['phase'] == 'aim' ? 'Your shot — slide, then drag back to aim' : (s['msg'] ?? 'Your move')) : '$turnName playing';
    return Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), decoration: BoxDecoration(color: Colors.white.withOpacity(.04), borderRadius: BorderRadius.circular(16), border: Border.all(color: T.line)), child: Row(children: [
      if (game.id == 'ludo' || game.id == 'snakes') ...[DiceWidget(value: s['dice'], rolling: false, enabled: myTurn && s['phase'] == 'roll', glow: myTurn && s['phase'] == 'roll', onTap: () => act({'type': 'roll'}), color: T.pc[me], face: dice.faceC!, pip: dice.pip!), const SizedBox(width: 8)],
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(status, maxLines: 1, overflow: TextOverflow.ellipsis, style: body(12, w: FontWeight.w800)), if (game.id == 'carrom') SizedBox(height: 26, child: Slider(value: slide, onChanged: myTurn ? (v) => setState(() => slide = v) : null, activeColor: T.yellow, inactiveColor: T.line))])),
      if (game.id == 'ludo' || game.id == 'snakes') Btn('↻ ${(view!['redo'] ?? 0)}', small: true, tone: Tone.dark, onTap: myTurn && s['phase'] == 'move' && ((view!['redo'] ?? 0) as num) > 0 ? () => act({'type': 'redo'}) : null),
    ]));
  }

  Widget _modePicker() {
    final fm = formatsOf(game.id).where((m) => m.players.contains(widget.n)).toList();
    return Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [IconButton(onPressed: widget.onBack, icon: const Icon(Icons.chevron_left, color: T.ink)), Text('${game.name} · ${widget.n} players', style: head(18))]),
      Text('Pick a format · online', style: body(12, color: T.mute)), const SizedBox(height: 12),
      for (final m in fm) Padding(padding: const EdgeInsets.only(bottom: 10), child: Panel(onTap: () { setState(() => mode = m); _queue(); }, border: m.color.withOpacity(.4), child: Row(children: [Container(width: 44, height: 44, alignment: Alignment.center, decoration: BoxDecoration(color: m.color.withOpacity(.15), borderRadius: BorderRadius.circular(14)), child: Text(m.glyph, style: const TextStyle(fontSize: 22))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(m.name, style: head(15)), Text(m.tag, style: body(11, color: T.mute)), Text('${m.secsFor(widget.n) ~/ 60} min clock', style: body(10, color: m.color, w: FontWeight.w700))]))]))),
    ]));
  }
  Widget _queueView() => Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(game.glyph, style: const TextStyle(fontSize: 40)), Text(game.name, style: head(24)), const SizedBox(height: 16),
        Text(err.isNotEmpty ? err : 'Finding players $found of ${widget.n}…', style: body(12, color: err.isNotEmpty ? T.red : T.yellow, w: FontWeight.w600)), const SizedBox(height: 6),
        Text('Real players first; empty seats fill with bots after 8 seconds.', style: body(10, color: T.mute)), const SizedBox(height: 10),
        SizedBox(width: 160, child: LinearProgressIndicator(value: found / widget.n, color: T.yellow, backgroundColor: T.line, minHeight: 4)), const SizedBox(height: 20),
        Btn('Cancel', tone: Tone.ghost, small: true, onTap: () async { await live.emit('queue:leave'); widget.onBack(); }),
      ]));
  Future<bool?> _confirmLeave() => showDialog<bool>(context: context, builder: (c) => AlertDialog(backgroundColor: T.panel, title: Text('Leave the game?', style: head(18)), content: Text("You'll forfeit this match and its coins.", style: body(13, color: T.mute)), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Stay')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Leave', style: TextStyle(color: T.red)))]));

  Widget _result() {
    final you = end!['you'] as Map, rank = (you['rank'] as num).toInt(), pay = (you['pay'] as num).toInt();
    return Container(color: T.bg.withOpacity(.92), padding: const EdgeInsets.all(24), alignment: Alignment.center, child: Panel(border: rank == 0 ? T.green : T.line, child: Column(children: [
      Text(['🥇', '🥈', '🥉', '🎖️'][rank.clamp(0, 3)], style: const TextStyle(fontSize: 40)), const SizedBox(height: 8),
      Text(['Pehla sthaan! 🔥', 'Second place', 'Third place', 'Fourth place'][rank.clamp(0, 3)], style: head(20, color: rank == 0 ? T.green : T.ink)),
      Text(ad == 'doubled' ? '+${pay * 2} coins · doubled' : pay > 0 ? '+$pay coins added' : 'No coins this time', style: body(14, color: T.yellow, w: FontWeight.w700)),
      Text('${(you['trophies'] as num? ?? 0) >= 0 ? '+' : ''}${you['trophies']} 🏆${(you['cupPoints'] ?? 0) != 0 ? ' · +${you['cupPoints']} cup points' : ''}', style: body(11, color: T.mute)),
      const SizedBox(height: 16),
      if (ad == 'offer' && you['adNonce'] != null && pay > 0) Btn('▶ Watch ad · double to ${pay * 2} 🪙', full: true, onTap: () async { setState(() => ad = 'watching'); try { await Backend.post('/v1/ads/complete', {'nonce': you['adNonce']}); setState(() => ad = 'doubled'); Backend.get('/v1/me').then((j) => widget.store.applyMe(j)); } catch (e) { setState(() { ad = 'offer'; err = '$e'; }); } }),
      if (ad == 'watching') Padding(padding: const EdgeInsets.all(8), child: Text('Ad playing… (production: AdMob rewarded unit)', style: body(11, color: T.mute))),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: Btn('Leave', tone: Tone.ghost, onTap: widget.onBack)), const SizedBox(width: 8), Expanded(child: Btn('Rematch', onTap: () async { final id = end!['matchId']; setState(() { end = null; view = null; feed.clear(); }); setState(() => phase = 'queue'); final r = await live.emit('match:rematch', {'matchId': id}); if (r['ok'] != true && mounted) setState(() => err = r['message'] ?? ''); }))]),
    ])));
  }
}

/// Carrom board rendered straight from the server state (pieces, striker home, aim line, frame animation).
class _CarromNet extends CustomPainter {
  final Map st; final int me; final double slide; final Offset? drag; final List? frame; final Item th; final Color strikerC;
  _CarromNet(this.st, this.me, this.slide, this.drag, this.frame, this.th, this.strikerC);
  @override
  void paint(Canvas c, Size size) {
    const cb = 400.0; final k = size.width / cb; c.scale(k, k);
    c.drawRect(const Rect.fromLTWH(0, 0, cb, cb), Paint()..shader = const LinearGradient(colors: [Color(0xFF5A3512), Color(0xFF2A1706)]).createShader(const Rect.fromLTWH(0, 0, cb, cb)));
    final play = th.carromC ?? const [Color(0xFFF4E1BC), Color(0xFFDDBF8E)];
    c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(20, 20, cb - 40, cb - 40), const Radius.circular(8)), Paint()..shader = RadialGradient(colors: play, radius: .75).createShader(const Rect.fromLTWH(20, 20, cb - 40, cb - 40)));
    c.drawRect(const Rect.fromLTWH(34, 34, cb - 68, cb - 68), Paint()..color = const Color(0xFF8A2B22)..style = PaintingStyle.stroke..strokeWidth = 2.5);
    c.drawCircle(const Offset(200, 200), 48, Paint()..color = const Color(0x228A2B22));
    for (final pk in const [Offset(32, 32), Offset(cb - 32, 32), Offset(32, cb - 32), Offset(cb - 32, cb - 32)]) { c.drawCircle(pk, 21, Paint()..color = const Color(0xFF07050C)); }
    final pieces = (st['pieces'] as List).cast<Map>(), seats = List<int>.from(st['seats']);
    final pos = <int, Offset>{}; Offset? strikerPos;
    if (frame != null) { for (final f in frame!) { final i = (f[0] as num).toInt(); final o = Offset((f[1] as num).toDouble(), (f[2] as num).toDouble()); if (i < 0) strikerPos = o; else pos[i] = o; } }
    for (var i = 0; i < pieces.length; i++) {
      final p = pieces[i]; if (frame != null ? !pos.containsKey(i) : p['alive'] != true) continue;
      final o = pos[i] ?? Offset((p['x'] as num).toDouble(), (p['y'] as num).toDouble());
      final col = p['t'] == 'queen' ? const Color(0xFFC42B3A) : p['t'] == 'w' ? const Color(0xFFEFE1C0) : const Color(0xFF2E2840);
      c.drawCircle(o + const Offset(.5, 2), 9.2, Paint()..color = Colors.black38); c.drawCircle(o, 9.2, Paint()..color = col); c.drawCircle(o, 5.5, Paint()..color = Colors.white24..style = PaintingStyle.stroke);
    }
    final turn = (st['turn'] as num).toInt(), sd = seats.indexOf(turn) % 4, u = 96 + slide * 208; const off = 62.0;
    final home = [[u, cb - off], [off, cb - u], [cb - u, off], [cb - off, u]][sd];
    final s = strikerPos ?? (st['phase'] == 'aim' ? Offset(home[0], home[1]) : null);
    if (s != null) { c.drawCircle(s + const Offset(.5, 2.5), 12.4, Paint()..color = Colors.black38); c.drawCircle(s, 12.4, Paint()..shader = RadialGradient(colors: [Colors.white, strikerC, Colors.black54], stops: const [0, .4, 1], center: const Alignment(-.4, -.4)).createShader(Rect.fromCircle(center: s, radius: 12.4))); }
    if (drag != null && s != null) { final d = s - drag!, dist = d.distance; if (dist > 0) { final pw = min(dist, 110) / 110; c.drawLine(s, s + d / dist * 160, Paint()..color = Colors.white.withOpacity(.45 + pw * .45)..strokeWidth = 2.5); c.drawArc(Rect.fromCircle(center: s, radius: 18 + pw * 10), -pi / 2, pi * 2 * pw, false, Paint()..color = pw > .8 ? const Color(0xFFFF6B5A) : const Color(0xFFFFD86B)..style = PaintingStyle.stroke..strokeWidth = 3); } }
    final tp = TextPainter(text: TextSpan(text: st['msg'] ?? '', style: body(11, color: Colors.white70)), textDirection: TextDirection.ltr)..layout(); tp.paint(c, Offset(200 - tp.width / 2, 8));
  }
  @override
  bool shouldRepaint(_CarromNet o) => true;
}
