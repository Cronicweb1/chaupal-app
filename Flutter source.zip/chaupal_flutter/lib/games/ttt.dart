import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../models.dart';
import '../sound.dart';
import '../theme.dart';
import 'common.dart';

const _lines = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
List<int>? lineOf(List<String?> b) { for (final l in _lines) { if (b[l[0]] != null && b[l[0]] == b[l[1]] && b[l[0]] == b[l[2]]) return l; } return null; }
String? winOf(List<String?> b) { final l = lineOf(b); if (l != null) return b[l[0]]; return b.every((x) => x != null) ? 'd' : null; }
int minimax(List<String?> b, String me, String turn, [int depth = 0]) {
  final w = winOf(b);
  if (w == me) return 10 - depth; if (w == 'd') return 0; if (w != null) return depth - 10;
  var best = turn == me ? -99 : 99;
  for (var i = 0; i < 9; i++) { if (b[i] != null) continue; final nb = [...b]; nb[i] = turn; final v = minimax(nb, me, turn == 'X' ? 'O' : 'X', depth + 1); best = turn == me ? max(best, v) : min(best, v); }
  return best;
}
const moveSecs = 10;
const markColors = [T.green, T.blue, T.yellow, T.violet, Color(0xFFFF7A59)];

class TttRound {
  List<String?> cells = List.filled(9, null);
  Map<String, List<int>> order = {'X': [], 'O': []};
  List<List<String?>> boards = List.generate(9, (_) => List.filled(9, null)); // nine-board
  List<String?> meta = List.filled(9, null);
  int? active; int turn; int? last, faded; List<int>? line; String? win;
  TttRound(this.turn);
}

List<int> nineLegalOf(TttRound r) => r.active != null && r.meta[r.active!] == null ? [r.active!] : [for (var i = 0; i < 9; i++) if (r.meta[i] == null) i];

class TttGame extends StatefulWidget {
  final GameCtx ctx; final bool timeUp;
  const TttGame({super.key, required this.ctx, required this.timeUp});
  @override
  State<TttGame> createState() => _TttState();
}

class _TttState extends State<TttGame> {
  late final bool nine = widget.ctx.mode.id == 'nine', inf = widget.ctx.mode.id == 'infinity';
  static const me = 'X', bot = 'O';
  final seats = [0, 2];
  TttRound r = TttRound(0);
  int round = 1, tleft = moveSecs, myCol = 0;
  Map<String, int> wins = {'X': 0, 'O': 0};
  bool over = false, ended = false;
  String? banner;
  Timer? clock, botT, nextT;
  final rnd = Random();

  @override
  void initState() { super.initState(); clock = Timer.periodic(const Duration(seconds: 1), (_) => _tick()); }
  @override
  void didUpdateWidget(TttGame o) { super.didUpdateWidget(o); if (widget.timeUp && !o.timeUp && !over) _end(); }
  @override
  void dispose() { clock?.cancel(); botT?.cancel(); nextT?.cancel(); super.dispose(); }

  List<int> nineLegal() => r.active != null && r.meta[r.active!] == null ? [r.active!] : [for (var i = 0; i < 9; i++) if (r.meta[i] == null) i];

  void _tick() {
    if (!mounted || over || r.win != null || banner != null) return;
    if (tleft > 0) { setState(() => tleft--); return; }
    if (r.turn == 0) { final p = botPick(); if (p != null) play(p[0], p.length > 1 ? p[1] : null); }
  }

  void play(int idx, int? sub) {
    if (over || r.win != null || banner != null) return;
    final who = r.turn == 0 ? me : bot;
    if (nine) {
      if (sub == null || r.boards[idx][sub] != null || !nineLegal().contains(idx)) return;
      r.boards[idx][sub] = who;
      final w = winOf(r.boards[idx]); if (w != null) r.meta[idx] = w;
      r.active = sub; r.turn = 1 - r.turn; r.last = idx * 9 + sub;
      final mw = winOf(r.meta);
      Sfx.play(who == me ? 'x' : 'o');
      if (mw != null) { r.win = mw; _roundOver(mw == 'd' ? 'X' : mw); } else { setState(() => tleft = moveSecs); _scheduleBot(); }
      return;
    }
    if (r.cells[idx] != null) return;
    final o = r.order[who]!;
    r.faded = null;
    if (inf && o.length >= 3) { r.faded = o.removeAt(0); r.cells[r.faded!] = null; Sfx.play('fade'); }
    r.cells[idx] = who; o.add(idx); r.last = idx; r.turn = 1 - r.turn;
    r.line = lineOf(r.cells);
    r.win = r.line != null ? who : (r.cells.every((x) => x != null) && !inf ? 'd' : null);
    Sfx.play(who == me ? 'x' : 'o');
    if (r.win != null) _roundOver(r.win!); else { setState(() => tleft = moveSecs); _scheduleBot(); }
  }

  void _roundOver(String w) {
    if (w != 'd') { wins[w] = wins[w]! + 1; Sfx.play(w == me ? 'win' : 'lose'); }
    final target = widget.ctx.mode.target;
    setState(() { banner = w == 'd' ? 'Draw — replay' : w == me ? 'You take round $round' : '${widget.ctx.nameOf(2)} takes round $round'; });
    if (wins['X']! >= target || wins['O']! >= target) { nextT = Timer(const Duration(milliseconds: 1200), _end); return; }
    nextT = Timer(const Duration(milliseconds: 1400), () { if (!mounted) return; setState(() { if (w != 'd') round++; r = TttRound(w == 'd' ? r.turn : (w == me ? 1 : 0)); banner = null; tleft = moveSecs; }); _scheduleBot(); });
  }
  void _end() {
    if (ended) return; ended = true;
    setState(() => over = true);
    final mine = wins['X']!, theirs = wins['O']!;
    widget.ctx.onEnd(mine > theirs ? 0 : mine == theirs ? (rnd.nextBool() ? 0 : 1) : 1);
  }
  void _scheduleBot() {
    botT?.cancel();
    if (over || r.win != null || r.turn != 1) return;
    botT = Timer(const Duration(milliseconds: 520), () { if (!mounted || r.turn != 1 || r.win != null || banner != null) return; final p = botPick(); if (rnd.nextDouble() < .1) widget.ctx.say(chatEmoji[rnd.nextInt(8)], 2, widget.ctx.nameOf(2)); if (p != null) play(p[0], p.length > 1 ? p[1] : null); });
  }

  List<int>? botPick() {
    final who = r.turn == 0 ? me : bot, opp = who == me ? bot : me;
    if (nine) {
      List<int>? best; var bs = -1e9;
      for (final bi in nineLegal()) { for (var ci = 0; ci < 9; ci++) {
        if (r.boards[bi][ci] != null) continue;
        var s = rnd.nextDouble() * 3;
        final t1 = [...r.boards[bi]]; t1[ci] = who; if (winOf(t1) == who) s += 60;
        final t2 = [...r.boards[bi]]; t2[ci] = opp; if (winOf(t2) == opp) s += 40;
        if (ci == 4) s += 6; if (r.meta[ci] != null) s -= 12;
        if (s > bs) { bs = s; best = [bi, ci]; }
      } }
      return best;
    }
    final empty = [for (var i = 0; i < 9; i++) if (r.cells[i] == null) i];
    if (empty.isEmpty) return null;
    if (!inf) {
      if (rnd.nextDouble() < .18) return [empty[rnd.nextInt(empty.length)]];
      int? best; var bs = -99;
      for (final i in empty) { final b = [...r.cells]; b[i] = who; final v = minimax(b, who, opp); if (v > bs) { bs = v; best = i; } }
      return [best!];
    }
    List<String?> after(List<String?> cells, String w, int i) { final c = [...cells]; final o = [...r.order[w]!]; if (o.length >= 3) c[o.removeAt(0)] = null; c[i] = w; return c; }
    for (final i in empty) { if (lineOf(after(r.cells, who, i)) != null) return [i]; }
    final threats = empty.where((i) => lineOf(after(r.cells, opp, i)) != null).toList();
    for (final i in [4, 0, 2, 6, 8, 1, 3, 5, 7]) { if (threats.contains(i) && r.cells[i] == null) return [i]; }
    if (threats.isNotEmpty) return [threats[0]];
    final pref = [4, 0, 2, 6, 8, 1, 3, 5, 7].where(empty.contains).toList();
    return [pref[rnd.nextInt(min(3, pref.length))]];
  }

  @override
  Widget build(BuildContext context) {
    final ctx = widget.ctx, th = themeOf(ctx.equip.board);
    final myColor = markColors[myCol];
    return Column(children: [
      Row(children: [
        Seat(p: 0, name: ctx.nameOf(0), avatar: ctx.playerOf(0).avatar, you: true, active: r.turn == 0 && !over, sub: 'X · ${wins['X']} of ${ctx.mode.target}', timer: r.turn == 0 && !over ? tleft / moveSecs : null, frame: frameOf(ctx.playerOf(0).frame).color),
        const SizedBox(width: 4),
        Seat(p: 2, name: ctx.nameOf(2), avatar: ctx.playerOf(2).avatar, active: r.turn == 1 && !over, sub: 'O · ${wins['O']} of ${ctx.mode.target}', timer: r.turn == 1 && !over ? tleft / moveSecs : null, frame: frameOf(ctx.playerOf(2).frame).color),
      ]),
      const SizedBox(height: 6),
      Expanded(child: Stack(alignment: Alignment.center, children: [
        SquareBox((side) => BoardFrame(theme: th, child: GestureDetector(
          onTapUp: (d) {
            if (r.turn != 0 || over || banner != null) return;
            final s = side - 12, x = d.localPosition.dx / s, y = d.localPosition.dy / s;
            if (nine) { final bi = (y * 3).floor() * 3 + (x * 3).floor(); final ci = ((y * 9).floor() % 3) * 3 + (x * 9).floor() % 3; play(bi.clamp(0, 8).toInt(), ci.clamp(0, 8).toInt()); }
            else { play(((y * 3).floor() * 3 + (x * 3).floor()).clamp(0, 8).toInt(), null); }
          },
          child: CustomPaint(size: Size.square(side - 12), painter: TttPainter(r, nine, inf, th, myColor, nineLegal())),
        ))),
        if (banner != null) Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10), decoration: BoxDecoration(color: T.bg.withOpacity(.92), borderRadius: BorderRadius.circular(16), border: Border.all(color: T.yellow, width: 2)), child: Text(banner!, style: head(16, color: T.yellow))),
      ])),
      const SizedBox(height: 6),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(color: Colors.white.withOpacity(.04), borderRadius: BorderRadius.circular(16), border: Border.all(color: T.line)),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(over ? 'Game over' : r.turn == 0 ? (nine && r.active != null && r.meta[r.active!] == null ? 'Play in board ${r.active! + 1}' : 'Your move') : '${ctx.nameOf(2)} thinking…', style: body(12, w: FontWeight.w800)),
            Text('Round $round · ${ctx.mode.name}${inf ? ' · oldest mark fades' : ''}', style: body(10, color: T.mute)),
          ])),
          Row(children: [for (var i = 0; i < markColors.length; i++) GestureDetector(onTap: () => setState(() => myCol = i), child: Container(width: 18, height: 18, margin: const EdgeInsets.only(left: 4), decoration: BoxDecoration(color: markColors[i], shape: BoxShape.circle, border: Border.all(color: i == myCol ? Colors.white : Colors.transparent, width: 2))))]),
        ]),
      ),
    ]);
  }
}

class TttPainter extends CustomPainter {
  final TttRound r; final bool nine, inf; final Item th; final Color myColor; final List<int> legal;
  TttPainter(this.r, this.nine, this.inf, this.th, this.myColor, this.legal);
  @override
  void paint(Canvas c, Size size) {
    final s = size.width;
    c.drawRect(Offset.zero & size, Paint()..shader = LinearGradient(colors: th.boardC ?? const [Color(0xFFFFFDF6), Color(0xFFEBE0C8)]).createShader(Offset.zero & size));
    final grid = Paint()..color = const Color(0x553C2D14)..strokeWidth = nine ? 4 : 5..strokeCap = StrokeCap.round;
    if (!nine) {
      for (var i = 1; i < 3; i++) { c.drawLine(Offset(s / 3 * i, s * .06), Offset(s / 3 * i, s * .94), grid); c.drawLine(Offset(s * .06, s / 3 * i), Offset(s * .94, s / 3 * i), grid); }
      for (var i = 0; i < 9; i++) { final v = r.cells[i]; if (v == null) continue; final fade = inf && r.order[v]!.length >= 3 && r.order[v]![0] == i; _mark(c, v, Offset((i % 3 + .5) * s / 3, (i ~/ 3 + .5) * s / 3), s / 6 * .55, fade ? .35 : 1); }
      if (r.line != null) { final a = r.line![0], b = r.line![2]; c.drawLine(Offset((a % 3 + .5) * s / 3, (a ~/ 3 + .5) * s / 3), Offset((b % 3 + .5) * s / 3, (b ~/ 3 + .5) * s / 3), Paint()..color = T.yellow..strokeWidth = 6..strokeCap = StrokeCap.round); }
    } else {
      final u = s / 3;
      for (var bi = 0; bi < 9; bi++) {
        final ox = (bi % 3) * u, oy = (bi ~/ 3) * u;
        final isLegal = legal.contains(bi) && r.meta[bi] == null;
        if (isLegal) c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(ox + 4, oy + 4, u - 8, u - 8), const Radius.circular(8)), Paint()..color = T.yellow.withOpacity(.18));
        final small = Paint()..color = const Color(0x443C2D14)..strokeWidth = 1.5;
        for (var i = 1; i < 3; i++) { c.drawLine(Offset(ox + u / 3 * i, oy + 8), Offset(ox + u / 3 * i, oy + u - 8), small); c.drawLine(Offset(ox + 8, oy + u / 3 * i), Offset(ox + u - 8, oy + u / 3 * i), small); }
        for (var ci = 0; ci < 9; ci++) { final v = r.boards[bi][ci]; if (v != null) _mark(c, v, Offset(ox + (ci % 3 + .5) * u / 3, oy + (ci ~/ 3 + .5) * u / 3), u / 6 * .5, r.meta[bi] != null ? .25 : 1); }
        final m = r.meta[bi];
        if (m != null && m != 'd') _mark(c, m, Offset(ox + u / 2, oy + u / 2), u * .32, 1);
      }
      for (var i = 1; i < 3; i++) { c.drawLine(Offset(u * i, s * .03), Offset(u * i, s * .97), grid); c.drawLine(Offset(s * .03, u * i), Offset(s * .97, u * i), grid); }
    }
  }
  void _mark(Canvas c, String v, Offset o, double r, double op) {
    final col = (v == 'X' ? myColor : T.red).withOpacity(op);
    final p = Paint()..color = col..strokeWidth = r * .34..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
    if (v == 'X') { c.drawLine(o + Offset(-r, -r), o + Offset(r, r), p); c.drawLine(o + Offset(r, -r), o + Offset(-r, r), p); } else { c.drawCircle(o, r, p); }
  }
  @override
  bool shouldRepaint(TttPainter o) => true;
}
