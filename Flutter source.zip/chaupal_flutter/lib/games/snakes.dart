import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../models.dart';
import '../sound.dart';
import '../theme.dart';
import 'common.dart';

const snakes_ = {99: 78, 95: 56, 89: 53, 79: 41, 65: 35, 58: 38, 47: 18, 30: 9, 22: 3};
const ladders_ = {4: 25, 13: 46, 27: 56, 33: 52, 42: 63, 50: 69, 62: 81, 74: 92, 86: 97};
const slSecs = 12, hopMs = 120;

/// Centre of square [c] (1..100) on a board of side [s]; 0 = off-board start row.
Offset slXY(int c, double s) {
  final u = s / 10;
  if (c <= 0) return Offset(u * .5, s + u * .5);
  final r = (c - 1) ~/ 10, i = (c - 1) % 10;
  return Offset((r.isOdd ? 9 - i : i) * u + u / 2, (9 - r) * u + u / 2);
}

class SlState {
  final List<int> seats; final bool plus;
  Map<int, List<int>> tokens, tp; Map<int, int> bank; Map<int, int>? moves;
  int turn; int? dice; String phase = 'roll', msg = 'Tap the dice'; bool rolling = false, bonus = false; List<int> done = []; FxLabel? fx; int rollId = 0;
  SlState(this.seats, this.plus, this.tokens, this.tp, this.bank, this.moves, this.turn);
  factory SlState.init(int n, Mode m) { final seats = seatsFor[n]!; return SlState(seats, m.id == 'plus', {for (final s in seats) s: List.filled(m.tokens, 0)}, {for (final s in seats) s: List.filled(m.tokens, 0)}, {for (final s in seats) s: 0}, m.moves == null ? null : {for (final s in seats) s: m.moves![n]!}, seats[0]); }
  int score(int p) => bank[p]! + tp[p]!.fold(0, (a, b) => a + b);
  List<int> legal(int p) => [for (var i = 0; i < tokens[p]!.length; i++) if (tokens[p]![i] < 100 && (!plus || tokens[p]![i] + (dice ?? 0) <= 100)) i];
  bool canPlay(int q) => !done.contains(q) && (moves == null || moves![q]! > 0);
  void finish() { final rest = seats.where((s) => !done.contains(s)).toList()..sort((a, b) => score(b).compareTo(score(a))); done.addAll(rest); phase = 'over'; }
  void advance() {
    final idx = seats.indexOf(turn); var found = false;
    for (var k = 1; k <= seats.length; k++) { final c = seats[(idx + k) % seats.length]; if (canPlay(c)) { turn = c; found = true; break; } }
    dice = null; phase = 'roll'; bonus = false;
    if (!found) finish();
  }
  void settleRoll(int d) {
    dice = d; rolling = false;
    if (moves != null && !bonus) moves![turn] = moves![turn]! - 1;
    bonus = false;
    final lg = legal(turn);
    if (lg.isEmpty) { msg = 'Rolled $d — no move'; phase = 'hold'; return; }
    phase = 'move'; msg = lg.length == 1 ? 'Tap your token' : 'Choose a token';
  }
}

class SlGame extends StatefulWidget {
  final GameCtx ctx; final bool timeUp;
  const SlGame({super.key, required this.ctx, required this.timeUp});
  @override
  State<SlGame> createState() => _SlState();
}

class _SlState extends State<SlGame> {
  late SlState g = SlState.init(widget.ctx.n, widget.ctx.mode);
  int tleft = slSecs, gen = 0; bool ended = false, busy = false;
  // hop animation: token being moved and its displayed square
  int? animP, animTi, animPos;
  final rnd = Random(); Timer? clock; final timers = <Timer>[];
  int get human => widget.ctx.human;

  @override
  void initState() { super.initState(); clock = Timer.periodic(const Duration(seconds: 1), (_) => _tick()); _after(); }
  @override
  void didUpdateWidget(SlGame o) { super.didUpdateWidget(o); if (widget.timeUp && !o.timeUp && g.phase != 'over') { setState(() { g.msg = 'Time up'; g.finish(); }); _after(); } }
  @override
  void dispose() { clock?.cancel(); for (final t in timers) { t.cancel(); } super.dispose(); }
  void _later(int ms, VoidCallback f) { final my = gen; timers.add(Timer(Duration(milliseconds: ms), () { if (mounted && my == gen) f(); })); }
  void _set(void Function() f) { setState(f); gen++; _after(); }

  void _after() {
    if (g.phase == 'over') { if (!ended) { ended = true; widget.ctx.onEnd(g.done.indexOf(human)); } return; }
    if (g.phase == 'hold') { _later(1000, () => _set(() => g.advance())); return; }
    if (g.rolling || busy) return;
    if (g.turn != human) {
      if (g.phase == 'roll') _later(1000, roll);
      else if (g.phase == 'move') _later(750, () { if (rnd.nextDouble() < .12) widget.ctx.say(chatEmoji[rnd.nextInt(8)], g.turn, widget.ctx.nameOf(g.turn)); play(bestMove()); });
    } else {
      if (g.phase == 'roll') Sfx.play('turn');
      if (g.phase == 'move') { final lg = g.legal(human); if (lg.length == 1) _later(650, () => play(lg[0])); }
    }
  }
  void _tick() {
    if (!mounted || g.phase == 'over' || g.phase == 'hold' || g.rolling || busy) return;
    if (tleft > 0) { setState(() => tleft--); return; }
    if (g.phase == 'roll') roll(); else if (g.phase == 'move') play(bestMove());
  }
  void roll() {
    if (g.rolling || g.phase != 'roll') return;
    final d = 1 + rnd.nextInt(6), id = ++g.rollId;
    Sfx.play('roll');
    setState(() { g.rolling = true; g.phase = 'rolling'; g.msg = 'Rolling…'; }); gen++;
    _later(600, () { if (g.rolling && g.rollId == id) _set(() { g.settleRoll(d); tleft = slSecs; }); });
  }
  int bestMove() {
    final lg = g.legal(g.turn); if (lg.isEmpty) return -1;
    var best = lg[0]; var bs = -1e9;
    for (final i in lg) {
      var np = g.tokens[g.turn]![i] + g.dice!; if (!g.plus && np > 100) np = 200 - np;
      var sc = np.toDouble();
      if (ladders_.containsKey(np)) sc += 40; if (snakes_.containsKey(np)) sc -= 60;
      if (g.plus) { for (final q in g.seats) { if (q != g.turn && g.tokens[q]!.where((x) => x == np).length == 1 && np < 100) sc += 30; } }
      if (np == 100) sc += 80;
      if (sc > bs) { bs = sc; best = i; }
    }
    return best;
  }

  /// Resolves a move: animates hops, then applies snake/ladder, cuts, scoring and turn order.
  void play(int ti) {
    if (g.phase != 'move' || busy) return;
    final p = g.turn, lg = g.legal(p);
    if (!lg.contains(ti)) { if (lg.isEmpty) _set(() => g.advance()); return; }
    final from = g.tokens[p]![ti], d = g.dice!;
    var raw = from + d; if (!g.plus && raw > 100) raw = 200 - raw;
    final steps = <int>[];
    if (raw >= from) { for (var s = from + 1; s <= raw; s++) { steps.add(s); } } else { for (var s = from + 1; s <= 100; s++) { steps.add(s); } for (var s = 99; s >= raw; s--) { steps.add(s); } }
    busy = true; gen++;
    setState(() { animP = p; animTi = ti; animPos = from; g.msg = ''; });
    var k = 0;
    void hop() {
      if (!mounted) return;
      if (k < steps.length) { setState(() => animPos = steps[k]); Sfx.play('move'); k++; timers.add(Timer(const Duration(milliseconds: hopMs), hop)); return; }
      _apply(p, ti, raw, d);
    }
    hop();
  }
  void _apply(int p, int ti, int raw, int d) {
    var np = raw, gain = d, label = '+$d', snd = 'move';
    if (ladders_.containsKey(np)) { final up = ladders_[np]! - np; np = ladders_[np]!; gain += up; label = 'Ladder +${d + up}'; snd = 'ladder'; }
    else if (snakes_.containsKey(np)) { final down = np - snakes_[np]!; np = snakes_[np]!; gain = d - down; label = 'Snake $gain'; snd = 'snake'; }
    var captured = false;
    if (g.plus && np > 0 && np < 100) {
      for (final q in g.seats) { if (q == p) continue; final at = [for (var j = 0; j < g.tokens[q]!.length; j++) if (g.tokens[q]![j] == np) j];
        if (at.length == 1) { g.tokens[q]![at[0]] = 0; g.tp[q]![at[0]] = 0; captured = true; } }
    }
    g.tokens[p]![ti] = np; g.tp[p]![ti] = g.plus ? max(0, g.tp[p]![ti] + gain) : 0;
    if (captured) { g.bank[p] = g.bank[p]! + 10; label = 'Cut! +10'; snd = 'cut'; }
    if (np == 100) { if (g.plus) { g.bank[p] = g.bank[p]! + g.tp[p]![ti] + 50; g.tp[p]![ti] = 0; } label = 'Home +50'; snd = 'home'; }
    final xy = slXY(max(1, np), 300);
    g.fx = FxLabel(xy.dx, xy.dy, label, snd == 'snake' ? T.red : T.pc[p], snd);
    Sfx.play(snd);
    timers.add(Timer(const Duration(milliseconds: 950), () { if (mounted) setState(() => g.fx = null); }));
    if (!g.plus && np == 100) { g.done.add(p); if (g.done.length >= g.seats.length - 1) { g.finish(); } }
    if (g.plus && g.tokens[p]!.every((x) => x == 100)) g.done.add(p);
    if (g.phase != 'over') {
      final again = d == 6 || captured || snd == 'ladder' || np == 100;
      if (again && g.canPlay(p)) { g.phase = 'roll'; g.dice = null; g.bonus = true; g.msg = 'Bonus roll — free'; } else { g.advance(); }
    }
    busy = false; animP = null; animTi = null; animPos = null;
    _set(() => tleft = slSecs);
  }

  void _tap(Offset local, double side) {
    if (g.turn != human || g.phase != 'move' || busy) return;
    final s = side / 1.1, u = s / 10, gi = g.seats.indexOf(human); // board = top 10/11 of the square; start row below
    for (final ti in g.legal(human)) {
      final pos = g.tokens[human]![ti];
      final o = pos <= 0 ? Offset(u * .6 + gi * (side / g.seats.length) + ti * u * .55, s + u * .5) : slXY(pos, s);
      if ((o - local).distance < u * .55) { play(ti); return; }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ctx = widget.ctx, th = themeOf(ctx.equip.board), dice = diceSkinOf(ctx.equip.dice);
    final myTurn = g.turn == human && g.phase != 'over';
    final legal = g.phase == 'move' && g.turn == human && !busy ? g.legal(human) : <int>[];
    return Column(children: [
      Row(children: [for (final s in g.seats) ...[
        Seat(p: s, name: ctx.nameOf(s), avatar: ctx.playerOf(s).avatar, you: s == human, active: g.turn == s, score: g.score(s),
            sub: g.moves != null ? '${g.moves![s]} moves' : 'square ${g.tokens[s]![0]}', timer: g.turn == s && g.phase != 'over' ? tleft / slSecs : null, frame: frameOf(ctx.playerOf(s).frame).color),
        if (s != g.seats.last) const SizedBox(width: 4)]]),
      const SizedBox(height: 6),
      Expanded(child: SquareBox((side) => BoardFrame(theme: th, child: GestureDetector(
        onTapUp: (d) => _tap(d.localPosition, side - 12),
        child: CustomPaint(size: Size.square(side - 12), painter: SlPainter(g, th, legal, human, animP, animTi, animPos)),
      )))),
      const SizedBox(height: 6),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(color: Colors.white.withOpacity(.04), borderRadius: BorderRadius.circular(16), border: Border.all(color: T.line)),
        child: Row(children: [
          DiceWidget(value: g.dice, rolling: g.rolling, enabled: myTurn && g.phase == 'roll' && !busy, glow: myTurn && g.phase == 'roll', onTap: roll, color: T.pc[human], face: dice.faceC!, pip: dice.pip!),
          const SizedBox(width: 8),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(g.phase == 'over' ? 'Game over' : g.phase == 'hold' ? g.msg : busy ? 'Moving…' : myTurn ? (g.phase == 'roll' ? (g.bonus ? 'Bonus roll — free' : 'Your turn') : (g.msg.isEmpty ? 'Move a token' : g.msg)) : '${ctx.nameOf(g.turn)} playing', maxLines: 1, overflow: TextOverflow.ellipsis, style: body(12, w: FontWeight.w800)),
            Text(g.phase == 'over' ? '' : '${g.score(human)} pts · ${ctx.mode.name}${g.moves != null ? ' · ${g.moves![human]} moves left' : ''}', style: body(10, color: T.mute)),
          ])),
          Btn(ctx.redoPacks() > 0 ? '↻ pack ${ctx.redoPacks()} · ${ctx.redoLeft()}' : '↻ 20 🪙 · ${ctx.redoLeft()}', small: true, tone: Tone.dark,
              onTap: !myTurn || g.phase != 'move' || busy || ctx.redoLeft() <= 0 ? null : () { if (ctx.tryRedo()) _set(() { g.phase = 'roll'; g.bonus = true; g.settleRoll(1 + rnd.nextInt(6)); }); }),
        ]),
      ),
    ]);
  }
}

class SlPainter extends CustomPainter {
  final SlState g; final Item th; final List<int> legal; final int human; final int? animP, animTi, animPos;
  SlPainter(this.g, this.th, this.legal, this.human, this.animP, this.animTi, this.animPos);
  @override
  void paint(Canvas c, Size size) {
    final s = size.width / 1.1, u = s / 10; // 10 rows + a start row
    c.drawRect(Offset.zero & size, Paint()..shader = LinearGradient(colors: th.boardC ?? const [Color(0xFFFFFDF6), Color(0xFFEBE0C8)]).createShader(Offset.zero & size));
    final cell = th.cell ?? const Color(0xFFFFFDF6);
    for (var n = 1; n <= 100; n++) {
      final o = slXY(n, s);
      final r = RRect.fromRectAndRadius(Rect.fromCenter(center: o, width: u - 2, height: u - 2), const Radius.circular(4));
      c.drawRRect(r, Paint()..color = n.isEven ? cell : cell.withOpacity(.55));
      if (snakes_.containsKey(n)) c.drawRRect(r, Paint()..color = T.red.withOpacity(.16));
      if (ladders_.containsKey(n)) c.drawRRect(r, Paint()..color = T.green.withOpacity(.16));
      if (n == 100) c.drawRRect(r, Paint()..color = T.yellow.withOpacity(.4));
      _text(c, '$n', o + Offset(-u * .3, -u * .3), 7, const Color(0x99000000));
    }
    ladders_.forEach((a, b) {
      final pa = slXY(a, s), pb = slXY(b, s), d = pb - pa, len = d.distance, nrm = Offset(-d.dy, d.dx) / len * (u * .18);
      final rail = Paint()..color = const Color(0xFFB07A2E)..strokeWidth = 3..strokeCap = StrokeCap.round;
      c.drawLine(pa + nrm, pb + nrm, rail); c.drawLine(pa - nrm, pb - nrm, rail);
      for (var t = .08; t < 1; t += .12) { final m = pa + d * t; c.drawLine(m + nrm, m - nrm, rail..strokeWidth = 2); }
    });
    snakes_.forEach((a, b) {
      final pa = slXY(a, s), pb = slXY(b, s), mid = (pa + pb) / 2, d = pb - pa, nrm = Offset(-d.dy, d.dx) / d.distance * (u * .9);
      final path = Path()..moveTo(pa.dx, pa.dy)..quadraticBezierTo(mid.dx + nrm.dx, mid.dy + nrm.dy, pb.dx, pb.dy);
      c.drawPath(path, Paint()..color = const Color(0xFF2E8B57)..style = PaintingStyle.stroke..strokeWidth = u * .28..strokeCap = StrokeCap.round);
      c.drawPath(path, Paint()..color = const Color(0xFF9BE07A)..style = PaintingStyle.stroke..strokeWidth = u * .08);
      c.drawCircle(pa, u * .22, Paint()..color = const Color(0xFF2E8B57));
      c.drawCircle(pa + Offset(-u * .07, -u * .05), u * .05, Paint()..color = Colors.white); c.drawCircle(pa + Offset(u * .07, -u * .05), u * .05, Paint()..color = Colors.white);
    });
    // start row
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(u * .1, s + u * .08, size.width - u * .2, u * .84), const Radius.circular(6)), Paint()..color = Colors.black12);
    for (final p in g.seats) {
      final gi = g.seats.indexOf(p);
      for (var ti = 0; ti < g.tokens[p]!.length; ti++) {
        var pos = g.tokens[p]![ti];
        if (animP == p && animTi == ti && animPos != null) pos = animPos!;
        Offset o;
        if (pos <= 0) { o = Offset(u * .6 + gi * (size.width / g.seats.length) + ti * u * .55, s + u * .5); }
        else { o = slXY(pos, s); final stack = [for (final q in g.seats) for (var j = 0; j < g.tokens[q]!.length; j++) if (g.tokens[q]![j] == pos && (q < p || (q == p && j < ti))) 1].length; o += Offset(stack * 3.0, -stack * 3.0); }
        final can = p == human && legal.contains(ti);
        if (can) c.drawCircle(o, u * .42, Paint()..color = T.pc[p].withOpacity(.3));
        c.drawCircle(o + const Offset(0, 1.5), u * .27, Paint()..color = Colors.black38);
        c.drawCircle(o, u * .27, Paint()..color = T.pc[p]);
        c.drawCircle(o, u * .27, Paint()..color = can ? Colors.white : Colors.black45..style = PaintingStyle.stroke..strokeWidth = can ? 2 : 1);
        if (g.tp[p]![ti] > 0 && pos < 100) _text(c, '${g.tp[p]![ti]}', o + Offset(u * .28, -u * .32), 7, Colors.white, bg: const Color(0xFF1E1937));
      }
    }
    final fx = g.fx;
    if (fx != null) { final o = Offset(fx.x / 300 * s, fx.y / 300 * s - u * .7); _text(c, fx.text, o, 14, fx.color, bg: Colors.black54); }
  }
  void _text(Canvas c, String t, Offset o, double size, Color col, {Color? bg}) {
    final tp = TextPainter(text: TextSpan(text: t, style: TextStyle(fontSize: size, fontWeight: FontWeight.w800, color: col)), textDirection: TextDirection.ltr)..layout();
    if (bg != null) c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: o, width: tp.width + 10, height: tp.height + 4), const Radius.circular(6)), Paint()..color = bg);
    tp.paint(c, o - Offset(tp.width / 2, tp.height / 2));
  }
  @override
  bool shouldRepaint(SlPainter o) => true;
}
